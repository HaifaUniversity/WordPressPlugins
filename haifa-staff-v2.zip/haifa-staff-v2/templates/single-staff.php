<?php
/**
 * Single Staff Member Template – Haifa Staff V2
 * No ACF dependency. Reads all fields via get_post_meta().
 */

// Flag English staff pages so header logic can exclude them
$_haifa_staff_lang = $lang ?? 'he';
if ($_haifa_staff_lang !== 'he') {
    add_filter('body_class', function($classes) {
        $classes[] = 'haifa-staff-en';
        return $classes;
    });
}


function is_university_network() {
    $ip = $_SERVER['REMOTE_ADDR'];
    foreach (['132.74.0.0/16'] as $range) {
        if (ip_in_range($ip, $range)) return true;
    }
    return false;
}

function ip_in_range($ip, $range) {
    if (strpos($range, '/') === false) return $ip === $range;
    list($subnet, $mask) = explode('/', $range);
    $ip_long  = ip2long($ip);
    $sub_long = ip2long($subnet);
    if ($ip_long === false || $sub_long === false) return false;
    $mask_long = -1 << (32 - (int)$mask);
    $sub_long &= $mask_long;
    return ($ip_long & $mask_long) === $sub_long;
}

// Canonical is handled centrally in haifa-staff-v2.php (template_redirect block).

// ── Language detection ────────────────────────────────────────────────────────
$staff_context = get_query_var('staff_context', '');

// WPML fallback: detect language from original URI before WPML rewrote it
if (empty($staff_context)) {
    $original_uri = $_SERVER['HAIFA_STAFF_ORIGINAL_URI'] ?? '';
    if (preg_match('#^/en/#', $original_uri)) {
        $staff_context = 'en';
    }
}

$lang = get_option('haifa_staff_english_only_site') === '1' ? 'en' : 'he';
if (preg_match('#^(en|ar)(/|$)#', $staff_context, $m)) {
    $lang = $m[1];
}

// ── Language-aware field getter (falls back to Hebrew if English is empty) ────
function haifa_v2_lang_field(string $field, int $pid, string $lang, bool $fallback = true): string {
    if ($lang !== 'he') {
        $val = get_post_meta($pid, $field . '_' . $lang, true);
        if (!empty($val)) return $val;
        if (!$fallback) return '';
    }
    return get_post_meta($pid, $field, true) ?: '';
}

// ── Label maps ────────────────────────────────────────────────────────────────
$section_labels = $lang === 'en'
    ? ['about' => 'About', 'publications' => 'Publications', 'education' => 'Education',
       'academic_background' => 'Academic Background', 'reserach_areas' => 'Research Areas',
       'media' => 'Media', 'prizes' => 'Awards', 'additional_info' => 'Additional Info']
    : ['about' => 'אודות', 'publications' => 'פרסומים', 'education' => 'השכלה',
       'academic_background' => 'רקע אקדמי', 'reserach_areas' => 'תחומי מחקר',
       'media' => 'מדיה', 'prizes' => 'פרסים', 'additional_info' => 'מידע נוסף'];

$contact_labels = $lang === 'en'
    ? ['email' => 'Email', 'phone' => 'Phone', 'ext' => 'Extension', 'room' => 'Room', 'hours' => 'Office Hours', 'personal' => 'Personal Site']
    : ['email' => 'דוא"ל', 'phone' => 'טלפון', 'ext' => 'טלפון פנימי', 'room' => 'חדר', 'hours' => 'שעות קבלה', 'personal' => 'אתר אישי'];

// Establish correct staff query BEFORE get_header() — Elementor's Theme Builder
// header renders during get_header(), so the query must already be correct at
// that point (matching is_singular/is_single) or Elementor/EAEL/ElementsKit's
// JS init (which depends on elementorFrontendConfig built from the query state)
// silently skips per-widget handlers like the wrapper-link overlay and parallax class.
$_staff_slug_tpl = get_query_var('staff_slug');
if (empty($_staff_slug_tpl)) {
    $_p = trim(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');
    $_parts = explode('/', $_p);
    $_staff_slug_tpl = array_pop($_parts);
}
if (!empty($_staff_slug_tpl)) {
    $_q = new WP_Query(['post_type' => 'staff', 'name' => $_staff_slug_tpl, 'posts_per_page' => 1]);
    if ($_q->have_posts()) {
        global $wp_query, $post;
        $wp_query              = $_q;
        $wp_query->is_404      = false;
        $wp_query->is_singular = true;
        $wp_query->is_single   = true;
        // Elementor/EAEL/ElementsKit build their frontend JS config (elementorFrontendConfig)
        // from the global $post at header-render time. WP_Query alone doesn't set it —
        // only the_post() does, and that's inside our loop, AFTER get_header(). Without
        // this, the header renders with a stale/empty $post, and widget JS handlers
        // (wrapper-link, parallax class) silently skip initializing.
        $post = $_q->posts[0];
        setup_postdata($post);
    }
}

get_header();

// Re-check after get_header() as a safety net — some themes/plugins hooked to
// wp_head or template_redirect can still reset the query, so re-apply if needed.
if (!empty($_staff_slug_tpl)) {
    global $wp_query, $post;
    if (empty($wp_query->post) || $wp_query->post->post_type !== 'staff' || $wp_query->post->post_name !== $_staff_slug_tpl) {
        $_q2 = new WP_Query(['post_type' => 'staff', 'name' => $_staff_slug_tpl, 'posts_per_page' => 1]);
        if ($_q2->have_posts()) {
            $wp_query              = $_q2;
            $wp_query->is_404      = false;
            $wp_query->is_singular = true;
            $wp_query->is_single   = true;
            $post = $_q2->posts[0];
            setup_postdata($post);
        }
    }
}

?>

<div class="haifa-staff-single-wrapper" dir="<?php echo $lang === 'en' ? 'ltr' : 'rtl'; ?>">
    <?php while (have_posts()) : the_post();

        // Build breadcrumbs — prefer the ?from= referrer path (set by the staff grid widget
        // when linking here), falling back to the current URL structure if absent.
        $breadcrumb_items = [];
        $current_path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');
        $path_parts   = explode('/', $current_path);
        $staff_slug   = array_pop($path_parts);

        $from_param = isset($_GET['from']) ? trim(sanitize_text_field(wp_unslash($_GET['from'])), '/') : '';
        if ($from_param !== '') {
            // Validate: only allow internal-looking relative paths, never full URLs or protocol-relative.
            $from_param = preg_replace('#^https?://#i', '', $from_param);
            if (strpos($from_param, '//') === 0 || preg_match('#^[a-z]+://#i', $from_param)) {
                $from_param = '';
            }
        }
        // Came from a widget rendered on an unpublished/draft preview page —
        // link back to that same preview (its real permalink doesn't exist yet).
        $is_preview_from = false;
        if (strpos($from_param, 'preview:') === 0) {
            $preview_post_id = (int) substr($from_param, 8);
            $preview_post    = $preview_post_id ? get_post($preview_post_id) : null;
            if ($preview_post) {
                $breadcrumb_items[] = [
                    'title' => $preview_post->post_title,
                    'url'   => get_preview_post_link($preview_post_id),
                ];
            }
            $is_preview_from = true;
        }

        if (!$is_preview_from && $from_param !== '') {
            $path_parts = explode('/', $from_param);
        }

        if (!$is_preview_from && !empty($path_parts)) {
            // Show only the immediate parent (last segment before the person slug)
            $parent_part = end($path_parts);
            $parent_path = implode('/', $path_parts);
            $page = get_page_by_path($parent_path, OBJECT, ['page', 'post']);
            if (!$page) {
                $fallback = get_posts(['post_type' => ['page', 'post'], 'name' => $parent_part, 'posts_per_page' => 1, 'suppress_filters' => true]);
                $page = $fallback[0] ?? null;
            }

            // If Polylang is active — get the correct language version of the parent page
            if ( $page && function_exists( 'pll_get_post' ) ) {
                $localized = pll_get_post( $page->ID, $lang === 'he' ? pll_default_language() : $lang );
                if ( $localized ) {
                    $page = get_post( $localized );
                }
            }

            // Strip -en suffix from URL for clean display
            // Build clean parent URL — strip language prefix, ignore WP permalink
            $clean_parent = preg_replace( '#^(en|ar|he)/#', '', $parent_path );
            $clean_parent = preg_replace( '#-(en|ar|he)$#', '', $clean_parent );

            if (get_option('haifa_staff_english_only_site') !== '1' && $lang !== 'he' && basename($clean_parent) === 'staff') {
                $parent_url = site_url('/' . $lang . '/' . $clean_parent . '/');
            } else {
                $parent_url = site_url('/' . $clean_parent . '/');
            }

            $parent_title = $page ? $page->post_title : ucwords( str_replace( '-', ' ', urldecode( $parent_part ) ) );

            // Polylang: get translated page title
            if ($page && function_exists('pll_get_post')) {
                $localized = pll_get_post($page->ID, $lang === 'he' ? pll_default_language() : $lang);
                if ($localized) $parent_title = get_the_title($localized);
            }

            // WPML: get translated page title
            if ($page && defined('ICL_LANGUAGE_CODE')) {
                $translated_id = apply_filters('wpml_object_id', $page->ID, $page->post_type, false, $lang === 'he' ? 'he' : $lang);
                if ($translated_id && $translated_id !== $page->ID) {
                    $translated_page = get_post($translated_id);
                    if ($translated_page) $parent_title = $translated_page->post_title;
                }
            }

            // English: try page_title_en from the Elementor staff grid widget on the parent page
            if ($page) {
                $elementor_data = get_post_meta($page->ID, '_elementor_data', true);
                if ($elementor_data) {
                    $elements = json_decode($elementor_data, true);
                    $stack = $elements ?: [];
                    while (!empty($stack)) {
                        $el = array_shift($stack);
                        if (($el['widgetType'] ?? '') === 'haifa_staff_grid') {
                            $widget_title = $lang !== 'he'
                                ? ($el['settings']['page_title_en'] ?? '')
                                : ($el['settings']['page_title'] ?? '');
                            if (!empty($widget_title)) {
                                $parent_title = $widget_title;
                            }
                            break;
                        }
                        if (!empty($el['elements'])) $stack = array_merge($stack, $el['elements']);
                    }
                }
            }

            $breadcrumb_items[] = [ 'title' => $parent_title, 'url' => $parent_url ];
        }

        // Read all fields
        $pid                 = get_the_ID();

        // English (or other non-Hebrew) staff pages require real English content —
        // if none exists, redirect to the Hebrew version of this same profile
        // instead of silently rendering it with Hebrew content under an /en/ URL.
        // 302 (temporary) since this is content-dependent: if English content is
        // added later, the /en/ URL should become valid again.
        // Whether this staff member has real English content at all — used both
        // to gate the /en/ page's existence (redirect guard below) and to decide
        // whether the language-switcher link shows on the Hebrew page.
        $has_name_en = !empty(get_post_meta($pid, 'first_name_en', true))
                     && !empty(get_post_meta($pid, 'last_name_en', true));

        $en_body_fields = ['about_en', 'publications_en', 'education_en', 'academic_background_en', 'reserach_areas_en', 'prizes_en', 'media_en', 'additional_info_en'];
        $has_body_en = false;
        foreach ($en_body_fields as $f) {
            if (!empty(get_post_meta($pid, $f, true))) { $has_body_en = true; break; }
        }
        // CRIS-sourced English publications count as real content too, even
        // when the manual publications_en field itself is empty.
        if (!$has_body_en && get_post_meta($pid, 'cris_publications_source_en', true) === '1' && get_post_meta($pid, 'cris_publications_cache_en', true)) {
            $has_body_en = true;
        }

        $has_min_english = $has_name_en && $has_body_en;

        if ($lang !== 'he' && !$has_min_english) {
            $current_path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');
            $he_path      = preg_replace('#^' . preg_quote($lang, '#') . '/#', '', $current_path);
            nocache_headers();
            wp_redirect(site_url('/' . $he_path . '/'), 302);
            exit;
        }

        $first_name          = haifa_v2_lang_field('first_name', $pid, $lang);
        $last_name           = haifa_v2_lang_field('last_name', $pid, $lang);
        $title_main_val      = get_post_meta($pid, 'title_main', true);
        $title_other         = haifa_v2_lang_field('title_other', $pid, $lang);
        // English has no custom/legacy-key support in haifa_v2_title_label() (Hebrew-only),
        // so it keeps its own map here — but legacy v1 keys are added so old data still
        // resolves in English too, matching the Hebrew side below.
        $title_main_labels_en = ['mr' => 'Mr.', 'mrs' => 'Ms.', 'dr' => 'Dr.', 'prof' => 'Prof.', 'other' => '',
                                  'professor' => 'Mr.', 'associate_professor' => 'Ms.', 'assistant_professor' => 'Dr.', 'lecturer' => 'Prof.'];
        $title_main          = ($title_main_val === 'other' && !empty($title_other))
                                ? $title_other
                                : ( $lang === 'en'
                                    ? ($title_main_labels_en[$title_main_val] ?? '')
                                    // Hebrew delegates to the plugin's single source of truth —
                                    // handles v2 keys, legacy v1 keys, and custom title options.
                                    : haifa_v2_title_label((string) $title_main_val) );
        $position            = haifa_v2_lang_field('position', $pid, $lang, false);
        $context_positions = [];
        $email               = get_post_meta($pid, 'email', true);
        $external_phone      = get_post_meta($pid, 'external_phone', true);
        $inner_phone         = get_post_meta($pid, 'inner_phone', true);
        $office_room         = haifa_v2_lang_field('office_room', $pid, $lang, false);
        $office_hours        = haifa_v2_lang_field('office_hours', $pid, $lang, false);
        $staff_image         = get_post_meta($pid, 'staff_image', true);
        $about               = get_post_meta($pid, 'about', true);
        $publications        = get_post_meta($pid, 'publications', true);
        $education           = get_post_meta($pid, 'education', true);
        $academic_background = get_post_meta($pid, 'academic_background', true);
        $research_areas      = get_post_meta($pid, 'reserach_areas', true);
        $media               = get_post_meta($pid, 'media', true);
        $prizes              = get_post_meta($pid, 'prizes', true);
        $additional_info     = get_post_meta($pid, 'additional_info', true);
        $personal_website    = get_post_meta($pid, 'personal_website', true);
        $cris_website        = get_post_meta($pid, 'cris_website', true);
        $socials             = haifa_v2_get_socials($pid);
        $staff_type          = get_post_meta($pid, 'staff_type', true);
        $status              = get_post_meta($pid, 'status', true);
        $is_academic         = is_array($staff_type) && in_array('academic', $staff_type, true);

        $full_name = trim($first_name . ' ' . $last_name);
        if ($status === 'dead' && $lang !== 'en') $full_name .= ' ז"ל';

        $image_url = '';
        if (is_array($staff_image) && isset($staff_image['url'])) {
            $image_url = $staff_image['url'];
        } elseif ($staff_image) {
            $image_url = wp_get_attachment_image_url((int)$staff_image, 'full') ?: '';
        }
        if (empty($image_url)) $image_url = HAIFA_STAFF_V2_PLUGIN_URL . 'assets/default-avatar.jpg';

        $has_links = $personal_website || $cris_website;
    ?>

    <article id="post-<?php the_ID(); ?>" <?php post_class('haifa-staff-single'); ?>>

        <!-- ① STICKY TOP BAR -->
        <div class="staff-sticky-bar">
            <div class="sticky-bar-photo">
                <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($full_name); ?>">
            </div>
            <div class="sticky-bar-identity">
                <?php if (!empty($breadcrumb_items)): ?>
                    <nav class="staff-breadcrumbs" aria-label="Breadcrumb">
                        <ol class="breadcrumb-list">
                            <?php foreach ($breadcrumb_items as $item): ?>
                                <li class="breadcrumb-item">
                                    <a id="staff-breadcrumb-link" href="<?php echo esc_url($item['url']); ?>"><?php echo esc_html($item['title']); ?></a>
                                    <span class="breadcrumb-separator">›</span>
                                </li>
                            <?php endforeach; ?>
                            <li class="breadcrumb-item breadcrumb-current" aria-current="page">
                                <?php if ($title_main): echo esc_html($title_main) . ' '; endif; ?><?php echo esc_html($full_name); ?>
                            </li>
                        </ol>
                    </nav>
                <?php endif; ?>
                <h1 class="staff-name"><?php if ($title_main): echo esc_html($title_main) . ' '; endif; ?><?php echo esc_html($full_name); ?></h1>
                <?php if ($position): ?>
                    <div class="staff-title">
                        <?php echo esc_html($position); ?>
                    </div>
                <?php endif; ?>
            </div>
            <?php
            /// Check minimum English fields (same rule used for the /en/ redirect guard above)
            $has_english = get_option('haifa_staff_english_only_site') === '1' ? false : ($has_min_english ?? false);

            // Build language switcher URLs
            $current_path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');
            $he_path = preg_replace('#^en/#', '', $current_path);
            $from_qs = !empty($from_param) ? '?from=' . rawurlencode($from_param) : '';
            $he_url  = site_url('/' . $he_path . '/') . $from_qs;
            $en_url  = site_url('/en/' . $he_path . '/') . $from_qs;
        ?>
        <?php if (get_option('haifa_staff_english_only_site') !== '1' && ($lang === 'en' || $has_english)): ?>
        <div class="sticky-bar-links">
            <?php if ($lang === 'he'): ?>
                <span class="lang-current">עברית</span><span class="lang-sep"> | </span><a href="<?php echo esc_url($en_url); ?>" class="lang-alt">English</a>
            <?php else: ?>
                <a href="<?php echo esc_url($he_url); ?>" class="lang-alt">עברית</a><span class="lang-sep"> | </span><span class="lang-current">English</span>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        </div>

        <!-- ② BODY: SIDEBAR + MAIN -->
        <div class="staff-body">

            <aside class="staff-sidebar">
                <div class="staff-contact">
                    <?php if ($email): ?>
                        <div class="contact-item"><span class="contact-label"><?php echo $contact_labels['email']; ?></span><a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a></div>
                    <?php endif; ?>
                    <?php if ($external_phone): ?>
                        <?php $phone = haifa_v2_format_phone($external_phone, $lang); ?>
                        <div class="contact-item"><span class="contact-label"><?php echo $contact_labels['phone']; ?></span><a href="tel:<?php echo esc_attr($phone['href']); ?>"><?php echo esc_html($phone['display']); ?></a></div>
                    <?php endif; ?>
                    <?php if (is_university_network() && $inner_phone): ?>
                        <div class="contact-item"><span class="contact-label"><?php echo $contact_labels['ext']; ?></span><?php echo esc_html($inner_phone); ?></div>
                    <?php endif; ?>
                    <?php if ($office_room): ?>
                        <div class="contact-item"><span class="contact-label"><?php echo $contact_labels['room']; ?></span><?php echo esc_html($office_room); ?></div>
                    <?php endif; ?>
                    <?php if ($office_hours): ?>
                        <div class="contact-item"><span class="contact-label"><?php echo $contact_labels['hours']; ?></span><?php echo esc_html($office_hours); ?></div>
                    <?php endif; ?>
                    <?php if ($cris_website): ?>
                        <div class="contact-item"><a href="<?php echo esc_url($cris_website); ?>" target="_blank" rel="noopener" class="contact-label"><?php echo $lang === 'en' ? 'Research Profile (CRIS)' : 'פרופיל מחקר (CRIS)'; ?></a></div>
                    <?php endif; ?>
                    <?php if ($personal_website): ?>
                        <div class="contact-item"><a href="<?php echo esc_url($personal_website); ?>" target="_blank" rel="noopener" class="contact-label"><?php echo $contact_labels['personal']; ?></a></div>
                    <?php endif; ?>
                    <?php if (!empty($socials)): ?>
                        <?php echo haifa_v2_render_social_links($socials); ?>
                    <?php endif; ?>
                </div>
            </aside>

            <main class="staff-main">

                <?php
                $accordion_fields = ['about', 'publications', 'education', 'academic_background', 'reserach_areas', 'prizes', 'media', 'additional_info'];
                $first = true;
                foreach ($accordion_fields as $key):
                    if ($key === 'publications') {
                        $cris_on = ($lang === 'en')
                            ? get_post_meta($pid, 'cris_publications_source_en', true) === '1'
                            : get_post_meta($pid, 'cris_publications_source', true) === '1';
                        if ($cris_on) {
                            $cache_key = ($lang === 'en') ? 'cris_publications_cache_en' : 'cris_publications_cache';
                            $value = get_post_meta($pid, $cache_key, true);
                            if (!$value) $value = haifa_v2_lang_field($key, $pid, $lang, false);
                        } else {
                            $value = haifa_v2_lang_field($key, $pid, $lang, false);
                        }
                    } else {
                        $value = haifa_v2_lang_field($key, $pid, $lang, false);
                    }
                    if ($value && in_array($key, ['about', 'additional_info', 'prizes', 'media'])) {
                        $value = wpautop($value);
                    }
                    if (!$value) continue;
                ?>
                <div class="accordion-item <?php echo $first ? 'active' : ''; ?>">
                    <h2 class="accordion-header" onclick="haifaToggleAccordion(this)"><span><?php echo esc_html($section_labels[$key]); ?></span><span class="accordion-icon">▼</span></h2>
                    <div class="accordion-content"><?php echo do_shortcode(wp_kses_post($value)); ?></div>
                </div>
                <?php $first = false; endforeach; ?>

            </main>
        </div>
    </article>

    <?php endwhile; wp_reset_postdata(); ?>
</div>

<style>
body[class*="elementor-page-"]::before { content:none !important; }
.haifa-staff-single-wrapper h1, .haifa-staff-single-wrapper h2, .haifa-staff-single-wrapper h3 { font-family:inherit; font-size:inherit; font-weight:inherit; line-height:inherit; letter-spacing:normal; color:inherit; margin:0; }
.haifa-staff-single-wrapper { margin:0 auto; margin-bottom:2em; min-height: 70vh;}
.haifa-staff-single-wrapper:before {content: ''; position: fixed; height: 100vh; background: #F5F5F9; right: 0; width: 350px; pointer-events: none;}
.haifa-staff-single-wrapper[dir="ltr"].haifa-staff-single-wrapper:before { right: auto; left: 0; }
.haifa-staff-single-wrapper .staff-breadcrumbs { padding:14px 0; margin-bottom:0; position: absolute; top:1em; margin-inline-start:4em}
.haifa-staff-single-wrapper .breadcrumb-list { display:flex; flex-wrap:wrap; align-items:center; list-style:none; margin:0; padding:0; gap:6px; }
.haifa-staff-single-wrapper .breadcrumb-item { display:flex; align-items:center; gap:6px; font-size:13px; color:#666; }
.haifa-staff-single-wrapper .breadcrumb-item a { color:#0073aa; text-decoration:none; font-size:inherit; }
.haifa-staff-single-wrapper .breadcrumb-item a:hover { color:#005177; text-decoration:underline; }
.haifa-staff-single-wrapper .breadcrumb-separator { color:#000; font-size:120%}
.haifa-staff-single-wrapper .breadcrumb-current { color:#333; font-weight:600; }
.haifa-staff-single-wrapper .staff-sticky-bar { position:sticky; top:0; z-index:1; background:transparent; color:#1F3343; display:flex; align-items:center; gap:16px; padding:10px 24px; pointer-events: none;}
.haifa-staff-single-wrapper .staff-sticky-bar > * {pointer-events: auto;}
.haifa-staff-single-wrapper .staff-sticky-bar::before { content:''; position:absolute; top:0; bottom:0; left:0;right:0; height:50%; background:#1F3343; z-index: -1; margin: auto;}
.haifa-staff-single-wrapper .sticky-bar-photo { flex-shrink:0; width:auto; height:260px; overflow:hidden; border:0; }
.haifa-staff-single-wrapper .sticky-bar-photo img { width:100%; height:100%; object-fit:cover; display:block; }
.haifa-staff-single-wrapper .sticky-bar-identity { min-width:0; }
.haifa-staff-single-wrapper .sticky-bar-identity .staff-name {background: #08BBE7; color: #fff; display: inline-block; padding: 0.2em 0.5em; font-size: 40px; font-weight: 500; position: absolute; top:.4em; transform: translate(0.9em, 75%); text-align: start; line-height: 1em;}
.haifa-staff-single-wrapper[dir="ltr"] .sticky-bar-identity .staff-name {right: auto; transform: translate(-0.9em, 75%);}
.haifa-staff-single-wrapper .sticky-bar-identity .staff-title { display: inline-block; color: #fff;font-size: 24px; position: absolute; line-height:1.2em}
.haifa-staff-single-wrapper .sticky-bar-links { position:absolute; left:1em; top:15%; display:flex; align-items:center; gap:4px; background:transparent; padding:0; gap:1em}
.haifa-staff-single-wrapper[dir="ltr"] .sticky-bar-links { left:auto; right:1em; }
.haifa-staff-single-wrapper .sticky-bar-links .lang-current { color:#000; font-weight:700; font-size:15px; }
.haifa-staff-single-wrapper .sticky-bar-links .lang-sep { font-size:15px; }
.haifa-staff-single-wrapper .sticky-bar-links .lang-alt { color:#1698B9; font-weight:700; font-size:15px; text-decoration:none; }
.haifa-staff-single-wrapper .sticky-bar-links .lang-alt:hover { text-decoration:underline; }
.haifa-staff-single-wrapper .ext-link { display:inline-flex; align-items:center; justify-content:center; text-decoration:none; transition:opacity 0.2s; padding:8px 14px; border-radius:4px; line-height:0; }
.haifa-staff-single-wrapper .staff-body { display:flex; align-items:flex-start; gap:30px; margin-top:30px; }
.haifa-staff-single-wrapper .staff-sidebar { flex-shrink:0; position:sticky; top:0; align-self:flex-start; padding-inline-start:2em; width:300px}
.haifa-staff-single-wrapper .staff-contact { text-align:right; }
.haifa-staff-single-wrapper[dir="ltr"] .staff-contact { text-align:left; }
.haifa-staff-single-wrapper[dir="ltr"] .staff-main { text-align:left; padding-inline-end:0; width:100%}
.haifa-staff-single-wrapper .contact-item { margin:0 0 14px 0; font-size:15px; color:#4a4a4a; line-height:1em; }
.haifa-staff-single-wrapper .contact-item:last-child { margin-bottom:0; }
.haifa-staff-single-wrapper .contact-label { display:inline; font-weight:700; text-transform:uppercase; letter-spacing:0.5px; color:#4a4a4a; margin-inline-end:4px; }
.haifa-staff-single-wrapper span.contact-label::after { content:':'; }
.haifa-staff-single-wrapper .contact-item a { color:#4a4a4a; text-decoration:none; word-break:break-all; text-decoration:underline; font-size:inherit; }
.haifa-staff-single-wrapper .contact-item a:hover { color:#1698B9}
.haifa-staff-single-wrapper .haifa-social-links { display:flex; gap:8px; margin-top:16px; flex-wrap:wrap; justify-content:flex-start; }
.haifa-staff-single-wrapper[dir="ltr"] .haifa-social-links { justify-content:flex-start; }
.haifa-staff-single-wrapper .haifa-social-link { display:flex; align-items:center; justify-content:center; width:34px; height:34px; border-radius:4px; background:#f0f0f0; color:#37495a; transition:background .3s,color .3s; }
.haifa-staff-single-wrapper .haifa-social-link svg { width:18px; height:18px; }
.haifa-staff-single-wrapper .haifa-social-link:hover { background:#08BBE7; color:#fff; }
.haifa-staff-single-wrapper .staff-main { flex:1; min-width:0; text-align:right; max-width:1200px; width:100%; margin:auto 5%;}
.haifa-staff-single-wrapper .staff-main:before {content: ""; background: #fff; height: 200px; position: fixed; top: 0; left: 0; width: 80%; pointer-events: none;}
.haifa-staff-single-wrapper .accordion-item { overflow:hidden; transition:box-shadow 0.2s; border-bottom: 1px solid #08BBE7;}
.haifa-staff-single-wrapper .accordion-item:first-child { margin-bottom:0; border-top: 1px solid #08BBE7;}
.haifa-staff-single-wrapper .accordion-header { font-size:17px; font-weight:600; color:#333; margin:0; padding:16px 20px; cursor:pointer; display:flex; justify-content:space-between; align-items:center; transition:background 0.2s, color 0.2s; user-select:none; font-family:inherit; line-height:1.4; }
.haifa-staff-single-wrapper .accordion-header:hover { background:#eef1f4; }
.haifa-staff-single-wrapper .accordion-item.active .accordion-header { background:#D8FDFF; }
.haifa-staff-single-wrapper .accordion-icon { font-size:13px; transition:transform 0.3s ease; display:inline-block; }
.haifa-staff-single-wrapper .accordion-item.active .accordion-icon { transform:rotate(180deg); }
.haifa-staff-single-wrapper .accordion-content { max-height:0; overflow-x:auto; word-break:break-word; transition:max-height 0.4s ease, padding 0.3s ease; padding:0 20px; background:#fff; }
.haifa-staff-single-wrapper .accordion-item.active .accordion-content { max-height:300px; padding:20px; overflow:auto}
.haifa-staff-single-wrapper .accordion-content p { margin:0 0 12px 0; font-size:17px; line-height:1.7; color:#444; }
.haifa-staff-single-wrapper .accordion-content p:last-child { margin-bottom:0; }
.haifa-staff-single-wrapper .accordion-content a { color:#0066cc; text-decoration:none; }
.haifa-staff-single-wrapper .accordion-content a:hover { text-decoration:underline; }
.haifa-staff-single-wrapper .accordion-content ul, .haifa-staff-single-wrapper .accordion-content ol {margin: 0 1em; }
.haifa-staff-single-wrapper .accordion-content li { margin:6px 0; font-size:17px; line-height:1.6; color:#444; }
.haifa-staff-single-wrapper li[style*="text-align: left"], .haifa-staff-single-wrapper li[style*="text-align:left"] {direction: ltr !important;}
.haifa-staff-single-wrapper li[style*="text-align: righr"], .haifa-staff-single-wrapper li[style*="text-align:right"] {direction: rtl !important;}

.haifa-staff-single-wrapper .hsv2-cris-publications { direction: ltr; text-align: start; }

.haifa-staff-single-wrapper .accordion-solo .accordion-icon { display:none; }
.haifa-staff-single-wrapper .accordion-solo .accordion-header { cursor:default; }
.haifa-staff-single-wrapper .accordion-solo .accordion-header:hover { background:#D8FDFF; }

.haifa-staff-single-wrapper .staff-title-sep { margin:0 6px; opacity:0.6; }

.haifa-staff-en .uh-injected-english-header { display:none !important; }
.haifa-staff-en #site-header { display:block !important; }

@media (max-width:768px) {
    .haifa-staff-single-wrapper .staff-sticky-bar { padding:8px 14px; gap:10px; }
    .haifa-staff-single-wrapper .sticky-bar-photo { width:100px; height:100px; }
    .haifa-staff-single-wrapper .sticky-bar-identity .staff-name { font-size:22px; top: 0;}
    .haifa-staff-single-wrapper .sticky-bar-identity .staff-title { transform: translate(0, 50%); font-size: 12px; background: #1f3343; padding: 0 1em 1em; position:relative}
    .haifa-staff-single-wrapper .personal-link { padding:6px 10px; font-size:12px; }
    .haifa-staff-single-wrapper .staff-body { flex-direction:column; gap:20px; }
    .haifa-staff-single-wrapper .staff-sidebar { width:100%; position:static; }
    .haifa-staff-single-wrapper .staff-contact { display:flex; flex-wrap:wrap; gap:12px 24px; }
    .haifa-staff-single-wrapper .contact-item { margin:0; }
    .haifa-staff-single-wrapper:before {display:none}
    .haifa-staff-single-wrapper .staff-main { margin:auto auto;}
    .haifa-staff-single-wrapper .staff-main:before {z-index: 1; width: 100%; height: 50px;}
    .haifa-staff-single-wrapper .sticky-bar-links {height: auto; padding: 0.5em 0; top: 0;}
    .haifa-staff-single-wrapper .breadcrumb-list {display:none}
}
</style>

<script>
function haifaToggleAccordion(header) {
    const allItems = document.querySelectorAll('.accordion-item');
    if (allItems.length === 1) return;
    const item      = header.parentElement;
    const wasActive = item.classList.contains('active');
    allItems.forEach(i => i.classList.remove('active'));
    if (!wasActive) item.classList.add('active');
}

// Mark solo accordion on load
document.addEventListener('DOMContentLoaded', function() {
    const allItems = document.querySelectorAll('.accordion-item');
    if (allItems.length === 1) allItems[0].classList.add('accordion-solo');

    document.querySelectorAll('.accordion-content a').forEach(function(a) {
        a.setAttribute('target', '_blank');
        a.setAttribute('rel', 'noopener');
    });
});

function getStickyHeaderHeight() {
    // Elementor Theme Builder headers are usually a <header> tag, sometimes
    // wrapped as .elementor-location-header. The wrapper itself is rarely the
    // sticky element — Elementor applies position:fixed/sticky to an inner
    // container (e.g. .elementor-sticky--active) and adds a hidden spacer div
    // alongside it, so we look inside rather than checking the wrapper directly.
    const header = document.querySelector('header') || document.querySelector('.elementor-location-header');
    if (!header) return 0;

    let sticky = header.querySelector('.elementor-sticky--active');

    // Fallback for non-Elementor themes / other sticky implementations.
    if (!sticky) {
        const candidates = [header, ...header.querySelectorAll('*')];
        sticky = candidates.find(function(el) {
            const cs = getComputedStyle(el);
            if (cs.visibility === 'hidden' || cs.display === 'none') return false;
            return cs.position === 'fixed' || cs.position === 'sticky';
        });
    }
    if (!sticky) return 0;

    // getBoundingClientRect().bottom already reflects the real, final rendered
    // position (including any offset like the WP admin bar), so no manual math needed.
    const rect = sticky.getBoundingClientRect();
    return rect.height > 0 ? Math.max(0, rect.bottom) : 0;
}

function setSidebarTop() {
    const bar     = document.querySelector('.staff-sticky-bar');
    const sidebar = document.querySelector('.staff-sidebar');
    const headerH = getStickyHeaderHeight();

    if (bar) bar.style.top = headerH + 'px';
    if (bar && sidebar) sidebar.style.top = (headerH + bar.offsetHeight) + 'px';
}
setSidebarTop();
window.addEventListener('resize', setSidebarTop);
window.addEventListener('load', setSidebarTop);
// Elementor's own sticky-header script applies position:fixed asynchronously
// after page load (not immediately available at parse time), so a single
// run can fire too early and miss it. Retry a few times over the first
// second to catch it whenever Elementor actually finishes.
[100, 300, 600, 1000].forEach(function(delay) {
    setTimeout(setSidebarTop, delay);
});


</script>

<?php get_footer(); ?>
