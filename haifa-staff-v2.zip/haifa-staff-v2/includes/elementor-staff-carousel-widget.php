<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Elementor Staff Carousel Widget
 *
 * Image + name cards in a swipeable carousel. Independent from the staff
 * grid widget — no shared state, no shared markup.
 */
class Haifa_Staff_Carousel_Widget extends \Elementor\Widget_Base {

    public function get_name()       { return 'haifa_staff_carousel'; }
    public function get_title()      { return __( 'קרוסלת סגל', 'haifa-staff' ); }
    public function get_icon()       { return 'eicon-slider-push'; }
    public function get_categories() { return [ 'university' ]; }
    public function get_keywords()   { return [ 'staff', 'carousel', 'slider', 'team', 'סגל', 'קרוסלה' ]; }

    // =========================================================================
    // CONTROLS
    // =========================================================================
    protected function register_controls() {

        // ── Staff selection ─────────────────────────────────────────────────
        $this->start_controls_section( 'section_selection', [
            'label' => __( 'בחירת סגל', 'haifa-staff' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'selection_mode', [
            'label'   => __( 'מצב בחירה', 'haifa-staff' ),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'default' => 'auto',
            'options' => [
                'auto'   => __( 'אוטומטי (לפי סינון)', 'haifa-staff' ),
                'manual' => __( 'ידני', 'haifa-staff' ),
                'random' => __( 'רנדומלי', 'haifa-staff' ),
            ],
        ] );

        $this->add_control( 'filter_staff_type', [
            'label'     => __( 'סוג סגל', 'haifa-staff' ),
            'type'      => \Elementor\Controls_Manager::SELECT,
            'default'   => 'academic',
            'options'   => [
                ''               => __( 'הכל', 'haifa-staff' ),
                'academic'       => __( 'אקדמי', 'haifa-staff' ),
                'administrative' => __( 'מנהלי', 'haifa-staff' ),
            ],
            'condition' => [ 'selection_mode' => 'auto', 'random' ],
        ] );
        $this->add_control( 'filter_academic_type', [
            'label'     => __( 'סוג אקדמי', 'haifa-staff' ),
            'type'      => \Elementor\Controls_Manager::SELECT,
            'default'   => '',
            'options'   => [
                ''       => __( 'הכל', 'haifa-staff' ),
                'senior' => __( 'בכיר', 'haifa-staff' ),
                'junior' => __( 'זוטר', 'haifa-staff' ),
            ],
            'condition' => [ 'selection_mode' => ['auto', 'random'], 'filter_staff_type' => 'academic' ],
        ] );
        $this->add_control( 'filter_status', [
            'label'     => __( 'סטטוס', 'haifa-staff' ),
            'type'      => \Elementor\Controls_Manager::SELECT,
            'default'   => 'alive',
            'options'   => [
                ''        => __( 'הכל', 'haifa-staff' ),
                'alive'   => __( 'פעיל', 'haifa-staff' ),
                'retired' => __( 'גימלאות', 'haifa-staff' ),
                'dead'    => __( 'נפטר', 'haifa-staff' ),
            ],
            'condition' => [ 'selection_mode' => ['auto', 'random'] ],
        ] );

        $taxonomy_options = [];
        $cats = get_terms( [ 'taxonomy' => 'category', 'hide_empty' => false ] );
        $tags = get_terms( [ 'taxonomy' => 'post_tag',  'hide_empty' => false ] );
        if ( ! is_wp_error( $cats ) ) foreach ( $cats as $c ) $taxonomy_options[ 'category:' . $c->slug ] = '📁 ' . $c->name;
        if ( ! is_wp_error( $tags ) ) foreach ( $tags as $t ) $taxonomy_options[ 'tag:' . $t->slug ]      = '🏷️ ' . $t->name;
        $this->add_control( 'filter_taxonomy', [
            'label'          => __( 'קטגוריות ותגיות', 'haifa-staff' ),
            'type'           => \Elementor\Controls_Manager::SELECT2,
            'multiple'       => true,
            'options'        => $taxonomy_options,
            'default'        => [],
            'label_block'    => true,
            'select2options' => [ 'placeholder' => __( 'בחר...', 'haifa-staff' ), 'allowClear' => true ],
            'condition'      => [ 'selection_mode' => 'auto' ],
        ] );

        $this->add_control( 'only_with_photo', [
            'label'        => __( 'רק בעלי תמונה', 'haifa-staff' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'default'      => 'yes',
            'return_value' => 'yes',
            'description'  => __( 'אנשי סגל ללא תמונה לא יופיעו בבחירה האוטומטית.', 'haifa-staff' ),
            'condition'    => [ 'selection_mode' => ['auto', 'random'] ],
        ] );

        $this->add_control( 'only_with_link', [
            'label'        => __( 'רק עם קישור זמין', 'haifa-staff' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'default'      => '',
            'return_value' => 'yes',
            'description'  => __( 'רלוונטי בעיקר בתצוגת אנגלית: מסנן החוצה מי שאין לו עמוד/תוכן בשפה שנבחרה, במקום להציג אותו בלי קישור.', 'haifa-staff' ),
            'condition'    => [ 'selection_mode' => ['auto', 'random'] ],
        ] );

        $this->add_control( 'order_by', [
            'label'     => __( 'מיון', 'haifa-staff' ),
            'type'      => \Elementor\Controls_Manager::SELECT,
            'default'   => 'last_name',
            'options'   => [
                'last_name'  => __( 'שם משפחה', 'haifa-staff' ),
                'first_name' => __( 'שם פרטי', 'haifa-staff' ),
                'date'       => __( 'תאריך', 'haifa-staff' ),
                'menu_order' => __( 'סדר תפריט', 'haifa-staff' ),
                'random'     => __( 'אקראי (מתחלף בכל טעינה)', 'haifa-staff' ),
            ],
            'condition' => [ 'selection_mode' => 'auto' ],
        ] );

        $staff_choices = [];
        $all_staff = get_posts( [ 'post_type' => 'staff', 'posts_per_page' => -1, 'post_status' => 'publish', 'orderby' => 'meta_value', 'meta_key' => 'last_name', 'order' => 'ASC' ] );
        foreach ( $all_staff as $s ) {
            $fn = get_post_meta( $s->ID, 'first_name', true );
            $ln = get_post_meta( $s->ID, 'last_name', true );
            $staff_choices[ $s->ID ] = trim( $fn . ' ' . $ln ) ?: $s->post_title;
        }
        $this->add_control( 'manual_staff', [
            'label'          => __( 'בחר אנשי סגל', 'haifa-staff' ),
            'type'           => \Elementor\Controls_Manager::SELECT2,
            'multiple'       => true,
            'options'        => $staff_choices,
            'default'        => [],
            'label_block'    => true,
            'select2options' => [ 'placeholder' => __( 'בחר...', 'haifa-staff' ), 'allowClear' => true ],
            'description'    => __( 'הבחירה הידנית מתעלמת מהגדרת "רק בעלי תמונה" ומוצגת בסדר הבחירה.', 'haifa-staff' ),
            'condition'      => [ 'selection_mode' => 'manual' ],
        ] );

        $this->add_control( 'limit', [
            'label'   => __( 'מספר פריטים מקסימלי', 'haifa-staff' ),
            'type'    => \Elementor\Controls_Manager::NUMBER,
            'min'     => 5,
            'max'     => 20,
            'default' => 12,
        ] );

        $this->end_controls_section();

        // ── Display ──────────────────────────────────────────────────────────
        $this->start_controls_section( 'section_display', [
            'label' => __( 'תצוגה', 'haifa-staff' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'show_title', [
            'label'        => __( 'הצג תפקיד מתחת לשם', 'haifa-staff' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'default'      => '',
            'return_value' => 'yes',
        ] );

        $this->add_control( 'display_language', [
            'label'       => __( 'שפת התוכן', 'haifa-staff' ),
            'type'        => \Elementor\Controls_Manager::SELECT,
            'default'     => 'he',
            'options'     => [
                'he' => __( 'עברית', 'haifa-staff' ),
                'en' => __( 'אנגלית', 'haifa-staff' ),
            ],
            'description' => __( 'באנגלית, מי שאין לו תוכן/עמוד באנגלית יוצג ללא קישור (תמונה בלבד).', 'haifa-staff' ),
        ] );

        $this->add_responsive_control( 'card_width', [
            'label'      => __( 'רוחב קוביה', 'haifa-staff' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'range'      => [ 'px' => [ 'min' => 120, 'max' => 300 ] ],
            'default'    => [ 'unit' => 'px', 'size' => 220 ],
            'tablet_default' => [ 'unit' => 'px', 'size' => 180 ],
            'mobile_default' => [ 'unit' => 'px', 'size' => 140 ],
            'selectors'  => [ '{{WRAPPER}} .haifa-staff-carousel-card' => '--card-w: {{SIZE}}{{UNIT}};' ],
            'description' => __( 'עד 300px. הקוביה בפועל מתכווצת אוטומטית לפי מקום פנוי.', 'haifa-staff' ),
        ] );

        $this->add_control( 'card_gap', [
            'label'     => __( 'רווח בין קוביות', 'haifa-staff' ),
            'type'      => \Elementor\Controls_Manager::SLIDER,
            'range'     => [ 'px' => [ 'min' => 0, 'max' => 48 ] ],
            'default'   => [ 'unit' => 'px', 'size' => 16 ],
            'selectors' => [ '{{WRAPPER}} .haifa-staff-carousel-track' => 'gap: {{SIZE}}{{UNIT}};' ],
        ] );

        $this->end_controls_section();

        // ── Carousel behavior ───────────────────────────────────────────────
        $this->start_controls_section( 'section_carousel', [
            'label' => __( 'קרוסלה', 'haifa-staff' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'show_arrows', [
            'label'        => __( 'חצי ניווט', 'haifa-staff' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'default'      => 'yes',
            'return_value' => 'yes',
        ] );
        $this->add_control( 'show_dots', [
            'label'        => __( 'נקודות ניווט', 'haifa-staff' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'default'      => '',
            'return_value' => 'yes',
        ] );
        $this->add_control( 'loop', [
            'label'        => __( 'לולאה אינסופית', 'haifa-staff' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'default'      => 'yes',
            'return_value' => 'yes',
        ] );
        $this->add_control( 'autoplay', [
            'label'        => __( 'נגינה אוטומטית', 'haifa-staff' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'default'      => '',
            'return_value' => 'yes',
        ] );
        $this->add_control( 'autoplay_speed', [
            'label'     => __( 'מהירות (מילישניות)', 'haifa-staff' ),
            'type'      => \Elementor\Controls_Manager::NUMBER,
            'min'       => 1500,
            'max'       => 10000,
            'step'      => 500,
            'default'   => 4000,
            'condition' => [ 'autoplay' => 'yes' ],
        ] );

        $this->end_controls_section();
    }

    // =========================================================================
    // QUERY
    // =========================================================================
    private function has_valid_link( $staff_id, $lang ): bool {
        if ( $lang !== 'en' ) return true;
        return ! empty( get_post_meta( $staff_id, 'first_name_en', true ) )
            && ! empty( get_post_meta( $staff_id, 'last_name_en', true ) );
    }

    private function get_staff_ids( array $settings ): array {
        $limit = max( 5, min( 20, (int) ( $settings['limit'] ?? 12 ) ) );
        $lang  = ( $settings['display_language'] ?? 'he' ) === 'en' ? 'en' : 'he';

        $mode = $settings['selection_mode'] ?? 'auto';

        if ( $mode === 'manual' ) {
            $ids = array_map( 'intval', $settings['manual_staff'] ?? [] );
            return array_slice( $ids, 0, $limit );
        }

        $only_with_link  = ( $settings['only_with_link']  ?? '' ) === 'yes';
        $only_with_photo = ( $settings['only_with_photo'] ?? '' ) === 'yes';
        $needs_full_scan = $only_with_photo || $only_with_link;

        $args = [
            'post_type'      => 'staff',
            'posts_per_page' => $needs_full_scan ? -1 : $limit,
            'post_status'    => 'publish',
            'meta_query'     => [ 'relation' => 'AND' ],
        ];

        if ( ! empty( $settings['filter_staff_type'] ) ) {
            $args['meta_query'][] = [ 'key' => 'staff_type', 'value' => $settings['filter_staff_type'], 'compare' => 'LIKE' ];
        }
        if ( ! empty( $settings['filter_academic_type'] ) ) {
            $args['meta_query'][] = [ 'key' => 'staff_academic_type', 'value' => $settings['filter_academic_type'], 'compare' => '=' ];
        }
        if ( ! empty( $settings['filter_status'] ) ) {
            $args['meta_query'][] = [ 'key' => 'status', 'value' => $settings['filter_status'], 'compare' => '=' ];
        }

        if ( ! empty( $settings['filter_taxonomy'] ) ) {
            $cat_terms = $tag_terms = [];
            foreach ( (array) $settings['filter_taxonomy'] as $val ) {
                if ( strpos( $val, 'category:' ) === 0 ) $cat_terms[] = substr( $val, 9 );
                if ( strpos( $val, 'tag:' ) === 0 )       $tag_terms[] = substr( $val, 4 );
            }
            $args['tax_query'] = [ 'relation' => 'OR' ];
            if ( $cat_terms ) $args['tax_query'][] = [ 'taxonomy' => 'category', 'field' => 'slug', 'terms' => $cat_terms, 'operator' => 'IN' ];
            if ( $tag_terms )  $args['tax_query'][] = [ 'taxonomy' => 'post_tag',  'field' => 'slug', 'terms' => $tag_terms,  'operator' => 'IN' ];
        }

        if ( $mode === 'random' ) {
            $args['orderby'] = 'rand';
        } else {
            $order_by = $settings['order_by'] ?? 'last_name';
            if ( $order_by === 'random' ) {
                $args['orderby'] = 'rand';
            } elseif ( in_array( $order_by, [ 'last_name', 'first_name' ], true ) ) {
                $args['meta_key'] = $order_by;
                $args['orderby']  = 'meta_value';
                $args['order']    = 'ASC';
            } else {
                $args['orderby'] = $order_by;
                $args['order']   = 'ASC';
            }
        }

        $query = new \WP_Query( $args );
        $ids   = wp_list_pluck( $query->posts, 'ID' );

        return $this->apply_post_filters( $ids, $only_with_photo, $only_with_link, $lang, $limit, $needs_full_scan );
    }

    private function apply_post_filters( array $ids, bool $only_with_photo, bool $only_with_link, string $lang, int $limit, bool $needs_full_scan ): array {
        if ( $only_with_photo ) {
            $ids = array_values( array_filter( $ids, function( $id ) {
                $img_id = get_post_meta( $id, 'staff_image', true );
                return is_numeric( $img_id ) && $img_id > 0 && wp_attachment_is_image( $img_id );
            } ) );
        }
        if ( $only_with_link ) {
            $ids = array_values( array_filter( $ids, function( $id ) use ( $lang ) {
                return $this->has_valid_link( $id, $lang );
            } ) );
        }
        if ( $needs_full_scan ) {
            $ids = array_slice( $ids, 0, $limit );
        }
        return $ids;
    }
    // =========================================================================
    // RENDER
    // =========================================================================
    protected function render() {
        $settings = $this->get_settings_for_display();
        $ids      = $this->get_staff_ids( $settings );
        if ( empty( $ids ) ) {
            if ( \Elementor\Plugin::instance()->editor->is_edit_mode() ) {
                echo '<p style="padding:20px;text-align:center;color:#999">' . esc_html__( 'לא נמצא סגל תואם לסינון שנבחר.', 'haifa-staff' ) . '</p>';
            }
            return;
        }

        $show_title  = ( $settings['show_title']  ?? '' ) === 'yes';
        $show_arrows = ( $settings['show_arrows'] ?? '' ) === 'yes';
        $show_dots   = ( $settings['show_dots']   ?? '' ) === 'yes';
        $loop        = ( $settings['loop']        ?? '' ) === 'yes';
        $autoplay    = ( $settings['autoplay']    ?? '' ) === 'yes';
        $speed       = (int) ( $settings['autoplay_speed'] ?? 4000 );
        $widget_id   = 'haifa-carousel-' . $this->get_id();
        ?>
        <div class="haifa-staff-carousel-widget" id="<?php echo esc_attr( $widget_id ); ?>"
             data-loop="<?php echo $loop ? '1' : '0'; ?>"
             data-autoplay="<?php echo $autoplay ? '1' : '0'; ?>"
             data-speed="<?php echo esc_attr( $speed ); ?>">
            <div class="haifa-staff-carousel-viewport">
                <div class="haifa-staff-carousel-track">
                    <?php $lang = ( $settings['display_language'] ?? 'he' ) === 'en' ? 'en' : 'he'; ?>
                    <?php foreach ( $ids as $staff_id ) : $this->render_card( $staff_id, $show_title, $lang ); endforeach; ?>
                </div>
            </div>
            <?php if ( $show_arrows ) : ?>
                <button type="button" class="haifa-staff-carousel-arrow haifa-staff-carousel-prev" aria-label="<?php esc_attr_e( 'הקודם', 'haifa-staff' ); ?>">&#8250;</button>
                <button type="button" class="haifa-staff-carousel-arrow haifa-staff-carousel-next" aria-label="<?php esc_attr_e( 'הבא', 'haifa-staff' ); ?>">&#8249;</button>
            <?php endif; ?>
            <?php if ( $show_dots ) : ?>
                <div class="haifa-staff-carousel-dots"></div>
            <?php endif; ?>
        </div>

        <style>
        .haifa-staff-carousel-widget{position:relative;direction:rtl}
        .haifa-staff-carousel-viewport{overflow:hidden}
        .haifa-staff-carousel-track{display:flex;gap:16px;transition:transform .4s ease}
        .haifa-staff-carousel-card{--card-w:220px;flex:0 0 auto;width:var(--card-w);max-width:300px}
        .haifa-staff-carousel-card a{display:block;text-decoration:none;color:inherit}
        .haifa-staff-carousel-card .hsc-img{width:100%;aspect-ratio:1/1;object-fit:cover;background:#eee;display:block}
        .haifa-staff-carousel-card .hsc-caption{background:#f4f4f4;padding:10px 8px;text-align:center;margin-top:-4px}
        .haifa-staff-carousel-card .hsc-name{font-size:15px;font-weight:600;margin:0}
        .haifa-staff-carousel-card .hsc-title{font-size:13px;color:#666;margin:2px 0 0}
        .haifa-staff-carousel-arrow{position:absolute;top:50%;transform:translateY(-50%);width:36px;height:36px;border-radius:0;border:none;background:rgba(0,0,0,.55);color:#fff;font-size:20px;cursor:pointer;display:flex;align-items:center;justify-content:center;z-index:2}
        .haifa-staff-carousel-prev{right:-8px}
        .haifa-staff-carousel-next{left:-8px}
        .haifa-staff-carousel-arrow:disabled{opacity:.3;cursor:default}
        .haifa-staff-carousel-dots{display:flex;justify-content:center;gap:6px;margin-top:12px}
        .haifa-staff-carousel-dots span{width:8px;height:8px;border-radius:50%;background:#ccc;cursor:pointer}
        .haifa-staff-carousel-dots span.active{background:#666}
        </style>
        <?php
    }

    private function render_card( $staff_id, $show_title, $lang = 'he' ) {
        if ( $lang === 'en' ) {
            $first_name = get_post_meta( $staff_id, 'first_name_en', true );
            $last_name  = get_post_meta( $staff_id, 'last_name_en',  true );
            $position   = get_post_meta( $staff_id, 'position_en',   true );
        } else {
            $first_name = get_post_meta( $staff_id, 'first_name', true );
            $last_name  = get_post_meta( $staff_id, 'last_name',  true );
            $position   = get_post_meta( $staff_id, 'position',   true );
        }
        $full_name = trim( $first_name . ' ' . $last_name );
        if ( $full_name === '' ) {
            $full_name = trim( get_post_meta( $staff_id, 'first_name', true ) . ' ' . get_post_meta( $staff_id, 'last_name', true ) );
        }
        $img_id    = get_post_meta( $staff_id, 'staff_image', true );
        $image_url = is_numeric( $img_id ) ? wp_get_attachment_image_url( $img_id, 'medium' ) : '';
        if ( empty( $image_url ) ) $image_url = HAIFA_STAFF_V2_PLUGIN_URL . 'assets/default-avatar.jpg';
        $has_link  = $this->has_valid_link( $staff_id, $lang );
        $permalink = $has_link ? get_permalink( $staff_id ) : '';
        ?>
        <div class="haifa-staff-carousel-card">
            <?php if ( $has_link ) : ?>
            <a href="<?php echo esc_url( $permalink ); ?>">
            <?php endif; ?>
                <img class="hsc-img" src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $full_name ); ?>" loading="lazy" />
                <div class="hsc-caption">
                    <p class="hsc-name"><?php echo esc_html( $full_name ); ?></p>
                    <?php if ( $show_title && $position ) : ?>
                        <p class="hsc-title"><?php echo esc_html( $position ); ?></p>
                    <?php endif; ?>
                </div>
            <?php if ( $has_link ) : ?>
            </a>
            <?php endif; ?>
        </div>
        <?php
    }

    // =========================================================================
    // FRONTEND JS — track slider, no external library
    // =========================================================================
    public function __construct( $data = [], $args = null ) {
        parent::__construct( $data, $args );
        add_action( 'elementor/editor/after_enqueue_scripts', function() { ?>
            <style>
            body.haifa-staff-carousel-editing .elementor-tab-control-advanced { display:none !important; }
            </style>
            <script>
            (function(){
                'use strict';
                function initPanelScope(){
                    if(typeof jQuery==='undefined'||typeof elementor==='undefined'){setTimeout(initPanelScope,100);return;}
                    function updateScope(){
                        var isCarousel=false;
                        try{
                            var currentView=elementor.getPanelView().getCurrentPageView();
                            var model=currentView&&currentView.model;
                            var widgetType=model&&model.get?model.get('widgetType'):null;
                            isCarousel=(widgetType==='haifa_staff_carousel');
                        }catch(e){}
                        document.body.classList.toggle('haifa-staff-carousel-editing',isCarousel);
                    }
                    jQuery(document).ready(function(){
                        [500,1000,2000,3000,4000].forEach(function(t){setTimeout(updateScope,t);});
                        if(elementor.channels&&elementor.channels.editor){
                            elementor.channels.editor.on('section:activated',updateScope);
                        }
                        var panel=document.querySelector('#elementor-panel-content-wrapper');
                        if(panel){new MutationObserver(updateScope).observe(panel,{childList:true,subtree:true,attributes:true,attributeFilter:['style','class']});}
                    });
                }
                initPanelScope();
            })();
            </script>
        <?php } );
        add_action( 'wp_footer', function() {
            static $printed = false;
            if ( $printed ) return;
            $printed = true;
            ?>
            <script>
            (function(){
                'use strict';
                function initCarousel(root){
                    if(root.dataset.hscInit) return;
                    root.dataset.hscInit='1';
                    var viewport=root.querySelector('.haifa-staff-carousel-viewport');
                    var track=root.querySelector('.haifa-staff-carousel-track');
                    var cards=Array.prototype.slice.call(track.children);
                    var prev=root.querySelector('.haifa-staff-carousel-prev');
                    var next=root.querySelector('.haifa-staff-carousel-next');
                    var dotsWrap=root.querySelector('.haifa-staff-carousel-dots');
                    var loop=root.dataset.loop==='1';
                    var autoplay=root.dataset.autoplay==='1';
                    var speed=parseInt(root.dataset.speed,10)||4000;
                    var index=0,timer=null;

                    function perView(){
                        var cw=cards[0]?cards[0].getBoundingClientRect().width:220;
                        var gap=parseFloat(getComputedStyle(track).gap)||16;
                        return Math.max(1,Math.floor((viewport.getBoundingClientRect().width+gap)/(cw+gap)));
                    }
                    function maxIndex(){return Math.max(0,cards.length-perView());}
                    function update(){
                        var cw=cards[0]?cards[0].getBoundingClientRect().width:220;
                        var gap=parseFloat(getComputedStyle(track).gap)||16;
                        var offset=index*(cw+gap);
                        track.style.transform='translateX('+offset+'px)';
                        if(prev) prev.disabled=!loop&&index<=0;
                        if(next) next.disabled=!loop&&index>=maxIndex();
                        if(dotsWrap){
                            Array.prototype.forEach.call(dotsWrap.children,function(d,i){d.classList.toggle('active',i===index);});
                        }
                    }
                    function goTo(i){
                        var mi=maxIndex();
                        if(loop){ if(i<0) i=mi; else if(i>mi) i=0; }
                        else { i=Math.min(Math.max(i,0),mi); }
                        index=i; update();
                    }
                    if(dotsWrap){
                        for(var i=0;i<=maxIndex();i++){
                            var d=document.createElement('span');
                            d.addEventListener('click',(function(idx){return function(){goTo(idx);resetAutoplay();};})(i));
                            dotsWrap.appendChild(d);
                        }
                    }
                    if(prev) prev.addEventListener('click',function(){goTo(index-1);resetAutoplay();});
                    if(next) next.addEventListener('click',function(){goTo(index+1);resetAutoplay();});

                    var startX=null;
                    track.addEventListener('touchstart',function(e){startX=e.touches[0].clientX;},{passive:true});
                    track.addEventListener('touchend',function(e){
                        if(startX===null) return;
                        var dx=e.changedTouches[0].clientX-startX;
                        if(Math.abs(dx)>40){ goTo(index+(dx<0?1:-1)); resetAutoplay(); }
                        startX=null;
                    },{passive:true});

                    function startAutoplay(){ if(autoplay) timer=setInterval(function(){goTo(index+1);},speed); }
                    function resetAutoplay(){ if(timer){clearInterval(timer);startAutoplay();} }

                    window.addEventListener('resize',function(){ index=Math.min(index,maxIndex()); update(); });
                    update();
                    startAutoplay();
                }
                function initAll(){
                    document.querySelectorAll('.haifa-staff-carousel-widget').forEach(initCarousel);
                }
                initAll();
                if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',initAll);
                try{if(typeof elementorFrontend!=='undefined'){
                    elementorFrontend.hooks.addAction('frontend/element_ready/widget',function($scope){
                        try{if($scope&&$scope.find&&$scope.find('.haifa-staff-carousel-widget').length) setTimeout(initAll,50);}catch(e){}
                    });
                }}catch(e){}
            })();
            </script>
            <?php
        } );
    }
}
