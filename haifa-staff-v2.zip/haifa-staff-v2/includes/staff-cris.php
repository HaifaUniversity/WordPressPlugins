<?php
/**
 * CRIS publications integration.
 *
 * Pulls a staff member's publication list from the university CRIS portal
 * (Elsevier Pure) via its per-person RSS feed, converts each entry into a
 * clean <li>, caches the resulting <ul> in post meta, and refreshes the
 * cache once daily through WP-Cron.
 *
 * Meta keys used:
 *   cris_website                  — source URL (always the /en/ person page)
 *   cris_publications_source      — "grab from CRIS" toggle, Hebrew tab
 *   cris_publications_source_en   — "grab from CRIS" toggle, English tab
 *   cris_publications_cache       — cached <ul> HTML, Hebrew
 *   cris_publications_cache_en    — cached <ul> HTML, English
 *   cris_publications_updated     — last successful fetch (unix timestamp)
 *
 * @package haifa-staff-v2
 */

if ( ! defined( 'WPINC' ) ) { die; }

/**
 * Convert a single CRIS RSS <description> block into an <li>.
 *
 * The feed's description is Pure's own pre-rendered citation HTML (entity
 * encoded). We keep the title as the only link (bold), flatten every other
 * link to plain text, and drop Pure's title heading + type breadcrumb.
 *
 * @param string $description_raw Raw (entity-encoded) description from the feed.
 * @return string A single <li>…</li>, or '' if the block can't be parsed.
 */
function haifa_v2_parse_cris_item_html($description_raw) {
    $html = html_entity_decode($description_raw, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    if (!$html) return '';

    libxml_use_internal_errors(true);
    $dom = new DOMDocument();
    $dom->loadHTML('<?xml encoding="utf-8"?>' . $html, LIBXML_NOERROR | LIBXML_NOWARNING);
    libxml_clear_errors();

    $xpath = new DOMXPath($dom);
    $title_node = $xpath->query('//h3[contains(@class,"title")]//a')->item(0);
    if (!$title_node) return '';

    $title_text = trim($title_node->textContent);
    $title_href = $title_node->getAttribute('href');

    $root = $dom->getElementsByTagName('div')->item(0);
    if (!$root) return '';

    // Strip ALL links from the details block — only the title stays clickable.
    foreach (iterator_to_array($xpath->query('.//a', $root)) as $a) {
        $text = $dom->createTextNode($a->textContent);
        $a->parentNode->replaceChild($text, $a);
    }

    // Remove Pure's own title heading and the type breadcrumb line.
    foreach ($xpath->query('.//h3[contains(@class,"title")]', $root) as $node) $node->parentNode->removeChild($node);
    foreach ($xpath->query('.//p[contains(@class,"type")]', $root) as $node) $node->parentNode->removeChild($node);

    $details_html = '';
    foreach ($root->childNodes as $child) {
        $details_html .= $dom->saveHTML($child);
    }
    $details_html = trim($details_html);

    return sprintf(
        '<li><strong><a href="%s" target="_blank" rel="noopener">%s</a></strong>%s</li>',
        esc_url($title_href),
        esc_html($title_text),
        $details_html ? ', ' . $details_html : ''
    );
}

/**
 * Fetch and parse a person's full CRIS publication list.
 *
 * Pure's RSS endpoint is paginated exactly like the HTML portal page (it's
 * the same search results, just a different format), so a single request
 * only returns one page's worth of items (confirmed: 50 per page on this
 * installation). We loop pages until an empty one comes back, so staff with
 * more publications than fit on one page still get everything. We also pin
 * the ordering explicitly — Pure's default RSS order is "date added to
 * Pure", not publication date, which can otherwise make the feed disagree
 * with what the portal page shows.
 *
 * @param string $cris_url The staff member's CRIS person-page URL.
 * @return string|false A <ul class="hsv2-cris-publications">…</ul>, or false on
 *                      empty/failed fetch (caller keeps any existing cache).
 */
function haifa_v2_fetch_cris_publications($cris_url) {
    if (!$cris_url) return false;
    if (!function_exists('fetch_feed')) require_once ABSPATH . WPINC . '/feed.php';

    $base_url = trailingslashit(untrailingslashit($cris_url) . '/publications');
    $li_list = [];
    $seen_hrefs = [];
    $page = 0;
    $max_pages = 20; // safety cap — no real person has 20 pages of output

    do {
        $feed_url = add_query_arg([
            'format'     => 'rss',
            'ordering'   => 'publicationYearThenTitle',
            'descending' => 'true',
            'page'       => $page,
        ], $base_url);

        $feed = fetch_feed($feed_url);
        if (is_wp_error($feed)) break;

        $items = $feed->get_items(0, $feed->get_item_quantity(0));
        if (!$items) break;

        foreach ($items as $item) {
            $desc = $item->get_item_tags('', 'description');
            $desc_raw = $desc[0]['data'] ?? $item->get_description();
            $li = haifa_v2_parse_cris_item_html($desc_raw);
            if (!$li) continue;

            // Dedupe by the title link, in case ordering ties shift an item
            // across the page boundary between requests.
            if (preg_match('/href="([^"]+)"/', $li, $m)) {
                if (isset($seen_hrefs[$m[1]])) continue;
                $seen_hrefs[$m[1]] = true;
            }
            $li_list[] = $li;
        }

        $page++;
    } while (count($items) > 0 && $page < $max_pages);

    if (!$li_list) return false;
    return '<ul class="hsv2-cris-publications">' . implode('', $li_list) . '</ul>';
}

/**
 * Refresh cached CRIS publications for every staff member with the feature on.
 *
 * Runs daily via WP-Cron and on demand from the settings page. Hebrew and
 * English currently share the same feed (cris_website is always the /en/ URL),
 * so both caches receive identical content; kept separate so the two tabs can
 * be toggled independently and to allow per-language feeds in future.
 */
function haifa_v2_refresh_cris_publications() {
    $staff_ids = get_posts([
        'post_type'      => 'staff',
        'posts_per_page' => -1,
        'fields'         => 'ids',
        'meta_query'     => [
            'relation' => 'OR',
            ['key' => 'cris_publications_source',    'value' => '1'],
            ['key' => 'cris_publications_source_en', 'value' => '1'],
        ],
    ]);

    foreach ($staff_ids as $post_id) {
        $cris_url = get_post_meta($post_id, 'cris_website', true);
        if (!$cris_url) continue;

        $he_on = get_post_meta($post_id, 'cris_publications_source', true) === '1';
        $en_on = get_post_meta($post_id, 'cris_publications_source_en', true) === '1';

        if ($he_on) {
            $result = haifa_v2_fetch_cris_publications($cris_url);
            if ($result) {
                update_post_meta($post_id, 'cris_publications_cache', $result);
                update_post_meta($post_id, 'cris_publications_updated', current_time('timestamp'));
            }
        }
        if ($en_on) {
            $result = haifa_v2_fetch_cris_publications($cris_url);
            if ($result) {
                update_post_meta($post_id, 'cris_publications_cache_en', $result);
                update_post_meta($post_id, 'cris_publications_updated', current_time('timestamp'));
            }
        }
    }
}
add_action('haifa_v2_cris_cron_hook', 'haifa_v2_refresh_cris_publications');
