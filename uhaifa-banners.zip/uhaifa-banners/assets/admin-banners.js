/* globals wp, jQuery */
jQuery( function ( $ ) {
    'use strict';

    // Field-name prefix for each repeater, keyed by its container id — lets
    // the generic renumber/add/remove/move logic below serve both the image
    // slides repeater and the dynamic items repeater without duplicating code.
    var REPEATER_PREFIX = {
        'uhaifa-slides-repeater':        'uhaifa_slides',
        'uhaifa-dynamic-items-repeater': 'uhaifa_dynamic_items',
    };

    // Advisory-only recommendations per picker field. Never blocks save —
    // just shows a note under the picker so editors can catch a wrong or
    // oversized image before it hits real visitors.
    var MIN_DIMENSIONS = {
        desktop:       { width: 1600, height: 400, label: 'שולחן עבודה' },
        image_desktop: { width: 1600, height: 400, label: 'שולחן עבודה' },
        mobile:        { width: 640,  height: 800, label: 'נייד' },
        image_mobile:  { width: 640,  height: 800, label: 'נייד' }
    };
    var MAX_RECOMMENDED_FILE_SIZE = 800 * 1024; // 800KB

    // ── Renumber a repeater's rows' name="prefix[N][...]" + data-index ─────
    // Called after any add/remove/reorder so indices stay contiguous and in
    // DOM order — this is what the PHP side relies on when saving. Works for
    // either repeater since the prefix is looked up from the container's id.
    function renumberRepeater( $repeater ) {
        var prefix = REPEATER_PREFIX[ $repeater.attr( 'id' ) ];
        if ( ! prefix ) return;

        $repeater.children( '.uhaifa-slide-row' ).each( function ( i, row ) {
            var $row = $( row );
            $row.attr( 'data-index', i );
            $row.find( '[name]' ).each( function () {
                var name    = $( this ).attr( 'name' );
                var newName = name.replace( /^[a-z_]+\[[^\]]*\]/, prefix + '[' + i + ']' );
                $( this ).attr( 'name', newName );
            } );
        } );

        // Hide the remove button when only one row remains — at least one
        // row must always exist so there's something to fill in.
        var $rows = $repeater.children( '.uhaifa-slide-row' );
        $rows.removeClass( 'uhaifa-slide-row-only' );
        if ( $rows.length === 1 ) {
            $rows.addClass( 'uhaifa-slide-row-only' );
        }
    }

    // ── Add slide (image repeater) ──────────────────────────────────────────
    $( '#uhaifa-add-slide' ).on( 'click', function ( e ) {
        e.preventDefault();
        var $repeater = $( '#uhaifa-slides-repeater' );
        var template  = $( '#uhaifa-slide-row-template' ).html();
        var html      = template.replace( /__INDEX__/g, 'new' );
        $repeater.append( html );
        renumberRepeater( $repeater );
    } );

    // ── Add item (dynamic items repeater) ───────────────────────────────────
    // Which template is used depends on the currently-selected background
    // mode, since per_item rows carry background fields that shared rows don't.
    $( '#uhaifa-add-dynamic-item' ).on( 'click', function ( e ) {
        e.preventDefault();
        var $repeater = $( '#uhaifa-dynamic-items-repeater' );
        var bgMode    = $( 'input[name="uhaifa_dynamic_bg_mode"]:checked' ).val() || 'shared';
        var template  = $( '#uhaifa-dynamic-item-template-' + bgMode ).html();
        var html      = template.replace( /__INDEX__/g, 'new' );
        $repeater.append( html );
        renumberRepeater( $repeater );
    } );

    // ── Remove row (either repeater) ────────────────────────────────────────
    $( document ).on( 'click', '.uhaifa-slide-remove', function ( e ) {
        e.preventDefault();
        var $row      = $( this ).closest( '.uhaifa-slide-row' );
        var $repeater = $row.closest( '.uhaifa-slides-repeater' );
        if ( $repeater.children( '.uhaifa-slide-row' ).length <= 1 ) return; // never remove the last row
        $row.remove();
        renumberRepeater( $repeater );
    } );

    // ── Move up / down (either repeater) ────────────────────────────────────
    $( document ).on( 'click', '.uhaifa-slide-move-up', function ( e ) {
        e.preventDefault();
        var $row      = $( this ).closest( '.uhaifa-slide-row' );
        var $repeater = $row.closest( '.uhaifa-slides-repeater' );
        var $prev     = $row.prev( '.uhaifa-slide-row' );
        if ( $prev.length ) {
            $row.insertBefore( $prev );
            renumberRepeater( $repeater );
        }
    } );

    $( document ).on( 'click', '.uhaifa-slide-move-down', function ( e ) {
        e.preventDefault();
        var $row      = $( this ).closest( '.uhaifa-slide-row' );
        var $repeater = $row.closest( '.uhaifa-slides-repeater' );
        var $next     = $row.next( '.uhaifa-slide-row' );
        if ( $next.length ) {
            $row.insertAfter( $next );
            renumberRepeater( $repeater );
        }
    } );

    renumberRepeater( $( '#uhaifa-slides-repeater' ) );        // normalize state on page load
    renumberRepeater( $( '#uhaifa-dynamic-items-repeater' ) );

    // ── Banner type toggle (image vs dynamic) ───────────────────────────────
    $( 'input[name="uhaifa_banner_type"]' ).on( 'change', function () {
        var isDynamic = $( this ).val() === 'dynamic' && this.checked;
        if ( ! this.checked ) return; // only react to the radio that became checked
        $( '#uhaifa-section-image' ).toggle( ! isDynamic );
        $( '#uhaifa-section-dynamic' ).toggle( isDynamic );
    } );

    // ── Dynamic background-mode toggle (shared / per_item / multi) ─────────
    $( 'input[name="uhaifa_dynamic_bg_mode"]' ).on( 'change', function () {
        if ( ! this.checked ) return;
        var bgMode    = $( this ).val();
        var $repeater = $( '#uhaifa-dynamic-items-repeater' );

        $( '#uhaifa-shared-bg-fields' ).toggle( bgMode === 'shared' );
        $( '#uhaifa-static-text-fields' ).toggle( bgMode === 'multi' );

        // Existing rows' per-item background/text blocks toggle too — the
        // fields stay in the DOM (and keep whatever was entered) either way,
        // they're just hidden when not relevant to the current mode.
          $repeater.find( '.uhaifa-dynamic-item-bg' ).toggle( bgMode === 'per_item' || bgMode === 'multi' );
        $repeater.find( '.uhaifa-dynamic-item-text' ).toggle( bgMode !== 'multi' );
        $repeater.attr( 'data-bg-mode', bgMode );
    } );

    // ── Evergreen (dateless fallback) toggle ────────────────────────────────
    $( '#uhaifa-evergreen-checkbox' ).on( 'change', function () {
        $( '#uhaifa-dates-row' ).toggle( ! this.checked );
    } );

    // ── Shared: apply a chosen/uploaded attachment to a picker's preview ───
    // meta ({width, height, filesizeInBytes}) is optional — used for the
    // advisory size check only, missing values are simply skipped.
    function applyAttachmentToPicker( $picker, attId, attUrl, meta ) {
        var $input       = $picker.find( '.uhaifa-slide-image-input' );
        var $img         = $picker.find( '.uhaifa-preview-img' );
        var $placeholder = $picker.find( '.uhaifa-image-placeholder' );
        var imgTag       = '<img src="' + attUrl + '" class="uhaifa-preview-img">';

        $input.val( attId );

        if ( $img.length ) {
            $img.attr( 'src', attUrl );
        } else {
            $placeholder.replaceWith( imgTag );
        }

        $picker.addClass( 'has-image' );
        $picker.removeClass( 'uhaifa-image-error' );
        $picker.find( '.uhaifa-field-error-msg' ).remove();

        checkImageSize( $picker, meta || {} );
    }

    /** Advisory-only — shows a note under the picker, never blocks. */
    function checkImageSize( $picker, meta ) {
        var field    = $picker.data( 'field' );
        var rules    = MIN_DIMENSIONS[ field ];
        var warnings = [];

        if ( rules && meta.width && meta.height
             && ( meta.width < rules.width || meta.height < rules.height ) ) {
            warnings.push(
                'רזולוציה נמוכה מהמומלץ ל' + rules.label + ' ('
                + meta.width + '×' + meta.height + 'px, מומלץ לפחות '
                + rules.width + '×' + rules.height + 'px)'
            );
        }

        if ( meta.filesizeInBytes && meta.filesizeInBytes > MAX_RECOMMENDED_FILE_SIZE ) {
            warnings.push(
                'משקל הקובץ גדול מהמומלץ ('
                + Math.round( meta.filesizeInBytes / 1024 ) + 'KB, מומלץ עד '
                + Math.round( MAX_RECOMMENDED_FILE_SIZE / 1024 ) + 'KB לטעינה מהירה)'
            );
        }

        var $warning = $picker.find( '.uhaifa-image-size-warning' );
        if ( warnings.length ) {
            $warning.html( warnings.join( '<br>' ) ).show();
        } else {
            $warning.empty().hide();
        }
    }

    // ── Media image picker — click to open the library (scoped to its row,
    // works for image slides, shared dynamic background, and per-item
    // dynamic backgrounds alike since they all share .uhaifa-image-picker) ─
    $( document ).on( 'click', '.uhaifa-pick-image, .uhaifa-replace-image', function ( e ) {
        e.preventDefault();

        var $btn    = $( this );
        var $picker = $btn.closest( '.uhaifa-image-picker' );

        var frame = wp.media( {
            title   : 'Select Banner Image',
            button  : { text: 'Use this image' },
            multiple: false,
        } );

        frame.on( 'select', function () {
            var att = frame.state().get( 'selection' ).first().toJSON();
            applyAttachmentToPicker( $picker, att.id, att.url, {
                width           : att.width,
                height          : att.height,
                filesizeInBytes : att.filesizeInBytes
            } );
        } );

        frame.open();
    } );

    // ── Media image picker — drag & drop a file straight onto the box ──────
    // Uses the same ajax action ('upload-attachment') the classic media
    // modal itself uses, so no custom PHP endpoint is required.
    $( document ).on( 'dragover', '.uhaifa-image-picker', function ( e ) {
        e.preventDefault();
        e.stopPropagation();
        $( this ).addClass( 'is-dragover' );
    } );

    $( document ).on( 'dragleave', '.uhaifa-image-picker', function ( e ) {
        e.preventDefault();
        e.stopPropagation();
        $( this ).removeClass( 'is-dragover' );
    } );

    $( document ).on( 'drop', '.uhaifa-image-picker', function ( e ) {
        e.preventDefault();
        e.stopPropagation();

        var $picker = $( this ).removeClass( 'is-dragover' );
        var files   = e.originalEvent.dataTransfer && e.originalEvent.dataTransfer.files;
        if ( ! files || ! files.length ) return;

        var file = files[ 0 ];
        if ( file.type.indexOf( 'image/' ) !== 0 ) {
            window.alert( 'ניתן לגרור קבצי תמונה בלבד.' );
            return;
        }

        var uploadNonce = ( window._wpPluploadSettings
            && window._wpPluploadSettings.defaults
            && window._wpPluploadSettings.defaults.multipart_params )
            ? window._wpPluploadSettings.defaults.multipart_params._wpnonce
            : '';

        if ( ! uploadNonce ) {
            console.error( 'uhaifa-banners: no upload nonce found on window._wpPluploadSettings — drag-drop upload will fail auth.' );
        }

        var formData = new FormData();
        formData.append( 'action', 'upload-attachment' );
        formData.append( '_wpnonce', uploadNonce );
        formData.append( 'async-upload', file );
        formData.append( 'name', file.name );

        $picker.addClass( 'is-uploading' );

        $.ajax( {
            url        : ajaxurl,
            type       : 'POST',
            data       : formData,
            processData: false,
            contentType: false,
        } ).done( function ( response ) {
            $picker.removeClass( 'is-uploading' );
            if ( response && response.success && response.data ) {
                applyAttachmentToPicker( $picker, response.data.id, response.data.url, {
                    width           : response.data.width,
                    height          : response.data.height,
                    filesizeInBytes : response.data.filesizeInBytes
                } );
            } else {
                window.alert( 'העלאת התמונה נכשלה. נסה שוב או השתמש בכפתור "בחר תמונה".' );
            }
        } ).fail( function () {
            $picker.removeClass( 'is-uploading' );
            window.alert( 'העלאת התמונה נכשלה. נסה שוב או השתמש בכפתור "בחר תמונה".' );
        } );
    } );

    // Prevent the browser from navigating away if a file is dropped outside a picker
    $( document ).on( 'dragover drop', function ( e ) {
        if ( ! $( e.target ).closest( '.uhaifa-image-picker' ).length ) {
            e.preventDefault();
        }
    } );

    // ── Remove image (unlink only — does NOT delete from Media Library,
    // the attachment may be used elsewhere on the site) ────────────────────
    $( document ).on( 'click', '.uhaifa-remove-image', function ( e ) {
        e.preventDefault();

        var $btn    = $( this );
        var $picker = $btn.closest( '.uhaifa-image-picker' );
        var $input  = $picker.find( '.uhaifa-slide-image-input' );

        $input.val( '' );
        $picker.find( '.uhaifa-preview-img' )
               .replaceWith( '<div class="uhaifa-image-placeholder">לא נבחרה תמונה</div>' );
        $picker.removeClass( 'has-image' );
        $picker.find( '.uhaifa-image-size-warning' ).empty().hide();
    } );

    // Clear error highlight when image is selected
    $( document ).on( 'click', '.uhaifa-pick-image, .uhaifa-replace-image', function () {
        $( this ).closest( '[data-field]' ).removeClass( 'uhaifa-image-error' );
    } );

    // ── Target type toggle ──────────────────────────────────────────────────
    $( 'input[name="uhaifa_target_type"]' ).on( 'change', function () {
        if ( $( this ).val() === 'specific' ) {
            $( '#uhaifa-sites-list' ).slideDown( 200 );
        } else {
            $( '#uhaifa-sites-list' ).slideUp( 200 );
        }
    } );

    // ── Validate before publish ─────────────────────────────────────────────
    $( '#publish' ).on( 'click', function ( e ) {
        $( '#title' ).css( { 'border-color': '', 'box-shadow': '' } );
        $( '#uhaifa-title-error' ).remove();
        $( '#uhaifa_date_start' ).css( { 'border-color': '', 'box-shadow': '' } );
        $( '#uhaifa-startdate-error' ).remove();
        $( '.uhaifa-field-error-msg' ).remove();
        $( '[data-field]' ).removeClass( 'uhaifa-image-error' );
        $( '.uhaifa-dynamic-title-input, .uhaifa-dynamic-buttonurl-input, .uhaifa-static-text-title-input' ).removeClass( 'uhaifa-image-error' );

        var bannerType = $( 'input[name="uhaifa_banner_type"]:checked' ).val() || 'image';
        var hasError   = bannerType === 'dynamic'
            ? validateDynamicSection()
            : validateImageSection();

        // Check title (applies regardless of banner type)
        if ( ! $( '#title' ).val().trim() ) {
            $( '#title' ).css( { 'border-color': '#d63638', 'box-shadow': '0 0 0 1px #d63638' } );
            if ( ! $( '#uhaifa-title-error' ).length ) {
                $( '#title' ).after( '<p id="uhaifa-title-error" class="uhaifa-field-error-msg">שדה חובה — יש להזין כותרת לבאנר</p>' );
            }
            hasError = true;
        }

        // Start date is mandatory — without it the banner is silently never
        // shown on any site (see handle_active()'s date meta_query), with no
        // indication anywhere in wp-admin that anything is wrong.
        if ( ! $( '#uhaifa_date_start' ).val() ) {
            $( '#uhaifa_date_start' ).css( { 'border-color': '#d63638', 'box-shadow': '0 0 0 1px #d63638' } );
            if ( ! $( '#uhaifa-startdate-error' ).length ) {
                $( '#uhaifa_date_start' ).after( '<p id="uhaifa-startdate-error" class="uhaifa-field-error-msg">שדה חובה — ללא תאריך התחלה הבאנר לא יוצג באתר</p>' );
            }
            hasError = true;
        }

        // Clear title error on input
        $( '#title' ).off( 'input.uhaifaTitle' ).on( 'input.uhaifaTitle', function () {
            if ( $( this ).val().trim() ) {
                $( this ).css( { 'border-color': '', 'box-shadow': '' } );
                $( '#uhaifa-title-error' ).remove();
            }
        } );

        // Clear start-date error once one is picked
        $( '#uhaifa_date_start' ).off( 'change.uhaifaStartDate' ).on( 'change.uhaifaStartDate', function () {
            if ( $( this ).val() ) {
                $( this ).css( { 'border-color': '', 'box-shadow': '' } );
                $( '#uhaifa-startdate-error' ).remove();
            }
        } );

        if ( hasError ) {
            e.preventDefault();
            var $firstError = $( '.uhaifa-image-error, #uhaifa-title-error, #uhaifa-startdate-error' ).first();
            if ( $firstError.length ) {
                $( 'html, body' ).animate( { scrollTop: $firstError.offset().top - 100 }, 300 );
            }
            return false;
        }

        // No end date is a valid, intentional choice (campaign runs
        // indefinitely) — publish goes through in one click either way.
    } );

/** Validates the image-slides section. Returns true if there's an error. */
function validateImageSection() {
    var $repeater = $( '#uhaifa-slides-repeater' );
    var hasError  = false;
    var completeSlideFound = false;

    $repeater.children( '.uhaifa-slide-row' ).each( function () {
        var $row       = $( this );
        var desktop    = $row.find( '[data-field="desktop"] .uhaifa-slide-image-input' ).val();
        var hasDesktop = desktop && desktop !== '0';
        var mobile     = $row.find( '[data-field="mobile"] .uhaifa-slide-image-input' ).val();
        var hasMobile  = mobile && mobile !== '0';
        var alt        = $row.find( '.uhaifa-slide-alt-input' ).val().trim();
        var isComplete = hasDesktop && hasMobile && alt !== '';

        if ( isComplete ) {
            completeSlideFound = true;
            return;
        }

        // Flag partially-filled rows so the editor knows what's missing —
        // a fully-empty untouched row is left alone and just dropped server-side.
        var touched = hasDesktop || hasMobile || alt !== '';
        if ( ! touched ) return;

        if ( ! hasDesktop ) {
            $row.find( '[data-field="desktop"]' ).addClass( 'uhaifa-image-error' )
                .append( '<p class="uhaifa-field-error-msg">שדה חובה — יש לבחור תמונה למחשב</p>' );
            hasError = true;
        }
        if ( ! hasMobile ) {
            $row.find( '[data-field="mobile"]' ).addClass( 'uhaifa-image-error' )
                .append( '<p class="uhaifa-field-error-msg">שדה חובה — יש לבחור תמונה לנייד</p>' );
            hasError = true;
        }
        if ( alt === '' ) {
            $row.find( '.uhaifa-slide-alt-input' ).addClass( 'uhaifa-image-error' )
                .after( '<p class="uhaifa-field-error-msg">שדה חובה — יש להזין טקסט חלופי (alt) לתמונה</p>' );
            hasError = true;
        }
    } );

    if ( ! completeSlideFound ) {
        if ( ! hasError ) {
            var $first = $repeater.children( '.uhaifa-slide-row' ).first();
            $first.find( '[data-field="desktop"]' ).addClass( 'uhaifa-image-error' )
                .append( '<p class="uhaifa-field-error-msg">יש להוסיף לפחות שקופית אחת עם תמונה למחשב, תמונה לנייד וטקסט חלופי</p>' );
        }
        hasError = true;
    }

    return hasError;
}

    /** Validates the dynamic (background + rotating text) section. Returns true if there's an error. */
    function validateDynamicSection() {
        var $repeater = $( '#uhaifa-dynamic-items-repeater' );
        var bgMode    = $( 'input[name="uhaifa_dynamic_bg_mode"]:checked' ).val() || 'shared';
        var hasError  = false;

        // Multi mode: text is fixed (one title) and only the FIRST
        // background row is mandatory — handled on its own, skipping the
        // per-item title/button checks below entirely.
        if ( bgMode === 'multi' ) {
            var staticTitle = $( '#uhaifa-static-text-fields .uhaifa-static-text-title-input' ).val().trim();
            if ( staticTitle === '' ) {
                $( '#uhaifa-static-text-fields .uhaifa-static-text-title-input' ).addClass( 'uhaifa-image-error' )
                    .after( '<p class="uhaifa-field-error-msg">שדה חובה — יש להזין כותרת קבועה</p>' );
                hasError = true;
            }

            var $firstRow   = $repeater.children( '.uhaifa-slide-row' ).first();
            var firstMobile = $firstRow.find( '[data-field="image_mobile"] .uhaifa-slide-image-input' ).val();
            if ( ! firstMobile || firstMobile === '0' ) {
                $firstRow.find( '[data-field="image_mobile"]' ).addClass( 'uhaifa-image-error' )
                    .append( '<p class="uhaifa-field-error-msg">שדה חובה — יש לבחור תמונת רקע לנייד לתמונה הראשונה</p>' );
                hasError = true;
            }

            return hasError;
        }

        // Shared background: mobile image is mandatory.
        if ( bgMode === 'shared' ) {
            var $sharedMobile = $( '#uhaifa-shared-bg-fields [data-field="image_mobile"] .uhaifa-slide-image-input' );
            var sharedMobile  = $sharedMobile.val();
            if ( ! sharedMobile || sharedMobile === '0' ) {
                $( '#uhaifa-shared-bg-fields [data-field="image_mobile"]' ).addClass( 'uhaifa-image-error' )
                    .append( '<p class="uhaifa-field-error-msg">שדה חובה — יש לבחור תמונת רקע לנייד</p>' );
                hasError = true;
            }
        }

        // At least one item with title + button url (and, in per_item mode,
        // its own mobile background image).
        var hasValidItem = false;

        $repeater.children( '.uhaifa-slide-row' ).each( function () {
            var $row        = $( this );
            var title       = $row.find( '.uhaifa-dynamic-title-input' ).val().trim();
            var buttonUrl   = $row.find( '.uhaifa-dynamic-buttonurl-input' ).val().trim();
            var mobile      = $row.find( '[data-field="image_mobile"] .uhaifa-slide-image-input' ).val();
            var hasMobile   = mobile && mobile !== '0';
            var isComplete  = title !== '' && ( bgMode === 'shared' || hasMobile );

            if ( isComplete ) {
                hasValidItem = true;
                return;
            }

            // Flag partially-filled rows so the editor knows what's missing.
            var touched = title !== '' || buttonUrl !== '' || ( bgMode === 'per_item' && hasMobile );
            if ( ! touched ) return; // fully-empty row, will just be dropped server-side

            if ( title === '' ) {
                $row.find( '.uhaifa-dynamic-title-input' ).addClass( 'uhaifa-image-error' )
                    .after( '<p class="uhaifa-field-error-msg">שדה חובה — יש להזין כותרת</p>' );
                hasError = true;
            }
            if ( bgMode === 'per_item' && ! hasMobile ) {
                $row.find( '[data-field="image_mobile"]' ).addClass( 'uhaifa-image-error' )
                    .append( '<p class="uhaifa-field-error-msg">שדה חובה — יש לבחור תמונת רקע לנייד</p>' );
                hasError = true;
            }
        } );

        if ( ! hasValidItem && ! hasError ) {
            var $first = $repeater.children( '.uhaifa-slide-row' ).first();
            $first.find( '.uhaifa-dynamic-title-input' ).addClass( 'uhaifa-image-error' )
                .after( '<p class="uhaifa-field-error-msg">יש להוסיף לפחות פריט אחד עם כותרת וקישור לכפתור</p>' );
            hasError = true;
        } else if ( ! hasValidItem ) {
            hasError = true;
        }

        return hasError;
    }

    // ── Push Now (manual cache warm-up on target sites) ────────────────────
    $( document ).on( 'click', '#uhaifa-push-now', function () {
        if ( typeof uhaifaPushNow === 'undefined' ) return;

        var $button  = $( this );
        var $spinner = $( '#uhaifa-push-now-spinner' );
        var $results = $( '#uhaifa-push-now-results' );
        var postId   = $button.data( 'post-id' );

        $button.prop( 'disabled', true );
        $spinner.addClass( 'is-active' );
        $results.empty();

        $.post( uhaifaPushNow.ajaxUrl, {
            action:  'uhaifa_push_now',
            nonce:   uhaifaPushNow.nonce,
            post_id: postId
        } ).done( function ( response ) {
            if ( ! response.success ) {
                $results.html( '<p class="uhaifa-push-error">' + ( response.data && response.data.message ? response.data.message : 'שגיאה בשליחה' ) + '</p>' );
                return;
            }

            var results = response.data.results;
            if ( ! results.length ) {
                $results.html( '<p>אין אתרי יעד מרוחקים לרענון עבור קמפיין זה.</p>' );
                return;
            }

            var $list = $( '<ul class="uhaifa-push-results-list"></ul>' );
            results.forEach( function ( r ) {
                var icon = r.success ? '✅' : '❌';
                $list.append( '<li>' + icon + ' ' + r.url + '</li>' );
            } );
            $results.append( $list );
        } ).fail( function () {
            $results.html( '<p class="uhaifa-push-error">שגיאת תקשורת בעת השליחה</p>' );
        } ).always( function () {
            $button.prop( 'disabled', false );
            $spinner.removeClass( 'is-active' );
        } );
    } );

} );