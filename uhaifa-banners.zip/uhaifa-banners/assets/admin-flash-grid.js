document.addEventListener('DOMContentLoaded', function () {
	var table    = document.getElementById('uhaifa-flash-grid-table');
	var tbody    = table ? table.querySelector('tbody') : null;
	var template = document.getElementById('uhaifa-flash-row-template');
	var addBtn   = document.getElementById('uhaifa-flash-add-row');

	var nextIndex = tbody ? tbody.querySelectorAll('tr').length : 0;

	if (addBtn && tbody && template) {
		addBtn.addEventListener('click', function () {
			var html = template.innerHTML.split('__INDEX__').join(nextIndex);
			var wrapper = document.createElement('tbody');
			wrapper.innerHTML = html;

			var newRow = wrapper.querySelector('tr');
			if (newRow) {
				tbody.appendChild(newRow);
				nextIndex++;

				var firstInput = newRow.querySelector('input[type="text"]');
				if (firstInput) firstInput.focus();
			}
		});
	}

	document.addEventListener('click', function (e) {
		var link = e.target.closest('.uhaifa-flash-delete-row');
		if (!link) return;

		e.preventDefault();

		// Unsaved row added via "add row" — nothing to delete server-side,
		// just remove it from the form.
		if (link.getAttribute('data-new') === '1') {
			var row = link.closest('tr');
			if (row) row.remove();
			return;
		}

		var message = link.getAttribute('data-confirm') || 'למחוק?';
		if (window.confirm(message)) {
			window.location.href = link.href;
		}
	});
});
