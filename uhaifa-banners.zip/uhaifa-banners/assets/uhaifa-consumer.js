/* globals uhBanner */
/**
 * Front-end banner renderer. Branches on uhBanner.type:
 *   - 'image'   → the original fade-rotating image slideshow.
    *   - 'dynamic' → one fixed background with rotating text on top
 *                 (bg_mode: 'shared'); fully independent rotating items
 *                 that each carry their own background (bg_mode:
 *                 'per_item'); or rotating background images with one
 *                 PERMANENT text overlay (bg_mode: 'multi').
 * uhBanner is set by wp_localize_script only when there's active content
 * for this site (see class-consumer.php maybe_enqueue()).
 *
 * NOTE on YouTube backgrounds: as of YouTube's embed player redesign
 * (March 2026), a center play/pause icon shows briefly on load and is not
 * suppressible via any player parameter, CSS, or JS timing — this was
 * investigated at length and is an accepted limitation, not a bug in this
 * file. See project notes for details. The only real fix would be
 * switching to self-hosted video files instead of YouTube embeds.
 */
( function () {
    'use strict';

    // ── Debug switch ─────────────────────────────────────────────────────
    // Flip to false to silence all uh* console logs.
    var UH_DEBUG = false;
    function uhLog() {
        if ( ! UH_DEBUG ) return;
        var args = Array.prototype.slice.call( arguments );
        args.unshift( '[uh-banner]' );
        console.log.apply( console, args );
    }

    if ( typeof uhBanner === 'undefined' ) {
        uhLog( 'uhBanner is undefined — script loaded but no active banner data for this site.' );
        return;
    }

    var isDynamic  = uhBanner.type === 'dynamic';
    var hasContent = isDynamic
        ? ( uhBanner.items  && uhBanner.items.length )
        : ( uhBanner.slides && uhBanner.slides.length );

    uhLog( 'banner data received:', uhBanner );

    if ( ! hasContent ) {
        uhLog( 'no slides/items in payload — nothing to render.' );
        return;
    }

    document.addEventListener( 'DOMContentLoaded', function () {

        var hero = document.getElementById( 'uhaifa-hero-banner' );
        if ( ! hero ) {
            // Container not found on this page — nothing to override.
            uhLog( '#uhaifa-hero-banner not found on this page — skipping.' );
            return;
        }

        var wrapper = isDynamic ? buildDynamicBanner( uhBanner ) : buildImageBanner( uhBanner );

        hero.parentNode.insertBefore( wrapper, hero );
        document.body.classList.add( 'uhaifa-banner-active' );
        uhLog( 'wrapper inserted into DOM:', wrapper );

        // The background layer has zero size until the wrapper is actually
        // in the DOM (sizeVideoCover() bails out on a 0×0 container), so the
        // very first video — whichever bg_mode built it — needs sizing here,
        // now that real dimensions exist.
        var initialYtFrame = wrapper.querySelector( '.uhaifa-yt-bg' );
        if ( initialYtFrame ) sizeVideoCover( initialYtFrame );

        // ── Resize: swap desktop/mobile background element on breakpoint,
        // and re-size any active video background to keep covering its box ──
        var lastMobile = isMobile();
        window.addEventListener( 'resize', debounce( function () {
            var nowMobile = isMobile();
            if ( nowMobile !== lastMobile ) {
                lastMobile = nowMobile;
                applyResponsiveState( wrapper, nowMobile );
            }
            var activeYtFrame = wrapper.querySelector( '.uhaifa-slide-active .uhaifa-yt-bg, .uhaifa-yt-bg' );
            if ( activeYtFrame ) sizeVideoCover( activeYtFrame );
        }, 150 ) );

        window.addEventListener( 'load', function () {
            var activeYtFrame = wrapper.querySelector( '.uhaifa-slide-active .uhaifa-yt-bg, .uhaifa-yt-bg' );
            if ( activeYtFrame ) sizeVideoCover( activeYtFrame );
        } );
    } );

    // ══════════════════════════ IMAGE TYPE ═════════════════════════════════

    /** Builds the classic fade-rotating image slideshow wrapper. */
    function buildImageBanner( data ) {
        var slides   = data.slides;
        var duration = data.duration || 5000;

        var wrapper = document.createElement( 'div' );
        wrapper.id  = 'uhaifa-banner-override';

        var slideEls = slides.map( function ( slide, index ) {
            return buildImageSlide( slide, index === 0 );
        } );
        slideEls.forEach( function ( el ) { wrapper.appendChild( el ); } );

        var dots    = buildDots( wrapper, slideEls.length );
        var rotator = null;

        // Skip the rotation timer entirely when there's only one slide —
        // it should behave exactly like a plain static banner.
        if ( slideEls.length > 1 ) {
            rotator = createRotator( slideEls, duration, {
                onChange: function ( index ) { if ( dots ) dots.setActive( index ); }
            } );
        }

        if ( dots ) {
            dots.onClick( function ( index ) { if ( rotator ) rotator.goTo( index ); } );
        }
        if ( rotator ) {
            wrapper.addEventListener( 'mouseenter', rotator.pause );
            wrapper.addEventListener( 'mouseleave', rotator.resume );
        }

        return wrapper;
    }

    /** Builds one <div class="uhaifa-slide"> for the image slideshow. */
    function buildImageSlide( slide, isFirst ) {
        var el = document.createElement( 'div' );
        el.className = 'uhaifa-slide' + ( isFirst ? ' uhaifa-slide-active' : '' );

        var desktopImg = '<img'
            + ' src="'   + escAttr( slide.desktop ) + '"'
            + ' alt="'   + escAttr( slide.alt     ) + '"'
            + ' class="uhaifa-img uhaifa-img-desktop"'
            + ' loading="' + ( isFirst ? 'eager' : 'lazy' ) + '"'
            + '>';

        var mobileImg = slide.mobile
            ? '<img'
              + ' src="'   + escAttr( slide.mobile ) + '"'
              + ' alt="'   + escAttr( slide.alt    ) + '"'
              + ' class="uhaifa-img uhaifa-img-mobile"'
              + ' loading="' + ( isFirst ? 'eager' : 'lazy' ) + '"'
              + '>'
            : '';

        var inner = desktopImg + mobileImg;

        var slideHref = safeUrl( slide.link_url );
        if ( slideHref ) {
            inner = '<a href="' + escAttr( slideHref ) + '"'
                  + ' target="' + escAttr( slide.link_target || '_blank' ) + '"'
                  + ' rel="' + ( slide.link_target === '_self' ? '' : 'noopener noreferrer' ) + '"'
                  + '>' + inner + '</a>';
        }

        el.innerHTML = inner;
        return el;
    }

    // ══════════════════════════ DYNAMIC TYPE ════════════════════════════════

    /** Builds the dynamic banner wrapper, branching on bg_mode. */
    function buildDynamicBanner( data ) {
        var duration = data.duration || 5000;
        var wrapper  = document.createElement( 'div' );
        wrapper.id   = 'uhaifa-banner-override';
        wrapper.classList.add( 'uhaifa-banner-dynamic' );

        var dots    = null;
        var rotator = null;

        if ( data.bg_mode === 'multi' ) {
            wrapper.classList.add( 'uhaifa-bg-multi' );

            var staticText = data.static_text || {};

            var bgSlideEls = data.items.map( function ( bg, index ) {
                var el = document.createElement( 'div' );
                el.className = 'uhaifa-slide' + ( index === 0 ? ' uhaifa-slide-active' : '' );

                var bgLayer = document.createElement( 'div' );
                bgLayer.className = 'uhaifa-dynamic-bg';
                bgLayer.innerHTML = buildBgMarkup( bg, index === 0 );

                el.appendChild( bgLayer );
                return el;
            } );

            var multiOverlay = document.createElement( 'div' );
            multiOverlay.className = 'uhaifa-dynamic-overlay';
            multiOverlay.innerHTML = dynamicTextMarkup( staticText );

            if ( staticText.button_url ) {
                var multiLink = document.createElement( 'a' );
                multiLink.className = 'uhaifa-banner-link';
                multiLink.href   = safeUrl( staticText.button_url );
                multiLink.target = staticText.button_target || '_blank';
                multiLink.rel    = staticText.button_target === '_self' ? '' : 'noopener noreferrer';
                bgSlideEls.forEach( function ( el ) { multiLink.appendChild( el ); } );
                multiLink.appendChild( multiOverlay );
                wrapper.appendChild( multiLink );
            } else {
                bgSlideEls.forEach( function ( el ) { wrapper.appendChild( el ); } );
                wrapper.appendChild( multiOverlay );
            }

            // No dots for the permanent-text mode — rotation still runs as
            // normal, just without paging chrome.
            if ( bgSlideEls.length > 1 ) {
                rotator = createRotator( bgSlideEls, duration );
            }

        } else if ( data.bg_mode === 'shared' ) {
            wrapper.classList.add( 'uhaifa-bg-shared' );

            // One persistent background layer for the whole campaign.
            var bgLayer = document.createElement( 'div' );
            bgLayer.className = 'uhaifa-dynamic-bg';
            bgLayer.innerHTML = buildBgMarkup( data.background, true );

            var sharedYtMount = bgLayer.querySelector( '.uhaifa-yt-bg' );
            if ( sharedYtMount ) {
                uhLog( 'shared bg_mode: found YouTube mount, creating player. youtubeId=', sharedYtMount.dataset.youtubeId );
                createBgPlayer( sharedYtMount );
            } else {
                uhLog( 'shared bg_mode: no YouTube mount found (image-only background).' );
            }

            // Text-only items fade-rotate on top of that fixed background.
            var overlay = document.createElement( 'div' );
            overlay.className = 'uhaifa-dynamic-overlay';

            var itemEls = data.items.map( function ( item, index ) {
                return buildDynamicTextItem( item, index === 0 );
            } );
            itemEls.forEach( function ( el ) { overlay.appendChild( el ); } );

            // Whole-banner link, kept in sync with whichever item is
            // currently active — clicking ANYWHERE on the video/image/text
            // navigates to the current item's button_url, not just the
            // visible button. Only created if at least one item has a link.
            var hasAnyLink = data.items.some( function ( it ) { return !! it.button_url; } );
            var syncLink   = function ( index ) {
                var it = data.items[ index ];
                if ( ! bannerLink ) return;
                if ( it && safeUrl( it.button_url ) ) {
                    bannerLink.href   = safeUrl( it.button_url );
                    bannerLink.target = it.button_target || '_blank';
                    bannerLink.rel    = it.button_target === '_self' ? '' : 'noopener noreferrer';
                    bannerLink.classList.remove( 'uhaifa-bg-link-disabled' );
                } else {
                    bannerLink.removeAttribute( 'href' );
                    bannerLink.classList.add( 'uhaifa-bg-link-disabled' );
                }
            };

            var bannerLink = null;
            if ( hasAnyLink ) {
                bannerLink = document.createElement( 'a' );
                bannerLink.className = 'uhaifa-banner-link';
                bannerLink.appendChild( bgLayer );
                bannerLink.appendChild( overlay );
                wrapper.appendChild( bannerLink );
                syncLink( 0 );
            } else {
                wrapper.appendChild( bgLayer );
                wrapper.appendChild( overlay );
            }

            dots = buildDots( wrapper, itemEls.length );
            if ( itemEls.length > 1 ) {
                rotator = createRotator( itemEls, duration, {
                    onChange: function ( index ) {
                        syncLink( index );
                        if ( dots ) dots.setActive( index );
                    }
                } );
            }

        } else {
            // per_item: every rotating item carries its own background too.
            wrapper.classList.add( 'uhaifa-bg-per-item' );

            var perItemEls = data.items.map( function ( item, index ) {
                return buildDynamicFullItem( item, index === 0 );
            } );
            perItemEls.forEach( function ( el ) { wrapper.appendChild( el ); } );

            // The first item is active from the start, so its video (if any)
            // needs to load immediately rather than waiting for a rotation tick.
            if ( perItemEls.length ) activateItemVideo( perItemEls[ 0 ] );

            dots = buildDots( wrapper, perItemEls.length );
            if ( perItemEls.length > 1 ) {
                rotator = createRotator( perItemEls, duration, {
                    activate:   activateItemVideo,
                    deactivate: deactivateItemVideo,
                    onChange:   function ( index ) { if ( dots ) dots.setActive( index ); }
                } );
            }
        }

        if ( dots ) {
            dots.onClick( function ( index ) { if ( rotator ) rotator.goTo( index ); } );
        }
        if ( rotator ) {
            wrapper.addEventListener( 'mouseenter', rotator.pause );
            wrapper.addEventListener( 'mouseleave', rotator.resume );
        }

        return wrapper;
    }

    /**
     * Background markup for a fixed slot: a YouTube iframe when a video is
     * set (desktop only), otherwise the desktop image; the mobile image is
     * always included and toggled by the existing responsive breakpoint CSS.
     */
    function buildBgMarkup( bg, eager ) {
        // No desktop image uploaded (bg.desktop is null) — skip the <img>
        // entirely rather than falling back to the mobile photo, which
        // caused a visible flash/flicker on every video reload (mismatched
        // aspect ratio briefly showing through before the video re-covers
        // it). With no image element, the panel/gradient background shows
        // through cleanly instead during that brief window.
        var desktopImgEl = bg.desktop
            ? '<img src="' + escAttr( bg.desktop ) + '" alt="" class="uhaifa-img uhaifa-img-desktop" loading="' + ( eager ? 'eager' : 'lazy' ) + '">'
            : '';
        var desktopEl = bg.youtube_id
            ? desktopImgEl + youtubeMountHtml( bg.youtube_id )
            : desktopImgEl;

        var mobileEl = '<img src="' + escAttr( bg.mobile ) + '" alt="" class="uhaifa-img uhaifa-img-mobile" loading="' + ( eager ? 'eager' : 'lazy' ) + '">';

        return desktopEl + mobileEl;
    }

    /**
     * Loads the YouTube IFrame Player API script once (cached in
     * ytApiPromise). We use the real API instead of a raw iframe src +
     * loop=1&playlist=<id> URL trick because that trick shows YouTube's
     * native end-of-video UI every time it restarts — the API lets us
     * catch ENDED and restart manually instead.
     */
    var ytApiPromise = null;
    function loadYouTubeApi() {
        if ( ytApiPromise ) return ytApiPromise;
        uhLog( 'loading YouTube IFrame API…' );
        ytApiPromise = new Promise( function ( resolve ) {
            if ( window.YT && window.YT.Player ) {
                uhLog( 'YouTube IFrame API already present on window.' );
                resolve( window.YT );
                return;
            }
            var prevCallback = window.onYouTubeIframeAPIReady;
            window.onYouTubeIframeAPIReady = function () {
                uhLog( 'onYouTubeIframeAPIReady fired — API loaded.' );
                if ( typeof prevCallback === 'function' ) prevCallback();
                resolve( window.YT );
            };
            if ( ! document.querySelector( 'script[src*="youtube.com/iframe_api"]' ) ) {
                var tag = document.createElement( 'script' );
                tag.src = 'https://www.youtube.com/iframe_api';
                tag.onerror = function () {
                    console.error( '[uh-banner] FAILED to load https://www.youtube.com/iframe_api — check network/ad-block/CSP.' );
                };
                document.head.appendChild( tag );
                uhLog( 'iframe_api <script> tag appended to <head>.' );
            } else {
                uhLog( 'iframe_api <script> tag already present, waiting for it to call back.' );
            }
        } );
        return ytApiPromise;
    }

    /** Markup for a background-video mount point — a plain div the API replaces with its own iframe once loaded. */
    function youtubeMountHtml( youtubeId ) {
        return '<div class="uhaifa-img uhaifa-img-desktop uhaifa-yt-bg" data-youtube-id="' + escAttr( youtubeId ) + '"></div>';
    }

    /**
     * Creates a muted, autoplaying background player inside mountEl (must
     * already be in the DOM tree we're building — doesn't need to be
     * attached to document yet). Returns a handle for destroyBgPlayer().
     */
    function createBgPlayer( mountEl ) {
        var handle = { player: null, destroyed: false };
        var videoId = mountEl.dataset.youtubeId;

        uhLog( 'createBgPlayer() called for videoId=', videoId, 'mount element=', mountEl );

        loadYouTubeApi().then( function ( YT ) {
            if ( handle.destroyed ) {
                uhLog( 'createBgPlayer(): handle destroyed before API resolved, aborting for videoId=', videoId );
                return;
            }

            uhLog( 'API ready — constructing YT.Player for videoId=', videoId );

            handle.player = new YT.Player( mountEl, {
                videoId: videoId,
                playerVars: {
                    autoplay: 1, mute: 1, controls: 0, disablekb: 1, fs: 0,
                    modestbranding: 1, rel: 0, showinfo: 0, iv_load_policy: 3,
                    playsinline: 1
                },
                events: {
                    onReady: function ( e ) {
                        var iframe = e.target.getIframe();
                        uhLog( 'onReady fired for videoId=', videoId, '| iframe:', iframe );

                        iframe.className = 'uhaifa-img uhaifa-img-desktop uhaifa-yt-bg';
                        iframe.setAttribute( 'loading', 'lazy' );

                        // NOTE: no e.target.mute() call here — playerVars
                        // already sets mute:1 at creation. Calling .mute()
                        // again right before .playVideo() has been observed
                        // to make some browsers treat the following
                        // playVideo() as non-autoplay-eligible and silently
                        // block it, leaving the video paused forever.
                        e.target.playVideo();
                        sizeVideoCover( iframe );
                    },
                    onStateChange: function ( e ) {
                        uhLog( 'onStateChange fired for videoId=', videoId, '| state=', e.data );

                        // Manual restart on end — avoids YouTube's native
                        // end-of-video overlay that the loop=1&playlist=
                        // URL trick would otherwise trigger every cycle.
                        if ( e.data === YT.PlayerState.ENDED ) {
                            uhLog( 'ENDED for videoId=', videoId, '— restarting manually.' );
                            e.target.seekTo( 0 );
                            e.target.playVideo();
                        }
                    },
                    onError: function ( e ) {
                        // YouTube error codes: 2 invalid param, 5 HTML5 error,
                        // 100 not found/private, 101/150 embedding disabled.
                        console.error( '[uh-banner] onError fired for videoId=', videoId, '| code=', e.data );
                    }
                }
            } );
        } );

        return handle;
    }

    /** Destroys a player handle created by createBgPlayer(); safe to call even if the API hasn't finished loading yet. */
    function destroyBgPlayer( handle ) {
        if ( ! handle ) return;
        handle.destroyed = true;
        if ( handle.player && typeof handle.player.destroy === 'function' ) {
            uhLog( 'destroying player handle:', handle );
            handle.player.destroy();
        }
    }

    /**
     * Sizes a YouTube background iframe so it always crops to fill its
     * container ("cover" behavior) without distorting the video. YouTube's
     * player letterboxes/pillarboxes internally to preserve the video's
     * native 16:9 ratio rather than stretching — so instead of fighting
     * that, this makes the iframe itself deliberately oversized in
     * whichever dimension is needed, and CSS centers + clips the overflow
     * (see .uhaifa-yt-bg / #uhaifa-banner-override overflow:hidden).
     */
    function sizeVideoCover( iframe ) {
        var container = iframe.parentElement;
        if ( ! container ) return;

        // getBoundingClientRect gives sub-pixel precision — clientWidth/
        // clientHeight round to integers, which was leaving a hairline gap.
        var rect = container.getBoundingClientRect();
        var w = rect.width;
        var h = rect.height;
        if ( ! w || ! h ) return;

        var videoRatio     = 16 / 9;
        var containerRatio = w / h;

        // Deliberate 3% overshoot: covers rounding, plus the fact that not
        // every YouTube upload is encoded at exactly 16:9 — an exact-fit
        // calculation can still leave a sliver of page background showing
        // on one edge if the source video's real ratio is slightly off.
        var SAFETY = 1.03;

        var videoW, videoH;
        if ( containerRatio > videoRatio ) {
            videoW = w * SAFETY;
            videoH = videoW / videoRatio;
        } else {
            videoH = h * SAFETY;
            videoW = videoH * videoRatio;
        }

        iframe.style.width  = videoW + 'px';
        iframe.style.height = videoH + 'px';
    }

    /** Text-only rotating item used in shared-background mode (title/text/button, no background of its own). */
    function buildDynamicTextItem( item, isFirst ) {
        var el = document.createElement( 'div' );
        el.className = 'uhaifa-slide uhaifa-dynamic-item' + ( isFirst ? ' uhaifa-slide-active' : '' );
        el.innerHTML = dynamicTextMarkup( item );
        return el;
    }

    /**
     * Full rotating item used in per-item background mode: its own
     * background layer (image rendered immediately; video added/removed on
     * activation, see activateItemVideo/deactivateItemVideo) plus text on top.
     */
    function buildDynamicFullItem( item, isFirst ) {
        var el = document.createElement( 'div' );
        el.className = 'uhaifa-slide uhaifa-dynamic-item' + ( isFirst ? ' uhaifa-slide-active' : '' );

        var bgLayer = document.createElement( 'div' );
        bgLayer.className = 'uhaifa-dynamic-bg';
        // Same reasoning as buildBgMarkup(): no desktop <img> at all when
        // item.desktop is null, instead of stretching the mobile photo.
        bgLayer.innerHTML = ( item.desktop ? '<img src="' + escAttr( item.desktop ) + '" alt="" class="uhaifa-img uhaifa-img-desktop" loading="' + ( isFirst ? 'eager' : 'lazy' ) + '">' : '' )
            + '<img src="' + escAttr( item.mobile ) + '" alt="" class="uhaifa-img uhaifa-img-mobile" loading="' + ( isFirst ? 'eager' : 'lazy' ) + '">';
        bgLayer.dataset.youtubeId = item.youtube_id || '';

        var overlay = document.createElement( 'div' );
        overlay.className = 'uhaifa-dynamic-overlay';
        overlay.innerHTML = dynamicTextMarkup( item );

        // Whole-item link — each item already carries its own button_url,
        // so unlike shared mode this needs no rotation-sync: the link just
        // matches whichever item it belongs to, permanently.
        if ( item.button_url ) {
            var itemLink = document.createElement( 'a' );
            itemLink.className = 'uhaifa-banner-link';
            itemLink.href       = safeUrl( item.button_url );
            itemLink.target     = item.button_target || '_blank';
            itemLink.rel        = item.button_target === '_self' ? '' : 'noopener noreferrer';
            itemLink.appendChild( bgLayer );
            itemLink.appendChild( overlay );
            el.appendChild( itemLink );
        } else {
            el.appendChild( bgLayer );
            el.appendChild( overlay );
        }

        return el;
    }

    /** Title / body text / button markup shared by both dynamic item types. */
    function dynamicTextMarkup( item ) {
        var html = '<div class="uhaifa-dynamic-text">';
        if ( item.title ) html += '<h2 class="uhaifa-dynamic-title">' + escHtml( item.title ) + '</h2>';
        if ( item.text )  html += '<p class="uhaifa-dynamic-text-body">' + escHtml( item.text ) + '</p>';
        if ( item.button_url ) {
            // Purely visual — the entire banner is already one <a>
            // (see buildDynamicBanner()'s bannerLink), so this is a span
            // with button styling, not a real link.
            html += '<span class="uhaifa-dynamic-btn">' + escHtml( item.button_text || 'קרא עוד' ) + '</span>';
        }
        html += '</div>';
        return html;
    }

    /**
     * Lazily creates the YouTube iframe for an item's background only when
     * that item becomes active. Combined with deactivateItemVideo(), this
     * guarantees at most one video is ever autoplaying at a time in
     * per-item mode — the tradeoff is a brief reload the moment rotation
     * lands on a video item, instead of every video autoplaying at once.
     */
    function activateItemVideo( itemEl ) {
        var bgLayer = itemEl.querySelector( '.uhaifa-dynamic-bg' );
        if ( ! bgLayer || ! bgLayer.dataset.youtubeId ) return;
        if ( bgLayer._uhPlayerHandle ) return; // already active

        var mount = document.createElement( 'div' );
        mount.className = 'uhaifa-img uhaifa-img-desktop uhaifa-yt-bg';
        mount.dataset.youtubeId = bgLayer.dataset.youtubeId;
        // Appended LAST (not inserted first) — DOM order controls paint
        // order here since everything is position:absolute with no
        // z-index, so the video must come after the static images to
        // render on top of them, not underneath.
        bgLayer.appendChild( mount );

        uhLog( 'activateItemVideo(): mounting videoId=', bgLayer.dataset.youtubeId );
        bgLayer._uhPlayerHandle = createBgPlayer( mount );
    }

    /** Destroys a previously-activated item's player (see activateItemVideo). */
    function deactivateItemVideo( itemEl ) {
        var bgLayer = itemEl.querySelector( '.uhaifa-dynamic-bg' );
        if ( ! bgLayer || ! bgLayer._uhPlayerHandle ) return;
        uhLog( 'deactivateItemVideo(): destroying player for videoId=', bgLayer.dataset.youtubeId );
        destroyBgPlayer( bgLayer._uhPlayerHandle );
        bgLayer._uhPlayerHandle = null;
    }

     // ══════════════════════════ Rotation helpers ═══════════════════════════

    /**
     * Unified crossfade rotation controller — used for every rotating
     * element (image slides, shared-bg text items, per-item full items,
     * multi-mode backgrounds). Returns { pause, resume, goTo } so callers
     * (hover pause, pagination dots) can drive it externally instead of it
     * just being a fire-and-forget setInterval.
     *
     * options.activate/deactivate, if given, run on the newly-active /
     * outgoing element (used by per-item mode to swap its background video).
     * options.onChange, if given, runs after every change (timer or manual)
     * with (currentIndex, currentEl) — used for link-sync and dot-sync.
     */
    function createRotator( els, duration, options ) {
        options = options || {};
        var activate   = options.activate   || function () {};
        var deactivate = options.deactivate || function () {};
        var onChange   = options.onChange   || function () {};

        var current = 0;
        var timer   = null;

        function apply( index ) {
            if ( index !== current ) {
                deactivate( els[ current ] );
                els[ current ].classList.remove( 'uhaifa-slide-active' );
                els[ index ].classList.add( 'uhaifa-slide-active' );
                activate( els[ index ] );
                current = index;
            }
            onChange( current, els[ current ] );
        }

        function tick() {
            apply( ( current + 1 ) % els.length );
        }

        function start() {
            if ( timer || els.length <= 1 ) return;
            timer = setInterval( tick, duration );
        }

        function stop() {
            if ( timer ) { clearInterval( timer ); timer = null; }
        }

        start();

        return {
            pause:  stop,
            resume: start,
            goTo: function ( index ) {
                if ( index < 0 || index >= els.length || index === current ) return;
                apply( index );
                stop();
                start(); // manual jump restarts the countdown from zero
            }
        };
    }

    /**
     * Builds a pagination-dots row and appends it as the LAST child of
     * `wrapper` — always a sibling of the rotating slides/anchor, never
     * nested inside them, so a <button> is never nested inside an <a> and
     * the dots reliably paint above everything via z-index regardless of
     * banner type. Returns null when there's nothing to page through.
     */
    function buildDots( wrapper, count ) {
        if ( count <= 1 ) return null;

        var wrap = document.createElement( 'div' );
        wrap.className = 'uhaifa-dots';

        var buttons = [];
        for ( var i = 0; i < count; i++ ) {
            var btn = document.createElement( 'button' );
            btn.type = 'button';
            btn.className = 'uhaifa-dot' + ( i === 0 ? ' uhaifa-dot-active' : '' );
            btn.setAttribute( 'aria-label', 'עבור לפריט ' + ( i + 1 ) );
            wrap.appendChild( btn );
            buttons.push( btn );
        }

        wrapper.appendChild( wrap );

        return {
            setActive: function ( index ) {
                buttons.forEach( function ( b, i ) { b.classList.toggle( 'uhaifa-dot-active', i === index ); } );
            },
            onClick: function ( handler ) {
                buttons.forEach( function ( b, i ) {
                    b.addEventListener( 'click', function ( e ) {
                        e.preventDefault();
                        handler( i );
                    } );
                } );
            }
        };
    }

    // ══════════════════════════ Shared helpers ═════════════════════════════

    /** Toggles desktop/mobile background elements at the responsive breakpoint. */
    function applyResponsiveState( wrapper, nowMobile ) {
        var desktops = wrapper.querySelectorAll( '.uhaifa-img-desktop' );
        var mobiles  = wrapper.querySelectorAll( '.uhaifa-img-mobile'  );
        for ( var i = 0; i < desktops.length; i++ ) desktops[ i ].style.display = nowMobile ? 'none' : '';
        for ( var j = 0; j < mobiles.length;  j++ ) mobiles[ j ].style.display  = nowMobile ? ''     : 'none';
    }

    function isMobile() {
        return window.innerWidth <= 768;
    }

    /** Escapes a value for safe use inside an HTML attribute. */
    function escAttr( str ) {
        if ( ! str ) return '';
        return String( str )
            .replace( /&/g, '&amp;' )
            .replace( /"/g, '&quot;' )
            .replace( /</g, '&lt;'  )
            .replace( />/g, '&gt;'  );
    }

    /** Escapes a value for safe use as HTML text content. */
    function escHtml( str ) {
        if ( ! str ) return '';
        return String( str )
            .replace( /&/g, '&amp;' )
            .replace( /</g, '&lt;'  )
            .replace( />/g, '&gt;'  );
    }

    /** Returns the URL only if it's http(s)/mailto — blocks javascript:, data:, etc. */
    function safeUrl( url ) {
        if ( ! url ) return '';
        try {
            var parsed = new URL( url, window.location.href );
            return [ 'http:', 'https:', 'mailto:' ].indexOf( parsed.protocol ) !== -1 ? parsed.href : '';
        } catch ( e ) {
            return '';
        }
    }

    function debounce( fn, delay ) {
        var timer;
        return function () {
            clearTimeout( timer );
            timer = setTimeout( fn, delay );
        };
    }

} )();