(function () {
	document.addEventListener('DOMContentLoaded', function () {
		var el = document.getElementById('uhaifa-flash');
		if (!el) return;

		var once = el.getAttribute('data-once') === '1';
		var storageKey = el.getAttribute('data-storage-key');

		if (once && storageKey) {
			try {
				if (sessionStorage.getItem(storageKey)) return;
				sessionStorage.setItem(storageKey, '1');
			} catch (e) { /* sessionStorage unavailable — show it anyway */ }
		}

		el.style.display = 'block';

		var dismiss = el.querySelector('.uhaifa-flash-dismiss');
		if (dismiss) {
			dismiss.addEventListener('click', function () {
				el.style.display = 'none';
			});
		}

		var viewport = el.querySelector('.uhaifa-flash-viewport');
		var track    = el.querySelector('.uhaifa-flash-items');
		if (!viewport || !track) return;

		var items = Array.prototype.slice.call(track.children);
		if (items.length === 0) return;

		if (items.length === 1) {
			// Single message: centered and static, no motion at all.
			track.style.justifyContent = 'center';
			return;
		}

		// Multiple messages: continuous, infinite marquee.
		//
		// Direction is physical: positive velocity = content drifts
		// right, negative = drifts left. RTL sites (label pinned right)
		// drift right, toward the label; LTR sites (label pinned left)
		// drift left, toward the label — items travel from the open
		// edge toward the pinned label, disappearing underneath it.
		var velocity = (el.getAttribute('data-dir') === 'rtl') ? 60 : -60; // px/sec

		var originalWidth = track.scrollWidth; // width of ONE full sequence, before duplication

		// Duplicate the sequence once, back-to-back, so the loop is
		// seamless: the track now holds two identical copies in a row.
		var clone = track.cloneNode(true);
		while (clone.firstChild) track.appendChild(clone.firstChild);

		var viewportWidth = viewport.clientWidth;

		// Start position: the ENTIRE content block starts just off the
		// edge opposite the direction of travel, so the strip is truly
		// blank at load, then slides in as a whole.
		var x = (velocity > 0) ? -originalWidth : viewportWidth;

		var lastTime = null;
		var paused   = false;
		var traveled = 0; // distance moved since the last wrap correction

		el.addEventListener('mouseenter', function () { paused = true; });
		el.addEventListener('mouseleave', function () { paused = false; });

		function frame(time) {
			if (lastTime === null) lastTime = time;
			var delta = (time - lastTime) / 1000;
			lastTime = time;

			if (!paused && originalWidth > 0) {
				var dx = velocity * delta;
				x += dx;
				traveled += Math.abs(dx);

				// Correct by exactly one period's worth once that much
				// distance has actually been travelled. Because the
				// content repeats every originalWidth px (two identical
				// copies back-to-back), shifting by exactly that amount
				// is visually seamless and can repeat forever — this is
				// what makes the loop infinite rather than running out
				// after the duplicated copy is used up.
				while (traveled >= originalWidth) {
					x -= (velocity > 0 ? originalWidth : -originalWidth);
					traveled -= originalWidth;
				}

				track.style.transform = 'translateX(' + x + 'px)';
			}

			requestAnimationFrame(frame);
		}

		requestAnimationFrame(frame);
	});
})();