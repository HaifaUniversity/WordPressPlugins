/**
 * Controller for the UHaifa Hero Elementor widget. The widget's PHP render()
 * (via class-hero-renderer.php) already outputs the full markup — slides,
 * dynamic items, background images, YouTube mount points — server-side, for
 * BOTH local content and a hub override. This script only ATTACHES behavior
 * to that existing markup: crossfade rotation, and the YouTube IFrame Player
 * API (autoplay/mute/loop-without-native-end-screen/cover-sizing).
 *
 * Filename is deliberately "uhaifa-hero", not "*banner*" — asset filenames
 * containing "banner" get silently dropped by common ad-block filter lists.
 * (See project notes — this was a known issue with the old banner-override.*
 * assets used by the legacy, non-widget override path.)
 *
 * Multiple widget instances on one page are supported: every wrapper
 * carrying the .uhaifa-hero-widget class is initialized independently.
 *
 * NOTE on YouTube backgrounds: a brief center play/pause icon on load is an
 * accepted YouTube-embed limitation (not fixable via player params/CSS/JS
 * timing) — see banner-override.js's original notes for the investigation.
 */
( function () {
    'use strict';

    var UH_DEBUG = true;
    function uhLog() {
        if ( ! UH_DEBUG ) return;
        var args = Array.prototype.slice.call( arguments );
        args.unshift( '[uh-hero]' );
        console.log.apply( console, args );
    }

    // ══════════════════════════ YouTube IFrame API ══════════════════════════
    // Identical approach to the legacy banner-override.js: the real IFrame
    // Player API (not a raw iframe src + loop=1&playlist= URL trick), so we
    // can catch ENDED and restart manually instead of showing YouTube's
    // native end-of-video overlay every cycle.

    var ytApiPromise = null;
    function loadYouTubeApi() {
        if ( ytApiPromise ) return ytApiPromise;
        uhLog( 'loading YouTube IFrame API…' );
        ytApiPromise = new Promise( function ( resolve ) {
            if ( window.YT && window.YT.Player ) {
                resolve( window.YT );
                return;
            }
            var prevCallback = window.onYouTubeIframeAPIReady;
            window.onYouTubeIframeAPIReady = function () {
                if ( typeof prevCallback === 'function' ) prevCallback();
                resolve( window.YT );
            };
            if ( ! document.querySelector( 'script[src*="youtube.com/iframe_api"]' ) ) {
                var tag = document.createElement( 'script' );
                tag.src = 'https://www.youtube.com/iframe_api';
                tag.onerror = function () {
                    console.error( '[uh-hero] FAILED to load https://www.youtube.com/iframe_api — check network/ad-block/CSP.' );
                };
                document.head.appendChild( tag );
            }
        } );
        return ytApiPromise;
    }

    /**
     * Creates a muted, autoplaying background player inside mountEl (a
     * `.uhaifa-yt-bg[data-youtube-id]` div — either already present in the
     * server-rendered markup, or created on the fly by activateBgLayerVideo()
     * below). Returns a handle for destroyBgPlayer().
     */
    function createBgPlayer( mountEl ) {
        var handle  = { player: null, destroyed: false };
        var videoId = mountEl.dataset.youtubeId;

        loadYouTubeApi().then( function ( YT ) {
            if ( handle.destroyed ) return;

            handle.player = new YT.Player( mountEl, {
                videoId: videoId,
                playerVars: {
                    autoplay: 1, mute: 1, controls: 0, disablekb: 1, fs: 0,
                    modestbranding: 1, rel: 0, showinfo: 0, iv_load_policy: 3,
                    playsinline: 1
                },
                events: {
                    onReady: function ( e ) {
                        var iframe = e.target.getIframe();
                        iframe.className = 'uhaifa-img uhaifa-img-desktop uhaifa-yt-bg';
                        iframe.setAttribute( 'loading', 'lazy' );

                        // NOTE: no e.target.mute() call here — playerVars
                        // already sets mute:1 at creation. Calling .mute()
                        // again right before .playVideo() has been observed
                        // to make some browsers treat the following
                        // playVideo() as non-autoplay-eligible and silently
                        // block it, leaving the video paused forever.
                        e.target.playVideo();
                        sizeVideoCover( iframe );
                    },
                    onStateChange: function ( e ) {
                        // Manual restart on end — avoids YouTube's native
                        // end-of-video overlay that loop=1&playlist= would
                        // otherwise trigger every cycle.
                        if ( e.data === YT.PlayerState.ENDED ) {
                            e.target.seekTo( 0 );
                            e.target.playVideo();
                        }
                    },
                    onError: function ( e ) {
                        console.error( '[uh-hero] onError for videoId=', videoId, '| code=', e.data );
                    }
                }
            } );
        } );

        return handle;
    }

    function destroyBgPlayer( handle ) {
        if ( ! handle ) return;
        handle.destroyed = true;
        if ( handle.player && typeof handle.player.destroy === 'function' ) {
            handle.player.destroy();
        }
    }

    /**
     * Ensures a background layer's video is playing. Works whether the
     * `.uhaifa-yt-bg` mount already exists in the server-rendered markup
     * (the shared background, and the first per-item background) or needs
     * to be created now (a later per-item background, activated on
     * rotation) — either way the outer `.uhaifa-dynamic-bg` element carries
     * data-youtube-id, set by class-hero-renderer.php.
     */
    function activateBgLayerVideo( bgLayer ) {
        if ( ! bgLayer || ! bgLayer.dataset.youtubeId ) return;
        if ( bgLayer._uhPlayerHandle ) return; // already active

        var mount = bgLayer.querySelector( '.uhaifa-yt-bg' );
        if ( ! mount ) {
            mount = document.createElement( 'div' );
            mount.className = 'uhaifa-img uhaifa-img-desktop uhaifa-yt-bg';
            mount.dataset.youtubeId = bgLayer.dataset.youtubeId;
            // Appended LAST — everything here is position:absolute with no
            // z-index, so paint order (= DOM order) must put the video after
            // the static images for it to render on top of them.
            bgLayer.appendChild( mount );
        }

        bgLayer._uhPlayerHandle = createBgPlayer( mount );
    }

    /** Destroys a previously-activated background's player (see activateBgLayerVideo). */
    function deactivateBgLayerVideo( bgLayer ) {
        if ( ! bgLayer || ! bgLayer._uhPlayerHandle ) return;
        destroyBgPlayer( bgLayer._uhPlayerHandle );
        bgLayer._uhPlayerHandle = null;
    }

    /**
     * Sizes a YouTube background iframe (or its not-yet-replaced mount div)
     * so it always crops to fill its container ("cover" behavior) without
     * distorting the video, the same way banner-override.js did.
     */
    function sizeVideoCover( iframe ) {
        var container = iframe.parentElement;
        if ( ! container ) return;

        var rect = container.getBoundingClientRect();
        var w = rect.width;
        var h = rect.height;
        if ( ! w || ! h ) return;

        var videoRatio     = 16 / 9;
        var containerRatio = w / h;
        var SAFETY         = 1.03; // covers rounding + off-ratio source video

        var videoW, videoH;
        if ( containerRatio > videoRatio ) {
            videoW = w * SAFETY;
            videoH = videoW / videoRatio;
        } else {
            videoH = h * SAFETY;
            videoW = videoH * videoRatio;
        }

        iframe.style.width  = videoW + 'px';
        iframe.style.height = videoH + 'px';
    }

    // ══════════════════════════ Rotation ═══════════════════════════════════

    /**
     * Unified crossfade rotation controller — used for every rotating
     * element (image slides, shared-bg text items, per-item full items,
     * multi-mode backgrounds). Returns { pause, resume, goTo } so callers
     * (hover pause, pagination dots) can drive it externally instead of it
     * just being a fire-and-forget setInterval.
     *
     * options.activate/deactivate, if given, run on the newly-active /
     * outgoing element (used by per-item mode to swap its background video).
     * options.onChange, if given, runs after every change (timer or manual)
     * with (currentIndex, currentEl) — used for link-sync and dot-sync.
     */
    function createRotator( els, duration, options ) {
        options = options || {};
        var activate   = options.activate   || function () {};
        var deactivate = options.deactivate || function () {};
        var onChange   = options.onChange   || function () {};

        var current = 0;
        var timer   = null;

        function apply( index ) {
            if ( index !== current ) {
                deactivate( els[ current ] );
                els[ current ].classList.remove( 'uhaifa-slide-active' );
                els[ index ].classList.add( 'uhaifa-slide-active' );
                activate( els[ index ] );
                current = index;
            }
            onChange( current, els[ current ] );
        }

        function tick() {
            apply( ( current + 1 ) % els.length );
        }

        function start() {
            if ( timer || els.length <= 1 ) return;
            timer = setInterval( tick, duration );
        }

        function stop() {
            if ( timer ) { clearInterval( timer ); timer = null; }
        }

        start();

        return {
            pause:  stop,
            resume: start,
            goTo: function ( index ) {
                if ( index < 0 || index >= els.length || index === current ) return;
                apply( index );
                stop();
                start(); // manual jump restarts the countdown from zero
            }
        };
    }

    /**
     * Builds a pagination-dots row and appends it as the LAST child of
     * `wrapper` — always a sibling of the rotating slides/anchor, never
     * nested inside them, so a <button> is never nested inside an <a> and
     * the dots reliably paint above everything via z-index regardless of
     * banner type. Returns null when there's nothing to page through.
     */
    function buildDots( wrapper, count ) {
        if ( count <= 1 ) return null;

        var wrap = document.createElement( 'div' );
        wrap.className = 'uhaifa-dots';

        var buttons = [];
        for ( var i = 0; i < count; i++ ) {
            var btn = document.createElement( 'button' );
            btn.type = 'button';
            btn.className = 'uhaifa-dot' + ( i === 0 ? ' uhaifa-dot-active' : '' );
            btn.setAttribute( 'aria-label', 'עבור לפריט ' + ( i + 1 ) );
            wrap.appendChild( btn );
            buttons.push( btn );
        }

        wrapper.appendChild( wrap );

        return {
            setActive: function ( index ) {
                buttons.forEach( function ( b, i ) { b.classList.toggle( 'uhaifa-dot-active', i === index ); } );
            },
            onClick: function ( handler ) {
                buttons.forEach( function ( b, i ) {
                    b.addEventListener( 'click', function ( e ) {
                        e.preventDefault();
                        handler( i );
                    } );
                } );
            }
        };
    }

    /** Keeps the shared-bg whole-banner <a> pointed at whichever item is currently active. */
    function syncBannerLink( bannerLink, slideEl ) {
        if ( ! bannerLink ) return;
        var href = slideEl && slideEl.dataset.href;
        if ( href ) {
            bannerLink.href   = href;
            bannerLink.target = slideEl.dataset.target || '_blank';
            bannerLink.rel    = slideEl.dataset.target === '_self' ? '' : 'noopener noreferrer';
            bannerLink.classList.remove( 'uhaifa-bg-link-disabled' );
        } else {
            // Current item has no link — keep the anchor but make it inert
            // rather than pointing at a stale URL.
            bannerLink.removeAttribute( 'href' );
            bannerLink.classList.add( 'uhaifa-bg-link-disabled' );
        }
    }

    // ══════════════════════════ Shared helpers ═════════════════════════════

    function applyResponsiveState( wrapper, nowMobile ) {
        var desktops = wrapper.querySelectorAll( '.uhaifa-img-desktop' );
        var mobiles  = wrapper.querySelectorAll( '.uhaifa-img-mobile'  );
        for ( var i = 0; i < desktops.length; i++ ) desktops[ i ].style.display = nowMobile ? 'none' : '';
        for ( var j = 0; j < mobiles.length;  j++ ) mobiles[ j ].style.display  = nowMobile ? ''     : 'none';
    }

    function isMobile() {
        return window.innerWidth <= 768;
    }

    function debounce( fn, delay ) {
        var timer;
        return function () {
            clearTimeout( timer );
            timer = setTimeout( fn, delay );
        };
    }

    // ══════════════════════════ Per-instance init ══════════════════════════

    function initWrapper( wrapper ) {
        if ( wrapper.dataset.uhInit ) return; // already initialized
        wrapper.dataset.uhInit = '1';

        var type     = wrapper.dataset.uhType;
        var bgMode   = wrapper.dataset.uhBgMode;
        var duration = parseInt( wrapper.dataset.uhDuration, 10 ) || 5000;
        var slideEls = Array.prototype.slice.call( wrapper.querySelectorAll( '.uhaifa-slide' ) );

        uhLog( 'init', { type: type, bgMode: bgMode, duration: duration, slides: slideEls.length } );

        // Pagination dots — one per slide, EXCEPT for dynamic bg_mode =
        // 'multi' (permanent-text banner, text never changes) or when the
        // widget's own "show dots" control is switched off. data-uh-show-dots
        // is set by class-elementor-widget.php; absent (e.g. markup built
        // before this control existed) defaults to shown.
        var showDots = wrapper.dataset.uhShowDots !== '0'
            && ! ( type === 'dynamic' && bgMode === 'multi' );
        var dots = showDots ? buildDots( wrapper, slideEls.length ) : null;

        var rotator = null;

        if ( type === 'dynamic' && bgMode === 'shared' ) {
            // One persistent background — its video (if any) plays regardless
            // of rotation, since only the text overlay rotates.
            activateBgLayerVideo( wrapper.querySelector( ':scope > .uhaifa-dynamic-bg, :scope > a.uhaifa-banner-link > .uhaifa-dynamic-bg' ) );

            var bannerLink = wrapper.querySelector( ':scope > a.uhaifa-banner-link' );
            if ( slideEls.length > 1 ) {
                rotator = createRotator( slideEls, duration, {
                    onChange: function ( index, el ) {
                        syncBannerLink( bannerLink, el );
                        if ( dots ) dots.setActive( index );
                    }
                } );
            }

        } else if ( type === 'dynamic' && bgMode === 'per_item' ) {
            // The first (active) item's background video, if any, is already
            // mounted in the server-rendered markup — just start its player.
            if ( slideEls.length ) {
                activateBgLayerVideo( slideEls[ 0 ].querySelector( '.uhaifa-dynamic-bg' ) );
            }
            if ( slideEls.length > 1 ) {
                rotator = createRotator( slideEls, duration, {
                    activate:   function ( el ) { activateBgLayerVideo( el.querySelector( '.uhaifa-dynamic-bg' ) ); },
                    deactivate: function ( el ) { deactivateBgLayerVideo( el.querySelector( '.uhaifa-dynamic-bg' ) ); },
                    onChange:   function ( index ) { if ( dots ) dots.setActive( index ); }
                } );
            }

        } else if ( slideEls.length > 1 ) {
            // Plain image slideshow, or dynamic bg_mode = 'multi'.
            rotator = createRotator( slideEls, duration, {
                onChange: function ( index ) { if ( dots ) dots.setActive( index ); }
            } );
        }

        if ( dots ) {
            dots.onClick( function ( index ) {
                if ( rotator ) rotator.goTo( index );
            } );
        }

        // Pause the active rotator (if any) while the mouse is over the
        // banner — resumes with a fresh interval on mouseleave.
        if ( rotator ) {
            wrapper.addEventListener( 'mouseenter', rotator.pause );
            wrapper.addEventListener( 'mouseleave', rotator.resume );
        }

        var initialYt = wrapper.querySelector( '.uhaifa-yt-bg' );
        if ( initialYt ) sizeVideoCover( initialYt );

        var lastMobile = isMobile();
        window.addEventListener( 'resize', debounce( function () {
            var nowMobile = isMobile();
            if ( nowMobile !== lastMobile ) {
                lastMobile = nowMobile;
                applyResponsiveState( wrapper, nowMobile );
            }
            var activeYt = wrapper.querySelector( '.uhaifa-slide-active .uhaifa-yt-bg, .uhaifa-yt-bg' );
            if ( activeYt ) sizeVideoCover( activeYt );
        }, 150 ) );

        window.addEventListener( 'load', function () {
            var activeYt = wrapper.querySelector( '.uhaifa-slide-active .uhaifa-yt-bg, .uhaifa-yt-bg' );
            if ( activeYt ) sizeVideoCover( activeYt );
        } );
    }

    function initAll() {
        var wrappers = document.querySelectorAll( '.uhaifa-hero-widget' );
        for ( var i = 0; i < wrappers.length; i++ ) initWrapper( wrappers[ i ] );
    }

    if ( document.readyState === 'loading' ) {
        document.addEventListener( 'DOMContentLoaded', initAll );
    } else {
        initAll();
    }

    // ── Elementor editor preview ────────────────────────────────────────────
    // The editor's preview iframe injects widget markup via AJAX AFTER
    // DOMContentLoaded has already fired, so initAll() above finds nothing
    // there on first load — nothing (rotation, hover-pause, dots) worked in
    // preview as a result. frontend/element_ready fires for EVERY instance
    // of this widget, both on normal page loads and every time Elementor
    // re-renders it in the editor after a settings change. initWrapper() is
    // idempotent (checks data-uh-init), so calling it again here for an
    // instance initAll() already handled on the live front end is harmless.
    jQuery( window ).on( 'elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction( 'frontend/element_ready/uhaifa_hero.default', function ( $scope ) {
            var wrapper = $scope[ 0 ].querySelector( '.uhaifa-hero-widget' );
            if ( wrapper ) initWrapper( wrapper );
        } );
    } );

} )();