<?php
/**
 * Plugin Name: אוניברסיטת חיפה - באנרים מרכזיים
 * Plugin URI:  https://haifa.ac.il
 * Description: מערכת באנרים מרכזית לאתרי אוניברסיטת חיפה. ניהול באנרים ראשיים ממקום אחד, עם תמיכה בסבב שקופיות (fade), באנרים דינמיים (רקע וידאו/תמונה + טקסט חי), הפצה אוטומטית לכל אתרי הפקולטות, וידג'ט Elementor שמאפשר לכל אתר לבנות גיבור מקומי משלו (מפוסטים לפי תגית או מקמפיין מקומי) שעדיין ניתן לדריסה על ידי קמפיין מרכזי.
 * Version:     3.1.0
 * Author:      Benny Mozes, University of Haifa
* Text Domain: uhaifa-banners
 * Domain Path: /languages
 * Update URI:  https://raw.githubusercontent.com/HaifaUniversity/WordPressPlugins/main/uhaifa-banners.json
 *
 * Changelog:
 *   3.0.0 — New architecture: the CPT/meta-box/validation/response-building
 *           logic that used to live only in UHaifa_Banner_Publisher (hub
 *           only) is now in UHaifa_Banner_CPT, a base class instantiated on
 *           EVERY site so local campaigns can be built anywhere. Publisher
 *           extends it and adds back only the hub-specific concepts (REST,
 *           this_site/all/specific targeting, site registration). New
 *           UHaifa_Elementor_Hero_Widget lets a webmaster drop the hero
 *           renderer directly into their page (posts-by-tag or a local
 *           campaign) — a hub override still wins, resolved entirely
 *           server-side via UHaifa_Banner_Override_Resolver (no JS swap,
 *           and no dependency on the "banner"-named legacy assets).
 *   2.1.0 — Added dynamic banner type (video/image background + rotating
 *           title/text/button), alongside the existing image-slideshow
 *           type. Added mandatory alt text per image slide, and
 *           drag-and-drop upload for every image picker in the admin UI.
 *   2.0.0 — Multi-slide fade rotation within a single campaign.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ─── Constants ────────────────────────────────────────────────────────────────
define( 'UHAIFA_BANNERS_VERSION',       '3.1.0' );
if ( ! defined( 'UHAIFA_BANNERS_PUBLISHER_URL' ) ) {
	define( 'UHAIFA_BANNERS_PUBLISHER_URL', 'https://www.haifa.ac.il' );   // production hub. Override in wp-config.php for local/staging.
}
define( 'UHAIFA_BANNERS_SECRET',        'uh-banners-2025-secret' );     // shared key, same on all sites
define( 'UHAIFA_BANNERS_CACHE_TTL',     300 );                          // 5 minutes
define( 'UHAIFA_BANNERS_DIR',           plugin_dir_path( __FILE__ ) );
define( 'UHAIFA_BANNERS_URL',           plugin_dir_url( __FILE__ ) );

// Only these WordPress usernames (user_login, case-insensitive) can see or
// use the banners admin menu/screens, on every site running this plugin.
// Single source of truth — add/remove usernames here only.
define( 'UHAIFA_BANNERS_ADMIN_USERS', [ '4medouble', 'bmozes' ] );

// ─── Auto-updater ─────────────────────────────────────────────────────────────
// Checks a remote JSON manifest on GitHub and surfaces a standard WordPress
// "update available" notice when a newer version is published. Same pattern
// as haifa-staff-v2's updater — Update URI header + core hooks, no library.
class UHaifa_Banners_Updater {

	private $plugin_slug;
	private $manifest_url;
	private $zip_url;
	private $current_version;

	public function __construct() {
		$this->plugin_slug     = 'uhaifa-banners/uhaifa-banners.php';
		$this->manifest_url    = 'https://raw.githubusercontent.com/HaifaUniversity/WordPressPlugins/main/uhaifa-banners.json';
		$this->zip_url         = 'https://raw.githubusercontent.com/HaifaUniversity/WordPressPlugins/main/uhaifa-banners.zip';
		$this->current_version = UHAIFA_BANNERS_VERSION;

		add_filter( 'pre_set_site_transient_update_plugins',     [ $this, 'check_for_update' ] );
		add_filter( 'plugins_api',                                [ $this, 'plugin_info' ], 10, 3 );
		add_filter( 'update_plugins_raw.githubusercontent.com',   [ $this, 'handle_update_check' ], 10, 4 );
	}

	// Fetch remote manifest (cached 12h).
	private function get_remote_data(): ?array {
		$cache = get_transient( 'uhaifa_banners_update_data' );
		if ( $cache ) return $cache;

		$response = wp_remote_get( $this->manifest_url, [ 'timeout' => 10 ] );
		if ( is_wp_error( $response ) ) return null;

		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( empty( $data['version'] ) ) return null;

		set_transient( 'uhaifa_banners_update_data', $data, 12 * HOUR_IN_SECONDS );
		return $data;
	}

	// Inject update info into WP transient so the plugins list shows the notice.
	public function check_for_update( $transient ) {
		if ( empty( $transient->checked ) ) return $transient;
		$remote = $this->get_remote_data();
		if ( ! $remote ) return $transient;
		if ( version_compare( $this->current_version, $remote['version'], '<' ) ) {
			$transient->response[ $this->plugin_slug ] = (object) [
				'slug'        => 'uhaifa-banners',
				'plugin'      => $this->plugin_slug,
				'new_version' => $remote['version'],
				'url'         => $remote['details_url'] ?? 'https://github.com/HaifaUniversity/WordPressPlugins',
				'package'     => $this->zip_url,
			];
		}
		return $transient;
	}

	// Required for Update URI header — WordPress fires this for non-wp.org plugins.
	public function handle_update_check( $update, $plugin_data, $plugin_file, $locales ) {
		if ( $plugin_file !== $this->plugin_slug ) return $update;
		$remote = $this->get_remote_data();
		if ( ! $remote ) return false;
		if ( version_compare( $this->current_version, $remote['version'], '<' ) ) {
			return (object) [
				'slug'        => 'uhaifa-banners',
				'plugin'      => $this->plugin_slug,
				'new_version' => $remote['version'],
				'url'         => $remote['details_url'] ?? 'https://github.com/HaifaUniversity/WordPressPlugins',
				'package'     => $this->zip_url,
			];
		}
		return false;
	}

	// Provide plugin details popup in wp-admin.
	public function plugin_info( $result, $action, $args ) {
		if ( $action !== 'plugin_information' ) return $result;
		if ( ( $args->slug ?? '' ) !== 'uhaifa-banners' ) return $result;
		$remote = $this->get_remote_data();
		if ( ! $remote ) return $result;
		return (object) [
			'name'          => 'אוניברסיטת חיפה - באנרים מרכזיים',
			'slug'          => 'uhaifa-banners',
			'version'       => $remote['version'],
			'author'        => 'Benny Mozes, University of Haifa',
			'homepage'      => 'https://github.com/HaifaUniversity/WordPressPlugins',
			'requires'      => $remote['requires_wp']  ?? '6.0',
			'requires_php'  => $remote['requires_php'] ?? '8.0',
			'download_link' => $this->zip_url,
			'sections'      => [
				'description' => $remote['description'] ?? '',
				'changelog'   => $remote['changelog']   ?? '',
			],
		];
	}
}

new UHaifa_Banners_Updater();

// ─── Activation: queue registration ──────────────────────────────────────────
register_activation_hook( __FILE__, function () {
	set_transient( 'uhaifa_banners_needs_registration', true, 300 );
} );

// ─── After activation: register this site with the publisher ─────────────────
add_action( 'admin_init', function () {
	if ( ! get_transient( 'uhaifa_banners_needs_registration' ) ) return;
	delete_transient( 'uhaifa_banners_needs_registration' );

	$site_url  = untrailingslashit( get_site_url() );
	$publisher = untrailingslashit( UHAIFA_BANNERS_PUBLISHER_URL );

	if ( $site_url === $publisher ) {
		// Publisher registers itself directly into the option
		$sites = get_option( 'uhaifa_registered_sites', [] );
		$found = false;
		foreach ( $sites as &$site ) {
			if ( untrailingslashit( $site['url'] ) === $site_url ) {
				$site['name']      = get_bloginfo( 'name' );
				$site['last_seen'] = time();
				$found             = true;
				break;
			}
		}
		if ( ! $found ) {
			$sites[] = [
				'url'       => $site_url,
				'name'      => get_bloginfo( 'name' ),
				'last_seen' => time(),
			];
		}
		update_option( 'uhaifa_registered_sites', $sites );

	} else {
		// Consumer calls the publisher REST endpoint
		wp_remote_post(
			trailingslashit( UHAIFA_BANNERS_PUBLISHER_URL ) . 'wp-json/uhaifa-banners/v1/register',
			[
				'timeout'   => 10,
				'sslverify' => false,
				'body'      => [
					'site_url'  => $site_url,
					'site_name' => get_bloginfo( 'name' ),
					'secret'    => UHAIFA_BANNERS_SECRET,
				],
			]
		);
	}
} );

// ─── Load classes ─────────────────────────────────────────────────────────────
require_once UHAIFA_BANNERS_DIR . 'includes/class-access-control.php';
require_once UHAIFA_BANNERS_DIR . 'includes/class-campaign-cpt.php';
require_once UHAIFA_BANNERS_DIR . 'includes/class-publisher.php';
require_once UHAIFA_BANNERS_DIR . 'includes/class-consumer.php';

new UHaifa_Banners_Access_Control();

$current_site = untrailingslashit( get_site_url() );
$publisher    = untrailingslashit( UHAIFA_BANNERS_PUBLISHER_URL );

// The campaign CPT (meta box, validation, response-building) is registered
// on EVERY site — this is what lets each site build its own local
// campaigns for the Elementor widget. Only the hub gets the Publisher
// subclass's extra REST/targeting/registration behavior on top of it.
// Stored in a global so the Elementor widget (a separate object with no
// class relationship to this one) can call get_active_local_response()
// without re-instantiating the CPT registration.
global $uhaifa_banner_cpt;
$uhaifa_banner_cpt = ( $current_site === $publisher )
	? new UHaifa_Banner_Publisher()
	: new UHaifa_Banner_CPT();

// Legacy client-side override — still needed for any hero area that hasn't
// been switched over to the Elementor widget yet.
new UHaifa_Banner_Consumer();

// מבזק קמפוס — renderer runs on every site; the CPT/admin/REST side only
// exists on the hub, where flash items are actually created.
require_once UHAIFA_BANNERS_DIR . 'includes/class-flash-renderer.php';
new UHaifa_Flash_Renderer();

if ( $current_site === $publisher ) {
	require_once UHAIFA_BANNERS_DIR . 'includes/class-flash-cpt.php';
	require_once UHAIFA_BANNERS_DIR . 'includes/class-flash-grid.php';
	new UHaifa_Flash_CPT();
	new UHaifa_Flash_Grid();
}
// ─── Elementor widget (only if Elementor is active on this site) ─────────────
// NOTE: we deliberately do NOT hook 'elementor/loaded' directly here. If
// Elementor's own plugin file happens to load (and fire that event) before
// this file runs, our add_action() would register too late to ever catch
// it — 'elementor/loaded' fires once, synchronously, wherever Elementor's
// own bootstrap code sits, not on a schedule we control. Checking
// did_action() on 'plugins_loaded' (priority 20, so it runs after every
// plugin — Elementor included — has had its file loaded and its own
// plugins_loaded-time hooks fired) works regardless of plugin load order.
add_action( 'plugins_loaded', function () {
	if ( ! did_action( 'elementor/loaded' ) && ! defined( 'ELEMENTOR_VERSION' ) ) return;
	require_once UHAIFA_BANNERS_DIR . 'includes/class-elementor-integration.php';
}, 20 );
