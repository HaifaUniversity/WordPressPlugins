<?php
/**
 * Resolves "what flash items is the hub currently publishing?" — runs on
 * EVERY site (spoke and hub alike), cached the same way as
 * UHaifa_Banner_Override_Resolver (transient, UHAIFA_BANNERS_CACHE_TTL).
 *
 * Deliberately returns ALL currently-in-range items, unfiltered by referrer.
 * Referrer matching happens locally in UHaifa_Flash_Renderer against this
 * cached payload — matching server-side on the hub per-request would defeat
 * the cache, since the referrer differs on every pageview.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class UHaifa_Flash_Resolver {

	public static function get_payload() {
		$site_url  = untrailingslashit( get_site_url() );
		$cache_key = 'uhaifa_flash_' . md5( $site_url );

		$cached = get_transient( $cache_key );
		if ( $cached !== false ) {
			return $cached === 'none' ? null : $cached;
		}

		$publisher = untrailingslashit( UHAIFA_BANNERS_PUBLISHER_URL );

		if ( $site_url === $publisher ) {
			$req  = new WP_REST_Request( 'GET', '/uhaifa-banners/v1/flash' );
			$res  = rest_do_request( $req );
			$data = $res->get_data();

		} else {
			$endpoint = trailingslashit( UHAIFA_BANNERS_PUBLISHER_URL ) . 'wp-json/uhaifa-banners/v1/flash';

			$response = uhaifa_banners_remote_request( 'GET', $endpoint, [ 'timeout' => 5 ] );

			if ( is_wp_error( $response )
			     || wp_remote_retrieve_response_code( $response ) !== 200 ) {
				set_transient( $cache_key, 'none', 60 );
				return null;
			}

			$data = json_decode( wp_remote_retrieve_body( $response ), true );
		}

		$has_content = $data && is_array( $data ) && ! empty( $data['items'] );

		if ( $has_content ) {
			set_transient( $cache_key, $data, UHAIFA_BANNERS_CACHE_TTL );
			return $data;
		}

		set_transient( $cache_key, 'none', UHAIFA_BANNERS_CACHE_TTL );
		return null;
	}
}
