<?php
/**
 * Registers the Hero widget under the "university" Elementor category
 * (owned by the haifa-staff plugin — see haifa_staff_v2_add_elementor_categories()).
 * Falls back to registering "university" ourselves if haifa-staff is
 * inactive or hasn't registered it yet, so the widget is never left
 * orphaned with nowhere to appear. Only ever loaded from
 * uhaifa-banners.php after confirming Elementor is active.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'elementor/elements/categories_registered', function ( $elements_manager ) {
	$existing = $elements_manager->get_categories();
	if ( isset( $existing['university'] ) ) return; // haifa-staff already registered it

	$elements_manager->add_category( 'university', [
		'title' => 'אוניברסיטה',
		'icon'  => 'fa fa-university',
	] );
}, 20 ); // after haifa-staff's own (default priority 10) registration

add_action( 'elementor/widgets/register', function ( $widgets_manager ) {
	try {
		require_once __DIR__ . '/class-elementor-widget.php';

		if ( ! class_exists( 'UHaifa_Elementor_Hero_Widget' ) ) {
			error_log( 'uhaifa-banners: UHaifa_Elementor_Hero_Widget class does not exist after require — check that \Elementor\Widget_Base is available at this point, and check for a parse error in class-elementor-widget.php or its own requires (class-hero-renderer.php / class-override-resolver.php / class-campaign-cpt.php).' );
			return;
		}

		$widgets_manager->register( new UHaifa_Elementor_Hero_Widget() );
		error_log( 'uhaifa-banners: UHaifa_Elementor_Hero_Widget registered successfully.' );

	} catch ( \Throwable $e ) {
		error_log( sprintf(
			'uhaifa-banners: widget registration threw %s: %s in %s:%d',
			get_class( $e ), $e->getMessage(), $e->getFile(), $e->getLine()
		) );
	}
} );

// Register (NOT enqueue) the front-end assets on wp_enqueue_scripts — this
// runs before <head> is printed, unlike enqueueing inside the widget's own
// render() (which happens mid-body, too late for a <style> to ever reach
// the page). Elementor's get_style_depends()/get_script_depends() on the
// widget then pulls these in at the correct time, only on pages that
// actually use the widget.
add_action( 'wp_enqueue_scripts', function () {
	wp_register_style( 'uhaifa-hero', UHAIFA_BANNERS_URL . 'assets/uhaifa-hero.css', [], UHAIFA_BANNERS_VERSION );
	wp_register_script( 'uhaifa-hero', UHAIFA_BANNERS_URL . 'assets/uhaifa-hero.js', [ 'jquery', 'elementor-frontend' ], UHAIFA_BANNERS_VERSION, true );
} );

// Elementor < 3.5 fallback (older hook name).
add_action( 'elementor/widgets/widgets_registered', function ( $widgets_manager ) {
	try {
		require_once __DIR__ . '/class-elementor-widget.php';
		if ( class_exists( 'UHaifa_Elementor_Hero_Widget' ) && method_exists( $widgets_manager, 'register_widget_type' ) ) {
			$widgets_manager->register_widget_type( new UHaifa_Elementor_Hero_Widget() );
		}
	} catch ( \Throwable $e ) {
		error_log( sprintf(
			'uhaifa-banners: legacy widget registration threw %s: %s in %s:%d',
			get_class( $e ), $e->getMessage(), $e->getFile(), $e->getLine()
		) );
	}
} );
