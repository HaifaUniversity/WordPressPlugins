<?php
/**
 * Publisher class — runs ONLY on the hub site (UHAIFA_BANNERS_PUBLISHER_URL).
 * Extends UHaifa_Banner_CPT (which handles CPT registration, the meta box,
 * validation, save, and response-building — see that file) and adds back
 * exactly the hub-specific concepts:
 *   - REST routes so other sites can register themselves and ask "what's
 *     active for me?"
 *   - Site targeting (this_site / all / specific) on top of the base
 *     class's date-based "is this campaign live?" logic.
 *   - The registered-sites list + 'target' admin column.
 *   - Cache invalidation (uhaifa_banners_last_updated + this site's own
 *     consumer-cache transient) whenever a campaign is saved/updated.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once __DIR__ . '/class-campaign-cpt.php';

class UHaifa_Banner_Publisher extends UHaifa_Banner_CPT {

	public function __construct() {
		parent::__construct();
		add_action( 'rest_api_init', [ $this, 'register_rest_routes' ] );
		add_action( 'post_updated',  [ $this, 'on_banner_updated' ], 10, 1 );
		add_action( 'wp_ajax_uhaifa_push_now', [ $this, 'ajax_push_now' ] );
		add_action( 'admin_enqueue_scripts',   [ $this, 'enqueue_push_now_assets' ] );
	}

	// ─── Extension points from UHaifa_Banner_CPT ───────────────────────────

	protected function cpt_labels() {
		return [
			'name'               => 'באנרים מרכזיים',
			'all_items'          => 'באנרים מרכזיים',
			'singular_name'      => 'באנר',
			'add_new'            => 'הוסף באנר',
			'add_new_item'       => 'הוסף באנר חדש',
			'edit_item'          => 'ערוך באנר',
			'view_item'          => 'צפה בבאנר',
			'search_items'       => 'חפש באנרים',
			'not_found'          => 'לא נמצאו באנרים.',
			'menu_name'          => 'הודעות ובאנרים',
		];
	}

	protected function render_target_section( $post ) {
		$target_type  = get_post_meta( $post->ID, '_uhaifa_target_type',  true ) ?: 'this_site';
		$target_sites = get_post_meta( $post->ID, '_uhaifa_target_sites', true ) ?: [];
		$registered   = get_option( 'uhaifa_registered_sites', [] );

		ob_start();
		?>
		<div class="uhaifa-settings-section">
			<h3 class="uhaifa-settings-section-title">אתרי יעד</h3>

			<div class="uhaifa-field">
				<div class="uhaifa-radio-group">
					<label>
						<input type="radio" name="uhaifa_target_type" value="this_site"
						       <?php checked( $target_type, 'this_site' ); ?>>
						רק האתר הזה
					</label>
					<label>
						<input type="radio" name="uhaifa_target_type" value="all"
						       <?php checked( $target_type, 'all' ); ?>>
						כל האתרים הרשומים
					</label>
					<label>
						<input type="radio" name="uhaifa_target_type" value="specific"
						       <?php checked( $target_type, 'specific' ); ?>>
						אתרים ספציפיים בלבד
					</label>
				</div>

				<div id="uhaifa-sites-list"
				     class="uhaifa-sites-list"
				     style="<?php echo $target_type !== 'specific' ? 'display:none' : ''; ?>">
					<?php if ( empty( $registered ) ) : ?>
						<p class="description">
							אין אתרים רשומים עדיין. אתרים נרשמים אוטומטית עם הפעלת התוסף.
						</p>
					<?php else : ?>
						<?php foreach ( $registered as $site ) : ?>
							<label class="uhaifa-site-checkbox">
								<input type="checkbox"
								       name="uhaifa_target_sites[]"
								       value="<?php echo esc_attr( $site['url'] ); ?>"
								       <?php checked( in_array( $site['url'], (array) $target_sites ) ); ?>>
								<strong><?php echo esc_html( $site['name'] ); ?></strong>
								<span class="uhaifa-site-url"><?php echo esc_html( $site['url'] ); ?></span>
							</label>
						<?php endforeach; ?>
					<?php endif; ?>
				</div>
			</div>

			<?php if ( ! empty( $registered ) ) : ?>
			<div class="uhaifa-info-box" style="margin-top:12px;">
				<strong>אתרים רשומים:</strong>
				<?php echo count( $registered ); ?> אתר/ים מחובר/ים
			</div>
			<?php endif; ?>

			<?php if ( $post->post_status !== 'auto-draft' ) : ?>
			<div class="uhaifa-push-now-wrap">
				<button type="button" id="uhaifa-push-now" class="button button-secondary" data-post-id="<?php echo esc_attr( $post->ID ); ?>">🚀 עדכן עכשיו באתרי היעד</button>
				<span id="uhaifa-push-now-spinner" class="spinner"></span>
				<p class="description">שולח בקשת רענון מיידית לאתרי היעד השמורים, במקום להמתין עד 5 דקות.</p>
				<div id="uhaifa-push-now-results"></div>
			</div>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	protected function save_target_meta( $post_id ) {
		if ( isset( $_POST['uhaifa_target_type'] ) ) {
			update_post_meta( $post_id, '_uhaifa_target_type', sanitize_key( $_POST['uhaifa_target_type'] ) );
		}

		$sites = [];
		if ( isset( $_POST['uhaifa_target_sites'] ) && is_array( $_POST['uhaifa_target_sites'] ) ) {
			$sites = array_map( 'esc_url_raw', $_POST['uhaifa_target_sites'] );
		}
		update_post_meta( $post_id, '_uhaifa_target_sites', $sites );
	}

	protected function after_save_meta( $post_id ) {
		// Bump last_updated so consumers know caches are stale
		update_option( 'uhaifa_banners_last_updated', time() );

		// Clear publisher's own local consumer cache
		delete_transient( 'uhaifa_banner_' . md5( untrailingslashit( get_site_url() ) ) );
	}

	public function on_banner_updated( $post_id ) {
		if ( get_post_type( $post_id ) !== 'uhaifa_banner' ) return;
		update_option( 'uhaifa_banners_last_updated', time() );
		delete_transient( 'uhaifa_banner_' . md5( untrailingslashit( get_site_url() ) ) );
	}

	// ─── Push Now (manual cache warm-up) ───────────────────────────────────────

	public function enqueue_push_now_assets( $hook ) {
		if ( ! in_array( $hook, [ 'post.php', 'post-new.php' ] ) ) return;
		$screen = get_current_screen();
		if ( ! $screen || $screen->post_type !== 'uhaifa_banner' ) return;

		wp_localize_script( 'uhaifa-banners-admin', 'uhaifaPushNow', [
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'uhaifa_push_now' ),
		] );
	}

	/**
	 * Note: no capability check here beyond the logged-in-only wp_ajax_
	 * prefix + nonce — the button itself only ever renders on the campaign
	 * edit screen, which class-access-control.php already gates via
	 * username whitelist, not WP capabilities (see that class's docblock
	 * re: WPCode intercepting map_meta_cap). Adding a manage_options check
	 * here would be redundant at best and could silently misfire the same
	 * way the capability approach did elsewhere.
	 */
	public function ajax_push_now() {
		check_ajax_referer( 'uhaifa_push_now', 'nonce' );

		$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
		if ( ! $post_id || get_post_type( $post_id ) !== 'uhaifa_banner' ) {
			wp_send_json_error( [ 'message' => 'קמפיין לא תקין' ] );
		}

		$target_type  = get_post_meta( $post_id, '_uhaifa_target_type',  true ) ?: 'this_site';
		$target_sites = get_post_meta( $post_id, '_uhaifa_target_sites', true ) ?: [];
		$registered   = get_option( 'uhaifa_registered_sites', [] );

		$sites_to_push = [];
		if ( $target_type === 'all' ) {
			foreach ( $registered as $site ) $sites_to_push[] = $site['url'];
		} elseif ( $target_type === 'specific' ) {
			$sites_to_push = (array) $target_sites;
		}

		$publisher_url = untrailingslashit( UHAIFA_BANNERS_PUBLISHER_URL );
		$results       = [];

		foreach ( $sites_to_push as $site_url ) {
			$site_url = untrailingslashit( $site_url );
			if ( $site_url === $publisher_url ) continue; // hub already refreshed itself on save

			$response = wp_remote_post(
				trailingslashit( $site_url ) . 'wp-json/uhaifa-banners/v1/warm-cache',
				[
					'timeout'   => 8,
					'sslverify' => false,
					'body'      => [ 'secret' => UHAIFA_BANNERS_SECRET ],
				]
			);

			$results[] = [
				'url'     => $site_url,
				'success' => ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200,
			];
		}

		wp_send_json_success( [ 'results' => $results ] );
	}

	// ─── REST Routes ──────────────────────────────────────────────────────────

	public function register_rest_routes() {

		// POST /wp-json/uhaifa-banners/v1/register
		register_rest_route( 'uhaifa-banners/v1', '/register', [
			'methods'             => 'POST',
			'callback'            => [ $this, 'handle_register' ],
			'permission_callback' => [ $this, 'verify_secret' ],
		] );

		// GET /wp-json/uhaifa-banners/v1/active?site=https://law.haifa.ac.il
		register_rest_route( 'uhaifa-banners/v1', '/active', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'handle_active' ],
			'permission_callback' => '__return_true',
		] );

		// GET /wp-json/uhaifa-banners/v1/last-updated
		register_rest_route( 'uhaifa-banners/v1', '/last-updated', [
			'methods'             => 'GET',
			'callback'            => function () {
				return rest_ensure_response( [ 'timestamp' => (int) get_option( 'uhaifa_banners_last_updated', 0 ) ] );
			},
			'permission_callback' => '__return_true',
		] );
	}

	public function verify_secret( WP_REST_Request $request ) {
		return $request->get_param( 'secret' ) === UHAIFA_BANNERS_SECRET;
	}

	public function handle_register( WP_REST_Request $request ) {
		$site_url  = untrailingslashit( esc_url_raw( $request->get_param( 'site_url' ) ) );
		$site_name = sanitize_text_field( $request->get_param( 'site_name' ) );

		if ( ! $site_url ) {
			return new WP_Error( 'invalid', 'Invalid site URL', [ 'status' => 400 ] );
		}

		$sites = get_option( 'uhaifa_registered_sites', [] );
		$found = false;

		foreach ( $sites as &$site ) {
			if ( untrailingslashit( $site['url'] ) === $site_url ) {
				$site['name']      = $site_name;
				$site['last_seen'] = time();
				$found             = true;
				break;
			}
		}
		unset( $site );

		if ( ! $found ) {
			$sites[] = [
				'url'       => $site_url,
				'name'      => $site_name,
				'last_seen' => time(),
			];
		}

		update_option( 'uhaifa_registered_sites', $sites );
		return rest_ensure_response( [ 'success' => true, 'sites_count' => count( $sites ) ] );
	}

	/**
	 * Returns the single currently-live campaign (if any) targeted to the
	 * requesting site. Shape depends on the campaign's banner type — see
	 * UHaifa_Banner_CPT::build_image_response() / build_dynamic_response().
	 * Always a 200 response; 'slides' and 'items' are both [] when nothing
	 * is active, so the consumer's emptiness check works regardless of type.
	 */
	public function handle_active( WP_REST_Request $request ) {
		$requesting_site = untrailingslashit( esc_url_raw( $request->get_param( 'site' ) ) );
		$now             = current_time( 'Y-m-d H:i' );
		$duration        = (int) get_option( 'uhaifa_banners_slide_duration', 5000 );

		// Ordered by the campaign's own _uhaifa_date_start (most recent
		// first), not by post_date/last-saved-time. Rule 2/3 in
		// validate_before_save() should always prevent more than one
		// candidate from matching here, but if that's ever bypassed
		// (direct DB edit, a future save path we haven't guarded, etc.),
		// this makes the tie-break "whichever campaign's own schedule is
		// most current" rather than "whichever was clicked/saved last in
		// wp-admin" — a more predictable and defensible fallback.
		$banners = get_posts( [
			'post_type'      => 'uhaifa_banner',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'meta_query'     => [
				'date_start_clause' => [
					'key'     => '_uhaifa_date_start',
					'value'   => $now,
					'compare' => '<=',
					'type'    => 'DATETIME',
				],
			],
			'orderby' => 'date_start_clause',
			'order'   => 'DESC',
		] );

		foreach ( $banners as $banner ) {
			// Skip if end date is set and already passed
			$date_end = get_post_meta( $banner->ID, '_uhaifa_date_end', true );
			if ( $date_end && $date_end < $now ) continue;

			$target_type  = get_post_meta( $banner->ID, '_uhaifa_target_type',  true ) ?: 'this_site';
			$target_sites = get_post_meta( $banner->ID, '_uhaifa_target_sites', true ) ?: [];

			// Targeting check
			if ( $target_type === 'this_site' ) {
				$publisher_url = untrailingslashit( UHAIFA_BANNERS_PUBLISHER_URL );
				if ( $requesting_site !== $publisher_url ) continue;
			} elseif ( $target_type === 'specific' && $requesting_site ) {
				$match = false;
				foreach ( $target_sites as $ts ) {
					if ( untrailingslashit( $ts ) === $requesting_site ) {
						$match = true;
						break;
					}
				}
				if ( ! $match ) continue;
			}

			$response = $this->build_response_for_banner( $banner, $duration, $date_end );
			if ( $response === null ) continue; // campaign has no usable content, skip it

			return rest_ensure_response( $response );
		}

		// Nothing active
		return rest_ensure_response( [
			'id'       => null,
			'type'     => null,
			'duration' => $duration,
			'slides'   => [],
			'items'    => [],
			'expires'  => null,
		] );
	}

	// ─── CPT List Columns ─────────────────────────────────────────────────────

	public function cpt_columns( $cols ) {
		$cols = parent::cpt_columns( $cols );

		// Insert 'target' right after 'slides', before the date columns.
		$with_target = [];
		foreach ( $cols as $key => $label ) {
			$with_target[ $key ] = $label;
			if ( $key === 'slides' ) {
				$with_target['target'] = 'יעד';
			}
		}
		return $with_target;
	}

	public function cpt_column_content( $col, $post_id ) {
		if ( $col !== 'target' ) {
			parent::cpt_column_content( $col, $post_id );
			return;
		}

		$type = get_post_meta( $post_id, '_uhaifa_target_type', true ) ?: 'this_site';
		if ( $type === 'all' ) {
			echo '<span style="color:#00a32a">⬤ כל האתרים</span>';
		} elseif ( $type === 'this_site' ) {
			echo '<span style="color:#787c82">⬤ רק אתר זה</span>';
		} else {
			$sites = get_post_meta( $post_id, '_uhaifa_target_sites', true ) ?: [];

			if ( empty( $sites ) ) {
				echo '<span style="color:#d63638">⬤ לא נבחרו אתרים</span>';
				return;
			}

			$registered   = get_option( 'uhaifa_registered_sites', [] );
			$names_by_url = [];
			foreach ( $registered as $site ) {
				$names_by_url[ untrailingslashit( $site['url'] ) ] = $site['name'];
			}

			echo '<span style="color:#2271b1">⬤ ' . count( $sites ) . ' אתר/ים:</span>';
			echo '<ul style="margin:4px 0 0 0;padding-left:16px;font-size:12px;">';
			foreach ( $sites as $url ) {
				$clean = untrailingslashit( $url );
				$label = $names_by_url[ $clean ] ?? $clean;
				echo '<li><a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $label ) . '</a></li>';
			}
			echo '</ul>';
		}
	}
}
