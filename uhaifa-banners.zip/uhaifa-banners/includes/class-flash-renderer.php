<?php
/**
 * Front-end renderer for מבזק קמפוס — runs on EVERY site.
 *
 * Homepage: shows every currently-active item, auto-rotating — always, by
 * default.
 * Any other (internal) page: shows the same rotating set, but ONLY if the
 * visitor arrived via a link from an external site (not internal on-site
 * navigation), once per browser session (sessionStorage, see
 * uhaifa-topbar.js).
 * Renders nothing at all when there's no active content for this pageview.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once __DIR__ . '/class-flash-resolver.php';

class UHaifa_Flash_Renderer {

	private $payload      = null;
	private $page_items   = [];
	private $is_once_mode = false;

	public function __construct() {
		add_action( 'wp',                 [ $this, 'prepare' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'maybe_enqueue' ] );
		add_action( 'wp_body_open',       [ $this, 'render' ] );
	}

	// ─── 1. Decide what (if anything) shows on this pageview ──────────────────

	public function prepare() {
		if ( is_admin() ) return;

		$this->payload = UHaifa_Flash_Resolver::get_payload();
		if ( ! $this->payload || empty( $this->payload['items'] ) ) return;

		if ( is_front_page() || is_home() ) {
			$this->page_items = $this->payload['items'];
			return;
		}

		$referrer = wp_get_referer();
		if ( ! $referrer && ! empty( $_SERVER['HTTP_REFERER'] ) ) {
			$referrer = esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) );
		}
		if ( ! $referrer ) return; // no referrer at all — direct visit/refresh, don't show here

		$referrer_host = wp_parse_url( $referrer, PHP_URL_HOST );
		$site_host     = wp_parse_url( home_url(), PHP_URL_HOST );

		// Only show on an internal page if the visitor came from somewhere
		// OUTSIDE this site — plain on-site navigation between pages never
		// triggers it here (that's what the homepage default is for).
		if ( ! $referrer_host || ! $site_host || strtolower( $referrer_host ) === strtolower( $site_host ) ) {
			return;
		}

		$this->is_once_mode = true;
		$this->page_items   = $this->payload['items'];
	}

	// ─── 2. Enqueue assets only when there's something to show ────────────────

	public function maybe_enqueue() {
		if ( empty( $this->page_items ) ) return;

		wp_enqueue_style(
			'uhaifa-topbar',
			UHAIFA_BANNERS_URL . 'assets/uhaifa-topbar.css',
			[],
			UHAIFA_BANNERS_VERSION
		);

		wp_enqueue_script(
			'uhaifa-topbar',
			UHAIFA_BANNERS_URL . 'assets/uhaifa-topbar.js',
			[],
			UHAIFA_BANNERS_VERSION,
			true
		);
	}

	// ─── 3. Render ──────────────────────────────────────────────────────────

	public function render() {
		if ( empty( $this->page_items ) ) return;

		$logo_url    = $this->payload['logo_url'] ?? '';
		$item_ids    = wp_list_pluck( $this->page_items, 'id' );
		$storage_key = 'uhaifaFlashShown_' . md5( implode( ',', $item_ids ) );
		$dir         = is_rtl() ? 'rtl' : 'ltr';
		?>
		<div id="uhaifa-flash"
		     class="uhaifa-flash uhaifa-flash--<?php echo esc_attr( $dir ); ?>"
		     data-dir="<?php echo esc_attr( $dir ); ?>"
		     <?php if ( $this->is_once_mode ) : ?>
		     data-once="1"
		     data-storage-key="<?php echo esc_attr( $storage_key ); ?>"
		     <?php endif; ?>
		     style="display:none;">
			<div class="uhaifa-flash-inner">
				<div class="uhaifa-flash-label-group">
					<?php if ( $logo_url ) : ?>
						<img class="uhaifa-flash-logo" src="<?php echo esc_url( $logo_url ); ?>" alt="אוניברסיטת חיפה">
					<?php endif; ?>
					<span class="uhaifa-flash-label">מבזק קמפוס</span>
				</div>
				<div class="uhaifa-flash-viewport">
					<div class="uhaifa-flash-items">
						<?php foreach ( $this->page_items as $item ) : ?>
							<div class="uhaifa-flash-item">
								<?php if ( ! empty( $item['link'] ) ) : ?>
									<a href="<?php echo esc_url( $item['link'] ); ?>"><?php echo esc_html( $item['message'] ); ?></a>
								<?php else : ?>
									<?php echo esc_html( $item['message'] ); ?>
								<?php endif; ?>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
				<button type="button" class="uhaifa-flash-dismiss" aria-label="סגור">×</button>
			</div>
		</div>
		<?php
	}
}
