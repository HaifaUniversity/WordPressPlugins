<?php
/**
 * Access control — restricts the entire uhaifa_banner admin UI (top-level
 * menu, CPT list/edit/new screens, and the settings submenu) to a fixed
 * whitelist of usernames, except on local/dev environments where everyone
 * gets full access.
 *
 * Deliberately NOT capability-based. An earlier version granted a custom
 * 'manage_uhaifa_banners' capability via a 'user_has_cap' filter, but on
 * sites running WPCode (Insert Headers and Footers), a 'map_meta_cap'
 * hardening callback in that plugin denies any capability string it
 * doesn't recognize as core/standard WordPress — a defense against a
 * known capability-confusion vulnerability class, which has the side
 * effect of blocking legitimate custom capabilities from other plugins
 * too. Since map_meta_cap runs before user_has_cap, that denial can't be
 * out-prioritized from our side.
 *
 * This version sidesteps the problem entirely: no custom capability is
 * checked anywhere. Access is gated purely by comparing the current
 * user's username against the whitelist, directly on 'admin_menu' (to
 * hide the menu item) and on the specific page-load hooks (to hard-block
 * direct URL access even if the menu is hidden).
 *
 * To change who has access: edit UHAIFA_BANNERS_ADMIN_USERS in
 * uhaifa-banners.php — that's the single source of truth.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class UHaifa_Banners_Access_Control {

		// Relative path used as the array key in the 'all_plugins' filter —
	// must match the actual folder/file name as installed.
	private $plugin_basename = 'uhaifa-banners/uhaifa-banners.php';

	public function __construct() {
		add_action( 'admin_menu', [ $this, 'hide_menu_for_others' ], 999 );

		add_action( 'load-edit.php',     [ $this, 'block_direct_access' ] );
		add_action( 'load-post.php',     [ $this, 'block_direct_access' ] );
		add_action( 'load-post-new.php', [ $this, 'block_direct_access' ] );

		// The settings submenu's load-{hook} name depends on the parent
		// menu slug WordPress generates for the CPT; this covers it
		// without hardcoding the generated hook string.
		add_action( 'current_screen', [ $this, 'block_settings_page' ] );

		// Hides the plugin's own row from Plugins > Installed Plugins for
		// anyone not on the whitelist (still active either way — this
		// only affects what's visible in the list, not activation state).
		add_filter( 'all_plugins', [ $this, 'hide_from_plugins_list' ] );
	}

	public function hide_from_plugins_list( $plugins ) {
		if ( $this->is_allowed_user() ) return $plugins;
		unset( $plugins[ $this->plugin_basename ] );
		return $plugins;
	}
	/**
	 * True on local/dev environments, or for an EXACT whitelisted username
	 * that also holds the core 'edit_posts' capability (a core cap, so
	 * WPCode's map_meta_cap hardening doesn't affect it). Public + static
	 * so AJAX handlers elsewhere (Push Now) reuse the same gate. Existing
	 * $this->is_allowed_user() calls keep working.
	 */
	public static function is_allowed_user() {
		if ( uhaifa_banners_is_local_env() ) return true;
		if ( ! is_user_logged_in() ) return false;

		$user = wp_get_current_user();
		if ( empty( $user->user_login ) ) return false;
		if ( ! current_user_can( 'edit_posts' ) ) return false;

		$allowed = array_map( 'strtolower', (array) UHAIFA_BANNERS_ADMIN_USERS );
		return in_array( strtolower( $user->user_login ), $allowed, true );
	}

	public function hide_menu_for_others() {
		if ( $this->is_allowed_user() ) return;
		remove_menu_page( 'edit.php?post_type=uhaifa_banner' );
	}

	/**
	 * Hard-blocks edit.php / post.php / post-new.php for our CPT when
	 * accessed directly by URL, even though the menu is already hidden.
	 */
	public function block_direct_access() {
		if ( $this->is_allowed_user() ) return;

		$post_type = '';
		if ( isset( $_GET['post_type'] ) ) {
			$post_type = sanitize_key( $_GET['post_type'] );
		} elseif ( isset( $_GET['post'] ) ) {
			$post_type = get_post_type( absint( $_GET['post'] ) );
		}

		if ( $post_type === 'uhaifa_banner' ) {
			wp_die( 'אין לך הרשאה לגשת לעמוד זה.', 'שגיאת הרשאה', [ 'response' => 403 ] );
		}
	}

	/**
	 * Blocks the settings submenu (?page=uhaifa-banners-settings) the
	 * same way, checked on current_screen since its load-{hook} slug is
	 * generated dynamically by WordPress.
	 */
	public function block_settings_page() {
		if ( $this->is_allowed_user() ) return;

		if ( isset( $_GET['page'] ) && $_GET['page'] === 'uhaifa-banners-settings' ) {
			wp_die( 'אין לך הרשאה לגשת לעמוד זה.', 'שגיאת הרשאה', [ 'response' => 403 ] );
		}
	}
}