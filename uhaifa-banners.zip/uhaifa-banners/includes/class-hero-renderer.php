<?php
/**
 * Server-side markup renderer for the hero banner — a PHP port of the
* DOM-building functions in assets/uhaifa-consumer.js (buildImageBanner,
 * buildDynamicBanner, buildBgMarkup, etc.), producing the exact same
  * classes/structure so uhaifa-hero.css (a copy of uhaifa-consumer.css)
 * applies unchanged and so uhaifa-hero.js only has to ATTACH behavior
 * (rotation timers, YouTube IFrame API players) to markup that already
 * exists, instead of building it.
 *
 * Used by UHaifa_Elementor_Hero_Widget for BOTH of its content sources
 * (local campaign / posts-by-tag) and for a hub override payload — same
 * $data shape either way: { type, duration, slides[], items[], bg_mode?,
 * background? } as produced by UHaifa_Banner_CPT::build_image_response() /
 * build_dynamic_response(), or the hub's REST /active payload (identical
 * shape).
 *
 * NOTE on YouTube backgrounds: per the front-end JS's own notes, a brief
 * center play/pause icon on load is an accepted YouTube-embed limitation,
 * not something this renderer or the controller script can suppress.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class UHaifa_Hero_Renderer {

	/**
	 * @param array $data            {type, duration, slides[], items[], bg_mode?, background?}
	 * @param array $wrapper_classes Extra classes for the outer wrapper (e.g. ['uhaifa-hero-widget']).
	 * @param array $wrapper_attrs   Extra raw attributes for the outer wrapper, already
	 *                               escaped-safe key=>value pairs (e.g. ['id' => 'uhaifa-hero-3']).
	 */
	public static function render( array $data, array $wrapper_classes = [], array $wrapper_attrs = [] ) {
		$is_dynamic = ( $data['type'] ?? 'image' ) === 'dynamic';

		$has_content = $is_dynamic
			? ! empty( $data['items'] )
			: ! empty( $data['slides'] );

		if ( ! $has_content ) return '';

		return $is_dynamic
			? self::render_dynamic_banner( $data, $wrapper_classes, $wrapper_attrs )
			: self::render_image_banner( $data, $wrapper_classes, $wrapper_attrs );
	}

	// ══════════════════════════ IMAGE TYPE ═════════════════════════════════

	private static function render_image_banner( $data, $wrapper_classes, $wrapper_attrs ) {
		$slides   = $data['slides'];
		$duration = $data['duration'] ?? 5000;

		$classes = array_merge( [ 'uhaifa-banner-override' ], $wrapper_classes );
		$attrs   = array_merge( $wrapper_attrs, [
			'data-uh-type'     => 'image',
			'data-uh-duration' => (string) (int) $duration,
		] );

		$html = '<div ' . self::build_attrs( $classes, $attrs ) . '>';
		foreach ( $slides as $i => $slide ) {
			$html .= self::build_image_slide( $slide, $i === 0 );
		}
		$html .= '</div>';

		return $html;
	}

	private static function build_image_slide( $slide, $is_first ) {
		$desktop_img = '<img'
			. ' src="'   . esc_url( $slide['desktop'] ) . '"'
			. ' alt="'   . esc_attr( $slide['alt'] ?? '' ) . '"'
			. ' class="uhaifa-img uhaifa-img-desktop"'
			. ' loading="' . ( $is_first ? 'eager' : 'lazy' ) . '"'
			. '>';

		$mobile_img = ! empty( $slide['mobile'] )
			? '<img'
			  . ' src="'   . esc_url( $slide['mobile'] ) . '"'
			  . ' alt="'   . esc_attr( $slide['alt'] ?? '' ) . '"'
			  . ' class="uhaifa-img uhaifa-img-mobile"'
			  . ' loading="' . ( $is_first ? 'eager' : 'lazy' ) . '"'
			  . '>'
			: '';

		$inner = $desktop_img . $mobile_img;

		if ( ! empty( $slide['link_url'] ) ) {
			$target = $slide['link_target'] ?? '_blank';
			$rel    = $target === '_self' ? '' : 'noopener noreferrer';
			$inner  = '<a href="' . esc_url( $slide['link_url'] ) . '"'
				. ' target="' . esc_attr( $target ) . '"'
				. ' rel="' . esc_attr( $rel ) . '"'
				. '>' . $inner . '</a>';
		}

		$class = 'uhaifa-slide' . ( $is_first ? ' uhaifa-slide-active' : '' );
		return '<div class="' . esc_attr( $class ) . '">' . $inner . '</div>';
	}

	// ══════════════════════════ DYNAMIC TYPE ════════════════════════════════

	private static function render_dynamic_banner( $data, $wrapper_classes, $wrapper_attrs ) {
		$duration = $data['duration'] ?? 5000;
		$bg_mode  = $data['bg_mode']  ?? 'shared';
		$items    = $data['items'];

		$classes = array_merge( [ 'uhaifa-banner-override', 'uhaifa-banner-dynamic' ], $wrapper_classes );
		$classes[] = $bg_mode === 'shared' ? 'uhaifa-bg-shared' : ( $bg_mode === 'multi' ? 'uhaifa-bg-multi' : 'uhaifa-bg-per-item' );

		$attrs = array_merge( $wrapper_attrs, [
			'data-uh-type'     => 'dynamic',
			'data-uh-bg-mode'  => $bg_mode,
			'data-uh-duration' => (string) (int) $duration,
		] );

		$html = '<div ' . self::build_attrs( $classes, $attrs ) . '>';

		if ( $bg_mode === 'multi' ) {
			// N rotating background-only slides, one PERMANENT text overlay
			// outside the rotation. No JS changes needed: each background is
			// just a plain `.uhaifa-slide`, so uhaifa-hero.js's generic
			// crossfade fallback (no video, no link-sync) already handles it
			// exactly like a plain image slideshow.
			$static_text = $data['static_text'] ?? [];

			$bg_slides = '';
			foreach ( $items as $i => $bg ) {
				$slide_class = 'uhaifa-slide' . ( $i === 0 ? ' uhaifa-slide-active' : '' );
				$bg_slides .= '<div class="' . esc_attr( $slide_class ) . '">'
					. '<div class="uhaifa-dynamic-bg">' . self::build_bg_markup( $bg, $i === 0 ) . '</div>'
					. '</div>';
			}

			$overlay = '<div class="uhaifa-dynamic-overlay">' . self::dynamic_text_markup( $static_text ) . '</div>';

			if ( ! empty( $static_text['button_url'] ) ) {
				$target = $static_text['button_target'] ?? '_blank';
				$rel    = $target === '_self' ? '' : 'noopener noreferrer';
				$html .= '<a class="uhaifa-banner-link"'
					. ' href="' . esc_url( $static_text['button_url'] ) . '"'
					. ' target="' . esc_attr( $target ) . '"'
					. ' rel="' . esc_attr( $rel ) . '"'
					. '>' . $bg_slides . $overlay . '</a>';
			} else {
				$html .= $bg_slides . $overlay;
			}

		} elseif ( $bg_mode === 'shared' ) {
			$background = $data['background'] ?? [];
			// data-youtube-id lives on the .uhaifa-dynamic-bg wrapper itself
			// (not just the inner mount div) so uhaifa-hero.js's
			// activateBgLayerVideo()/deactivateBgLayerVideo() helpers can
			// treat the shared background and each per-item background
			// identically.
			$bg_layer = '<div class="uhaifa-dynamic-bg" data-youtube-id="' . esc_attr( $background['youtube_id'] ?? '' ) . '">'
				. self::build_bg_markup( $background, true )
				. '</div>';

			$overlay = '<div class="uhaifa-dynamic-overlay">';
			foreach ( $items as $i => $item ) {
				$overlay .= self::build_dynamic_text_item( $item, $i === 0 );
			}
			$overlay .= '</div>';

			$has_any_link = false;
			foreach ( $items as $item ) {
				if ( ! empty( $item['button_url'] ) ) { $has_any_link = true; break; }
			}

			if ( $has_any_link ) {
				$first        = $items[0];
				$first_href   = $first['button_url'] ?? '';
				$first_target = $first['button_target'] ?? '_blank';
				$first_rel    = $first_target === '_self' ? '' : 'noopener noreferrer';
				$disabled     = $first_href === '' ? ' uhaifa-bg-link-disabled' : '';

				$html .= '<a class="uhaifa-banner-link' . $disabled . '"'
					. ( $first_href !== '' ? ' href="' . esc_url( $first_href ) . '"' : '' )
					. ' target="' . esc_attr( $first_target ) . '"'
					. ' rel="' . esc_attr( $first_rel ) . '"'
					. '>' . $bg_layer . $overlay . '</a>';
			} else {
				$html .= $bg_layer . $overlay;
			}
		} else {
			foreach ( $items as $i => $item ) {
				$html .= self::build_dynamic_full_item( $item, $i === 0 );
			}
		}

		$html .= '</div>';
		return $html;
	}

	/**
	 * Background markup for a fixed slot: a YouTube mount div when a video
	 * is set (desktop only — uhaifa-hero.js's YouTube IFrame API controller
	 * fills it in), otherwise nothing extra beyond the desktop image; the
	 * mobile image is always included and toggled by the responsive CSS.
	 * No desktop <img> at all when $bg['desktop'] is null (video-only or
	 * no desktop image uploaded) — avoids stretching the mobile photo into
	 * the desktop slot.
	 */
	private static function build_bg_markup( $bg, $eager ) {
		$desktop_img = ! empty( $bg['desktop'] )
			? '<img src="' . esc_url( $bg['desktop'] ) . '" alt="" class="uhaifa-img uhaifa-img-desktop" loading="' . ( $eager ? 'eager' : 'lazy' ) . '">'
			: '';

		$desktop_el = ! empty( $bg['youtube_id'] )
			? $desktop_img . self::youtube_mount_html( $bg['youtube_id'] )
			: $desktop_img;

		$mobile_el = ! empty( $bg['mobile'] )
			? '<img src="' . esc_url( $bg['mobile'] ) . '" alt="" class="uhaifa-img uhaifa-img-mobile" loading="' . ( $eager ? 'eager' : 'lazy' ) . '">'
			: '';

		return $desktop_el . $mobile_el;
	}

	/** A plain mount point — uhaifa-hero.js's YouTube IFrame API controller replaces this with a real player. */
	private static function youtube_mount_html( $youtube_id ) {
		return '<div class="uhaifa-img uhaifa-img-desktop uhaifa-yt-bg" data-youtube-id="' . esc_attr( $youtube_id ) . '"></div>';
	}

	/** Text-only rotating item used in shared-background mode. Carries its own link data attributes for rotation-sync. */
	private static function build_dynamic_text_item( $item, $is_first ) {
		$class = 'uhaifa-slide uhaifa-dynamic-item' . ( $is_first ? ' uhaifa-slide-active' : '' );

		$link_attrs = '';
		if ( ! empty( $item['button_url'] ) ) {
			$link_attrs = ' data-href="' . esc_url( $item['button_url'] ) . '"'
				. ' data-target="' . esc_attr( $item['button_target'] ?? '_blank' ) . '"';
		}

		return '<div class="' . esc_attr( $class ) . '"' . $link_attrs . '>'
			. self::dynamic_text_markup( $item )
			. '</div>';
	}

	/**
	 * Full rotating item used in per-item background mode: its own
	 * background layer (image rendered immediately; a YouTube mount is
	 * only pre-rendered for the FIRST/initially-active item, matching the
	 * JS controller's "only one video plays at a time" behavior — it lazily
	 * adds/removes mounts for later items on rotation) plus text on top.
	 */
	private static function build_dynamic_full_item( $item, $is_first ) {
		$class = 'uhaifa-slide uhaifa-dynamic-item' . ( $is_first ? ' uhaifa-slide-active' : '' );

		$bg = [
			'desktop'    => $item['desktop']    ?? null,
			'mobile'     => $item['mobile']     ?? null,
			'youtube_id' => $is_first ? ( $item['youtube_id'] ?? '' ) : '',
		];
		$bg_layer = '<div class="uhaifa-dynamic-bg"'
			. ' data-youtube-id="' . esc_attr( $item['youtube_id'] ?? '' ) . '"'
			. '>' . self::build_bg_markup( $bg, $is_first ) . '</div>';

		$overlay = '<div class="uhaifa-dynamic-overlay">' . self::dynamic_text_markup( $item ) . '</div>';

		if ( ! empty( $item['button_url'] ) ) {
			$target = $item['button_target'] ?? '_blank';
			$rel    = $target === '_self' ? '' : 'noopener noreferrer';
			$inner  = '<a class="uhaifa-banner-link"'
				. ' href="' . esc_url( $item['button_url'] ) . '"'
				. ' target="' . esc_attr( $target ) . '"'
				. ' rel="' . esc_attr( $rel ) . '"'
				. '>' . $bg_layer . $overlay . '</a>';
		} else {
			$inner = $bg_layer . $overlay;
		}

		return '<div class="' . esc_attr( $class ) . '">' . $inner . '</div>';
	}

	/** Title / body text / button markup shared by both dynamic item shapes. Button is a <span> — the whole banner/item is already one <a>. */
	private static function dynamic_text_markup( $item ) {
		$html = '<div class="uhaifa-dynamic-text">';
		if ( ! empty( $item['title'] ) ) $html .= '<h2 class="uhaifa-dynamic-title">' . esc_html( $item['title'] ) . '</h2>';
		if ( ! empty( $item['text'] ) )  $html .= '<p class="uhaifa-dynamic-text-body">' . esc_html( $item['text'] ) . '</p>';
		if ( ! empty( $item['button_url'] ) ) {
			$html .= '<span class="uhaifa-dynamic-btn">' . esc_html( $item['button_text'] ?: 'קרא עוד' ) . '</span>';
		}
		$html .= '</div>';
		return $html;
	}

	// ══════════════════════════ Shared helpers ═════════════════════════════

	private static function build_attrs( $classes, $attrs ) {
		$out = 'class="' . esc_attr( implode( ' ', array_filter( $classes ) ) ) . '"';
		foreach ( $attrs as $key => $value ) {
			$out .= ' ' . esc_attr( $key ) . '="' . esc_attr( $value ) . '"';
		}
		return $out;
	}
}
