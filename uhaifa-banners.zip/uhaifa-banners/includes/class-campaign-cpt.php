<?php
/**
 * Base campaign CPT class — runs on EVERY site (hub and consumer alike).
 * Handles: CPT registration, admin UI (multi-slide / dynamic-item repeater),
 * validation, save, and the response-building logic that turns a campaign
 * post into the array consumed by the front-end renderer.
 *
 * This class deliberately knows NOTHING about the hub/consumer network:
 * no REST routes, no site targeting, no cross-site push. A campaign saved
 * here only ever applies to ITS OWN site. UHaifa_Banner_Publisher (hub-only)
 * extends this class and adds exactly those hub concepts back in via the
 * extension points marked below (render_target_section(), save_target_meta(),
 * after_save_meta(), cpt_labels(), plus its own REST routes).
 *
 * Data model (unchanged from the original class-publisher.php):
 *   - One uhaifa_banner post = one CAMPAIGN.
 *   - Only one campaign may be "live" (published + date-active) at a time —
 *     overlapping dates are blocked at save time (see validate_before_save()).
 *   - A campaign can contain multiple SLIDES (_uhaifa_slides meta) or, for
 *     the dynamic type, multiple ITEMS (_uhaifa_dynamic_items meta).
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class UHaifa_Banner_CPT {


	public function __construct() {
		add_action( 'init',                                    [ $this, 'register_cpt' ] );
		add_action( 'add_meta_boxes',                          [ $this, 'add_meta_boxes' ] );
		add_action( 'save_post_uhaifa_banner',                 [ $this, 'save_meta' ] );
		add_action( 'admin_enqueue_scripts',                   [ $this, 'enqueue_admin_assets' ] );
		add_filter( 'manage_uhaifa_banner_posts_columns',      [ $this, 'cpt_columns' ] );
		add_action( 'manage_uhaifa_banner_posts_custom_column',[ $this, 'cpt_column_content' ], 10, 2 );
		add_filter( 'wp_insert_post_data', [ $this, 'validate_before_save' ], 10, 2 );
		add_action( 'admin_notices',       [ $this, 'show_admin_errors' ] );
		add_action( 'admin_menu',          [ $this, 'add_settings_page' ] );
		// Native WP mechanism — the same one that shows "— Draft"/"— Sticky"
		// next to a post's title in the list table.
		add_filter( 'display_post_states', [ $this, 'add_evergreen_post_state' ], 10, 2 );
	}

	// ─── Extension points (no-ops here; UHaifa_Banner_Publisher overrides) ────

	/** CPT labels. Override to rename the menu for hub vs. local use. */
	protected function cpt_labels() {
		return [
			'name'               => 'באנרים מרכזיים',
			'singular_name'      => 'קמפיין',
			'add_new'            => 'הוסף קמפיין',
			'add_new_item'       => 'הוסף קמפיין חדש',
			'edit_item'          => 'ערוך קמפיין',
			'view_item'          => 'צפה בקמפיין',
			'search_items'       => 'חפש קמפיינים',
			'not_found'          => 'לא נמצאו קמפיינים.',
			'menu_name'          => 'באנרים מרכזיים',
		];
	}

	/**
	 * Extra meta-box section rendered next to "הגדרות כלליות" (same
	 * .uhaifa-settings-section shape expected). Base returns '' — a local
	 * campaign always applies only to this site, so there's nothing to
	 * target. The hub subclass returns the this_site/all/specific UI.
	 */
	protected function render_target_section( $post ) {
		return '';
	}

	/** Persists whatever render_target_section() collects. No-op here. */
	protected function save_target_meta( $post_id ) {}

	/**
	 * Runs at the end of save_meta(), after everything else is persisted.
	 * Base does nothing — a local campaign needs no cache invalidation,
	 * since the widget reads it live via WP_Query on every request. The
	 * hub subclass uses this to bump uhaifa_banners_last_updated and clear
	 * its own consumer-cache transient.
	 */
	protected function after_save_meta( $post_id ) {}

	// ─── CPT ──────────────────────────────────────────────────────────────────

	public function register_cpt() {
		register_post_type( 'uhaifa_banner', [
			'labels'       => $this->cpt_labels(),
			'public'       => false,
			'show_ui'      => true,
			'show_in_menu' => true,
			'supports'     => [ 'title' ],
			'menu_icon'    => 'dashicons-megaphone',
			'show_in_rest' => false,
			// The SAME site-wide category/tag pool used by regular Posts —
			// not a separate banner-only taxonomy — so a sub-unit's existing
			// terms (or brand new ones) can double as campaign targeting.
			// Gives the native Categories/Tags admin meta boxes for free.
			'taxonomies'   => [ 'category', 'post_tag' ],
		] );
	}

	// ─── Validation ─────────────────────────────────────────────────────────

	public function validate_before_save( $data, $postarr ) {
		if ( $data['post_type'] !== 'uhaifa_banner' ) return $data;
		if ( $data['post_status'] !== 'publish' )     return $data;
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return $data;

		$errors  = [];
		$post_id = isset( $postarr['ID'] ) ? absint( $postarr['ID'] ) : 0;

		// Was our meta box actually submitted? Quick Edit, bulk "Publish",
		// and any other status-change path that doesn't render our meta box
		// will NOT send uhaifa_banner_nonce (or any of our other fields) —
		// in that case $_POST is empty for our purposes and must NOT be
		// treated as "no content" / "no date". Instead we re-validate the
		// campaign's already-saved data, so a Quick-Edit publish can't
		// silently dodge the completeness/conflict checks a normal save
		// would have enforced.
		$meta_box_submitted = isset( $_POST['uhaifa_banner_nonce'] )
			&& wp_verify_nonce( $_POST['uhaifa_banner_nonce'], 'uhaifa_banner_save' );

		if ( $meta_box_submitted ) {
			$banner_type  = sanitize_key( $_POST['uhaifa_banner_type'] ?? 'image' );
			$bg_mode      = sanitize_key( $_POST['uhaifa_dynamic_bg_mode'] ?? 'shared' );
			$shared_bg    = $this->sanitize_dynamic_bg_from_post_array( $_POST['uhaifa_dynamic_shared_bg'] ?? [] );
			$items        = $this->sanitize_dynamic_items_from_post();
			$static_text  = $this->sanitize_static_text_from_post( $_POST['uhaifa_dynamic_static_text'] ?? [] );
			$slides       = $this->sanitize_slides_from_post();
			$date_start   = sanitize_text_field( $_POST['uhaifa_date_start'] ?? '' );
			$date_end     = sanitize_text_field( $_POST['uhaifa_date_end']   ?? '' );
			$is_evergreen = ! empty( $_POST['uhaifa_evergreen'] );
		} else {
			// Fall back to what's already persisted for this post.
			$banner_type  = get_post_meta( $post_id, '_uhaifa_banner_type', true ) ?: 'image';
			$bg_mode      = get_post_meta( $post_id, '_uhaifa_dynamic_bg_mode', true ) ?: 'shared';
			$shared_bg    = get_post_meta( $post_id, '_uhaifa_dynamic_shared_bg', true );
			$shared_bg    = is_array( $shared_bg ) ? $shared_bg : [];
			$items        = get_post_meta( $post_id, '_uhaifa_dynamic_items', true );
			$items        = is_array( $items ) ? $items : [];
			$static_text  = get_post_meta( $post_id, '_uhaifa_dynamic_static_text', true );
			$static_text  = is_array( $static_text ) ? $static_text : [];
			$slides       = get_post_meta( $post_id, '_uhaifa_slides', true );
			$slides       = is_array( $slides ) ? $slides : [];
			$date_start   = get_post_meta( $post_id, '_uhaifa_date_start', true );
			$date_end     = get_post_meta( $post_id, '_uhaifa_date_end',   true );
			$is_evergreen = (bool) get_post_meta( $post_id, '_uhaifa_evergreen', true );
		}

		// Rule 1: campaign must have at least one usable, complete content
		// unit. What "complete" means depends on the banner type.
		if ( $banner_type === 'dynamic' ) {

			if ( $bg_mode === 'multi' ) {
				// Text is fixed and lives in _uhaifa_dynamic_static_text, not
				// per-item — and only the FIRST background image is mandatory,
				// the rest are optional extra rotation frames.
				$has_valid_item = ( $static_text['title'] ?? '' ) !== '';
				$has_background = ! empty( $items[0]['image_mobile'] ?? null );
			} elseif ( $bg_mode === 'shared' ) {
				$has_valid_item = false;
				foreach ( $items as $item ) {
					if ( $item['title'] !== '' ) {
						$has_valid_item = true;
						break;
					}
				}
				$has_background = ! empty( $shared_bg['image_mobile'] );
			} else {
				// per_item: at least one item has a title, and at least one
				// item supplies its own background.
				$has_valid_item = false;
				foreach ( $items as $item ) {
					if ( $item['title'] !== '' ) {
						$has_valid_item = true;
						break;
					}
				}
				$has_background = false;
				foreach ( $items as $item ) {
					if ( ! empty( $item['image_mobile'] ) ) { $has_background = true; break; }
				}
			}

			if ( ! $has_valid_item || ! $has_background ) {
				$errors[] = 'missing_images';
			}
		} else {
			if ( empty( $slides ) ) {
				$errors[] = 'missing_images';
			}
		}

		if ( $is_evergreen ) {
			// Rule 2 (evergreen variant): no date required at all — but only
			// ONE evergreen fallback may exist site-wide, or there'd be no
			// way to pick between two equally-permanent campaigns.
			$conflict_id = $this->find_evergreen_conflict( $post_id );
			if ( $conflict_id ) {
				$errors[] = 'evergreen_conflict:' . $conflict_id;
			}
		} elseif ( ! $date_start ) {
			// Rule 2: a start date is mandatory. get_active_local_response() /
			// handle_active() only ever surface campaigns whose
			// _uhaifa_date_start is set (and past), so a published campaign
			// with no start date is invisible everywhere — silently, with
			// nothing in wp-admin flagging it. Treat that the same as any
			// other incomplete campaign.
			$errors[] = 'missing_start_date';
		} else {
			// Rule 3: date conflict — only one live campaign allowed at a time
			// per scope (see find_date_conflict()'s own docblock).
			$conflict_id = $this->find_date_conflict( $post_id, $date_start, $date_end );
			if ( $conflict_id ) {
				$errors[] = 'conflict:' . $conflict_id;
			}
		}

		if ( ! empty( $errors ) ) {
			set_transient( 'uhaifa_banner_errors_' . $post_id, $errors, 60 );
			$data['post_status'] = 'draft';
		}

		return $data;
	}

	/**
	 * Two campaigns only actually compete for the same widget slot — and so
	 * only actually need to be blocked from overlapping — if they'd both be
	 * eligible for the SAME target: either they're both untargeted (the
	 * general/fallback pool), or they share at least one category/tag. A
	 * "Law"-tagged campaign and a "Medicine"-tagged campaign can run at the
	 * same time; two "Law"-tagged campaigns, or two untargeted ones, can't.
	 */
	private function find_date_conflict( $exclude_id, $new_start, $new_end ) {
		$new_terms = array_merge(
			$this->get_submitted_term_ids( 'category' ),
			$this->get_submitted_term_ids( 'post_tag' )
		);

		$banners = get_posts( [
			'post_type'      => 'uhaifa_banner',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'exclude'        => $exclude_id ? [ $exclude_id ] : [],
		] );

		$new_start_ts = strtotime( $new_start );
		$new_end_ts   = $new_end ? strtotime( $new_end ) : PHP_INT_MAX;

		foreach ( $banners as $banner ) {
			$b_start = get_post_meta( $banner->ID, '_uhaifa_date_start', true );
			$b_end   = get_post_meta( $banner->ID, '_uhaifa_date_end',   true );
			if ( ! $b_start ) continue;

			$b_start_ts = strtotime( $b_start );
			$b_end_ts   = $b_end ? strtotime( $b_end ) : PHP_INT_MAX;

			if ( $new_start_ts > $b_end_ts || $b_start_ts > $new_end_ts ) continue; // dates don't even overlap

			$b_terms = wp_get_post_terms( $banner->ID, [ 'category', 'post_tag' ], [ 'fields' => 'ids' ] );
			$b_terms = is_wp_error( $b_terms ) ? [] : $b_terms;

			$both_untargeted = empty( $new_terms ) && empty( $b_terms );
			$shares_a_term   = ! empty( array_intersect( $new_terms, $b_terms ) );

			if ( $both_untargeted || $shares_a_term ) {
				return $banner->ID;
			}
		}
		return null;
	}

	/**
	 * Reads the category/tag IDs about to be saved for THIS submission,
	 * straight from $_POST rather than post meta — find_date_conflict() runs
	 * inside wp_insert_post_data, which fires BEFORE WordPress actually
	 * persists the post or its terms, so get_post_meta()/wp_get_post_terms()
	 * on $post_id would still return the OLD (pre-edit) values here.
	 *
	 * Categories are submitted as real term_ids (post_category[]) even for
	 * a brand-new category, since Elementor/Gutenberg's "+ Add New Category"
	 * creates the term via AJAX immediately, before the main form submits.
	 * Tags are submitted as a plain comma-separated string of NAMES
	 * (tax_input[post_tag]) — a brand-new tag name isn't a real term yet at
	 * this point (wp_set_post_terms() creates it later, on actual save), so
	 * an unresolvable name is simply skipped: a tag that doesn't exist yet
	 * can't already conflict with anything.
	 */
	private function get_submitted_term_ids( $taxonomy ) {
		if ( $taxonomy === 'category' ) {
			return array_map( 'absint', (array) ( $_POST['post_category'] ?? [] ) );
		}

		$raw = (string) ( $_POST['tax_input']['post_tag'] ?? '' );
		$ids = [];
		foreach ( array_filter( array_map( 'trim', explode( ',', $raw ) ) ) as $name ) {
			$term = get_term_by( 'name', $name, 'post_tag' );
			if ( $term && ! is_wp_error( $term ) ) $ids[] = $term->term_id;
		}
		return $ids;
	}

	/** Only one evergreen (dateless) fallback campaign may be published at a time. */
	private function find_evergreen_conflict( $exclude_id ) {
		$banners = get_posts( [
			'post_type'      => 'uhaifa_banner',
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'exclude'        => $exclude_id ? [ $exclude_id ] : [],
			'meta_query'     => [
				[ 'key' => '_uhaifa_evergreen', 'value' => '1' ],
			],
		] );
		return $banners ? $banners[0]->ID : null;
	}

	public function show_admin_errors() {
		$screen = get_current_screen();
		if ( ! $screen || $screen->post_type !== 'uhaifa_banner' ) return;

		$post_id = absint( $_GET['post'] ?? 0 );
		if ( ! $post_id ) return;

		$errors = get_transient( 'uhaifa_banner_errors_' . $post_id );
		if ( ! $errors ) return;
		delete_transient( 'uhaifa_banner_errors_' . $post_id );

		foreach ( $errors as $error ) {
			if ( $error === 'missing_images' ) {
				echo '<div class="notice notice-error"><p>'
				. '<strong>ניהול קמפיינים:</strong> '
				. 'יש להשלים לפחות פריט תוכן אחד לפני פרסום — בבאנר מבוסס תמונות: תמונה למחשב, תמונה לנייד וטקסט חלופי. בבאנר דינמי: רקע (תמונה לנייד לפחות) וכותרת. הקמפיין נשמר כטיוטה.'
				. '</p></div>';
			} elseif ( $error === 'missing_start_date' ) {
				echo '<div class="notice notice-error"><p>'
				. '<strong>ניהול קמפיינים:</strong> '
				. 'יש להגדיר תאריך ושעת התחלה לפני פרסום — ללא תאריך התחלה הקמפיין לא יוצג, גם אם הוא "מפורסם". הקמפיין נשמר כטיוטה.'
				. '</p></div>';
			} elseif ( strpos( $error, 'conflict:' ) === 0 ) {
				$conflict_id = intval( substr( $error, 9 ) );
				$edit_url    = get_edit_post_link( $conflict_id );
				$title       = get_the_title( $conflict_id ) ?: 'קמפיין #' . $conflict_id;
				echo '<div class="notice notice-error"><p>'
				. '<strong>ניהול קמפיינים:</strong> '
				. 'קיים קמפיין פעיל עם תאריכים חופפים: '
				. '<a href="' . esc_url( $edit_url ) . '"><strong>' . esc_html( $title ) . '</strong></a>. '
				. 'רק קמפיין אחד יכול להיות פעיל בו-זמנית — יש לסיים את הקמפיין הקיים לפני פרסום חדש. הקמפיין נשמר כטיוטה.'
				. '</p></div>';
			} elseif ( strpos( $error, 'evergreen_conflict:' ) === 0 ) {
				$conflict_id = intval( substr( $error, 19 ) );
				$edit_url    = get_edit_post_link( $conflict_id );
				$title       = get_the_title( $conflict_id ) ?: 'קמפיין #' . $conflict_id;
				echo '<div class="notice notice-error"><p>'
				. '<strong>ניהול קמפיינים:</strong> '
				. 'כבר קיים קמפיין ברירת מחדל אחר: '
				. '<a href="' . esc_url( $edit_url ) . '"><strong>' . esc_html( $title ) . '</strong></a>. '
				. 'ניתן להגדיר קמפיין ברירת מחדל אחד בלבד — יש לבטל את הסימון בקמפיין הקיים לפני פרסום חדש. הקמפיין נשמר כטיוטה.'
				. '</p></div>';
			}
		}
	}

	// ─── Meta Box ─────────────────────────────────────────────────────────────

	public function add_meta_boxes() {
		add_meta_box(
			'uhaifa_banner_details',
			'הגדרות קמפיין',
			[ $this, 'render_meta_box' ],
			'uhaifa_banner',
			'normal',
			'high'
		);
	}

	public function render_meta_box( $post ) {
		wp_nonce_field( 'uhaifa_banner_save', 'uhaifa_banner_nonce' );

		$banner_type  = get_post_meta( $post->ID, '_uhaifa_banner_type', true ) ?: 'image';

		// Image-type data
		$slides       = get_post_meta( $post->ID, '_uhaifa_slides', true );
		$slides       = is_array( $slides ) && ! empty( $slides ) ? $slides : [ $this->empty_slide() ];

		// Dynamic-type data
		$bg_mode      = get_post_meta( $post->ID, '_uhaifa_dynamic_bg_mode', true ) ?: 'shared';
		$shared_bg    = get_post_meta( $post->ID, '_uhaifa_dynamic_shared_bg', true );
		$shared_bg    = is_array( $shared_bg ) ? $shared_bg : [];
		$dyn_items    = get_post_meta( $post->ID, '_uhaifa_dynamic_items', true );
		$dyn_items    = is_array( $dyn_items ) && ! empty( $dyn_items ) ? $dyn_items : [ $this->empty_dynamic_item() ];
		$static_text  = get_post_meta( $post->ID, '_uhaifa_dynamic_static_text', true );
		$static_text  = is_array( $static_text ) ? $static_text : $this->empty_static_text();

		$link_url     = get_post_meta( $post->ID, '_uhaifa_link_url',       true );
		$link_target  = get_post_meta( $post->ID, '_uhaifa_link_target',    true ) ?: '_blank';
		$date_start   = get_post_meta( $post->ID, '_uhaifa_date_start',     true );
		$date_end     = get_post_meta( $post->ID, '_uhaifa_date_end',       true );
		$is_evergreen = (bool) get_post_meta( $post->ID, '_uhaifa_evergreen', true );
		?>
		<div class="uhaifa-meta-box">

			<?php /* ══════════ SECTIONS: General settings + (hub-only) Target sites ══════════ */ ?>
			<div class="uhaifa-settings-row">

				<div class="uhaifa-settings-section">
					<h3 class="uhaifa-settings-section-title">הגדרות כלליות</h3>

					<div class="uhaifa-field" style="margin-bottom:16px;">
						<label>סוג באנר</label>
						<div class="uhaifa-radio-group">
							<label>
								<input type="radio" name="uhaifa_banner_type" value="image"
								       <?php checked( $banner_type, 'image' ); ?> id="uhaifa-type-image">
								מבוסס תמונות (סבב שקופיות)
							</label>
							<label>
								<input type="radio" name="uhaifa_banner_type" value="dynamic"
								       <?php checked( $banner_type, 'dynamic' ); ?> id="uhaifa-type-dynamic">
								דינמי (רקע וידאו/תמונה + טקסט חי)
							</label>
						</div>
					</div>

					<div class="uhaifa-field" style="margin-bottom:16px;">
						<label for="uhaifa_duration_override">
							משך הצגת כל פריט (מילישניות)
							<span class="uhaifa-field-note">ריק = <?php echo esc_html( get_option( 'uhaifa_banners_slide_duration', 5000 ) ); ?> (הגדרה כללית)</span>
						</label>
						<input type="number"
						       name="uhaifa_duration_override"
						       id="uhaifa_duration_override"
						       min="1000"
						       step="500"
						       value="<?php echo esc_attr( get_post_meta( $post->ID, '_uhaifa_duration_override', true ) ); ?>"
						       placeholder="<?php echo esc_attr( get_option( 'uhaifa_banners_slide_duration', 5000 ) ); ?>">
					</div>

					<div class="uhaifa-field" style="margin-bottom:16px;">
						<label>
							<input type="checkbox" name="uhaifa_evergreen" value="1" id="uhaifa-evergreen-checkbox" <?php checked( $is_evergreen ); ?>>
							קמפיין ברירת מחדל (Fallback) — ללא הגבלת תאריכים
						</label>
						<span class="uhaifa-field-note">יוצג בכל אתר הפקולטה רק כאשר אין שום קמפיין פעיל אחר (לא כללי ולא מתויג). ניתן להגדיר קמפיין ברירת מחדל אחד בלבד.</span>
					</div>

					<div class="uhaifa-dates-row" id="uhaifa-dates-row" style="<?php echo $is_evergreen ? 'display:none' : ''; ?>">
						<div class="uhaifa-field">
							<label for="uhaifa_date_start">תאריך ושעת התחלה</label>
							<input type="datetime-local"
							       name="uhaifa_date_start"
							       id="uhaifa_date_start"
							       value="<?php echo esc_attr( $date_start ); ?>">
						</div>
						<div class="uhaifa-field">
							<label for="uhaifa_date_end">
								תאריך ושעת סיום
							</label>
							<input type="datetime-local"
							       name="uhaifa_date_end"
							       id="uhaifa_date_end"
							       value="<?php echo esc_attr( $date_end ); ?>">
						</div>
					</div>
				</div>

				<?php echo $this->render_target_section( $post ); // '' unless overridden (hub only) ?>

			</div>

			<?php /* ══════════ IMAGE TYPE SECTION ══════════ */ ?>
			<div id="uhaifa-section-image" class="uhaifa-type-section"
			     style="<?php echo $banner_type === 'image' ? '' : 'display:none'; ?>">

				<?php /* ── Slides repeater ── */ ?>
				<div class="uhaifa-field">
					<label>
						שקופיות (סבב עם fade)
						<span class="uhaifa-field-note">גרור/סדר עם החצים. לכל שקופית תמונה למחשב + תמונה לנייד + טקסט חלופי חובה. קישור לשקופית הוא אופציונלי — אם ריק, ייעשה שימוש בקישור הכללי של הקמפיין (למטה).</span>
					</label>
					<div id="uhaifa-slides-repeater" class="uhaifa-slides-repeater">
						<?php foreach ( $slides as $i => $slide ) : ?>
							<?php echo $this->render_slide_row( $i, $slide ); ?>
						<?php endforeach; ?>
					</div>
					<button type="button" class="button button-secondary" id="uhaifa-add-slide">+ הוסף שקופית</button>
				</div>

				<script type="text/template" id="uhaifa-slide-row-template">
					<?php echo $this->render_slide_row( '__INDEX__', $this->empty_slide() ); ?>
				</script>

				<?php /* ── Campaign-level link row (fallback for slides without their own link) ── */ ?>
				<div class="uhaifa-field-row">
					<div class="uhaifa-field">
						<label for="uhaifa_link_url">
							קישור כללי לקמפיין
							<span class="uhaifa-field-note">(ברירת מחדל לשקופיות ללא קישור משלהן)</span>
						</label>
						<input type="url"
						       name="uhaifa_link_url"
						       id="uhaifa_link_url"
						       class="large-text"
						       value="<?php echo esc_url( $link_url ); ?>"
						       placeholder="https://">
					</div>
					<div class="uhaifa-field uhaifa-field--small">
						<label for="uhaifa_link_target">פתח ב</label>
						<select name="uhaifa_link_target" id="uhaifa_link_target">
							<option value="_blank" <?php selected( $link_target, '_blank' ); ?>>לשונית חדשה</option>
							<option value="_self"  <?php selected( $link_target, '_self'  ); ?>>אותה לשונית</option>
						</select>
					</div>
				</div>
			</div>

			<?php /* ══════════ DYNAMIC TYPE SECTION ══════════ */ ?>
			<div id="uhaifa-section-dynamic" class="uhaifa-type-section"
			     style="<?php echo $banner_type === 'dynamic' ? '' : 'display:none'; ?>">

				<?php /* ── Background mode ── */ ?>
				<div class="uhaifa-field">
					<label>רקע</label>
					<div class="uhaifa-radio-group">
						<label>
							<input type="radio" name="uhaifa_dynamic_bg_mode" value="shared"
							       <?php checked( $bg_mode, 'shared' ); ?> id="uhaifa-bgmode-shared">
							רקע אחד קבוע לכל הקמפיין — רק הטקסט מתחלף
						</label>
												<label>
							<input type="radio" name="uhaifa_dynamic_bg_mode" value="per_item"
							       <?php checked( $bg_mode, 'per_item' ); ?> id="uhaifa-bgmode-per-item">
							רקע נפרד לכל פריט בסבב
						</label>
						<label>
							<input type="radio" name="uhaifa_dynamic_bg_mode" value="multi"
							       <?php checked( $bg_mode, 'multi' ); ?> id="uhaifa-bgmode-multi">
							מספר תמונות רקע מתחלפות — טקסט קבוע אחד
						</label>
					</div>
				</div>

				<?php /* ── Shared background — only relevant when bg_mode = shared ── */ ?>
				<div id="uhaifa-shared-bg-fields" class="uhaifa-field"
				     style="<?php echo $bg_mode === 'shared' ? '' : 'display:none'; ?>">
					<label>רקע משותף</label>
					<?php echo $this->render_bg_fields( 'uhaifa_dynamic_shared_bg', $shared_bg ); ?>
				</div>

				<?php /* ── Static text — only relevant when bg_mode = multi ── */ ?>
				<div id="uhaifa-static-text-fields" class="uhaifa-field"
				     style="<?php echo $bg_mode === 'multi' ? '' : 'display:none'; ?>">
					<label>טקסט קבוע</label>
					<?php echo $this->render_static_text_fields( $static_text ); ?>
				</div>

				<?php /* ── Text items repeater — background fields shown only in per_item/multi mode, text fields hidden in multi mode ── */ ?>
				<div class="uhaifa-field">
					<label>
						פריטים (סבב)
						<span class="uhaifa-field-note">כותרת חובה בכל פריט (למעט מצב "מספר תמונות רקע" — שם רק תמונת רקע לנייד בתמונה הראשונה חובה). במצב "רקע נפרד" יש להוסיף גם רקע לכל פריט.</span>
					</label>
					<div id="uhaifa-dynamic-items-repeater" class="uhaifa-slides-repeater" data-bg-mode="<?php echo esc_attr( $bg_mode ); ?>">
						<?php foreach ( $dyn_items as $i => $item ) : ?>
							<?php echo $this->render_dynamic_item_row( $i, $item, $bg_mode ); ?>
						<?php endforeach; ?>
					</div>
					<button type="button" class="button button-secondary" id="uhaifa-add-dynamic-item">+ הוסף פריט</button>
				</div>

				<script type="text/template" id="uhaifa-dynamic-item-template-shared">
					<?php echo $this->render_dynamic_item_row( '__INDEX__', $this->empty_dynamic_item(), 'shared' ); ?>
				</script>
				<script type="text/template" id="uhaifa-dynamic-item-template-per_item">
					<?php echo $this->render_dynamic_item_row( '__INDEX__', $this->empty_dynamic_item(), 'per_item' ); ?>
				</script>
				<script type="text/template" id="uhaifa-dynamic-item-template-multi">
					<?php echo $this->render_dynamic_item_row( '__INDEX__', $this->empty_dynamic_item(), 'multi' ); ?>
				</script>
			</div>

		</div>
		<?php
	}

	private function empty_slide() {
		return [ 'desktop' => 0, 'mobile' => 0, 'alt' => '', 'link_url' => '', 'link_target' => '_blank' ];
	}

	private function empty_dynamic_item() {
		return [
			'image_desktop' => 0, 'image_mobile' => 0, 'youtube_url' => '',
			'title' => '', 'text' => '', 'button_text' => '', 'button_url' => '', 'button_target' => '_blank',
		];
	}

	private function empty_static_text() {
		return [ 'title' => '', 'text' => '', 'button_text' => '', 'button_url' => '', 'button_target' => '_blank' ];
	}

	/**
	 * Renders the desktop image / mobile image / YouTube URL trio used both
	 * for the shared dynamic background and for each per-item background.
	 * $name_prefix is the bracket-notation field name prefix, e.g.
	 * 'uhaifa_dynamic_shared_bg' or 'uhaifa_dynamic_items[3]'.
	 */
	private function render_bg_fields( $name_prefix, $bg, $show_youtube = true ) {
		$desktop_id = absint( $bg['image_desktop'] ?? 0 );
		$mobile_id  = absint( $bg['image_mobile']  ?? 0 );
		$youtube    = $bg['youtube_url'] ?? '';

		$desktop_url = $desktop_id ? wp_get_attachment_image_url( $desktop_id, 'medium' ) : '';
		$mobile_url  = $mobile_id  ? wp_get_attachment_image_url( $mobile_id,  'medium' ) : '';

		ob_start();
		?>
		<div class="uhaifa-slide-row-images">
			<?php foreach ( [ 'image_desktop' => [ $desktop_id, $desktop_url, 'תמונת רקע למחשב (גם כגיבוי לוידאו)' ],
			                  'image_mobile'  => [ $mobile_id,  $mobile_url,  'תמונת רקע לנייד' ] ]
			         as $key => [ $att_id, $att_url, $label ] ) : ?>
			<div class="uhaifa-field">
				<label>
					<?php echo esc_html( $label ); ?>
					<?php if ( $key === 'image_mobile' ) : ?><span class="uhaifa-required" title="שדה חובה">*</span><?php endif; ?>
				</label>
				<div class="uhaifa-image-picker<?php echo $att_id ? ' has-image' : ''; ?>" data-field="<?php echo esc_attr( $key ); ?>">
					<?php if ( $att_url ) : ?>
						<img src="<?php echo esc_url( $att_url ); ?>" class="uhaifa-preview-img">
					<?php else : ?>
						<div class="uhaifa-image-placeholder">לא נבחרה תמונה</div>
					<?php endif; ?>
					<input type="hidden"
					       class="uhaifa-slide-image-input"
					       name="<?php echo esc_attr( $name_prefix ); ?>[<?php echo esc_attr( $key ); ?>]"
					       value="<?php echo esc_attr( $att_id ); ?>">
					<div class="uhaifa-picker-actions">
						<button type="button" class="button uhaifa-pick-image" data-preview="<?php echo esc_attr( $key ); ?>">
							בחר תמונה
						</button>
						<button type="button" class="button uhaifa-replace-image" data-preview="<?php echo esc_attr( $key ); ?>">
							החלף תמונה
						</button>
						<button type="button" class="button uhaifa-remove-image" data-preview="<?php echo esc_attr( $key ); ?>">
							הסר תמונה
						</button>
					</div>
					<p class="uhaifa-image-size-warning" style="display:none"></p>
				</div>
			</div>
			<?php endforeach; ?>
		</div>
		<?php if ( $show_youtube ) : ?>
		<div class="uhaifa-field">
			<label>קישור YouTube לוידאו רקע (אופציונלי, למחשב בלבד — בנייד תמיד מוצגת התמונה)</label>
			<input type="url"
			       class="large-text"
			       name="<?php echo esc_attr( $name_prefix ); ?>[youtube_url]"
			       value="<?php echo esc_url( $youtube ); ?>"
			       placeholder="https://www.youtube.com/watch?v=...">
		</div>
		<?php endif; ?>
		<?php
		return ob_get_clean();
	}

	/**
	 * Renders one row of the dynamic-items repeater: always the text/button
	 * fields, plus a per-item background block that's only shown (via inline
	 * style, kept in the DOM either way) when $bg_mode is 'per_item'.
	 */
	private function render_dynamic_item_row( $index, $item, $bg_mode ) {
		$title         = $item['title']         ?? '';
		$text          = $item['text']          ?? '';
		$button_text   = $item['button_text']   ?? '';
		$button_url    = $item['button_url']    ?? '';
		$button_target = $item['button_target'] ?? '_blank';

		$name_prefix = 'uhaifa_dynamic_items[' . $index . ']';
		$show_bg     = in_array( $bg_mode, [ 'per_item', 'multi' ], true );
		$show_text   = $bg_mode !== 'multi';

		ob_start();
		?>
		<div class="uhaifa-slide-row" data-index="<?php echo esc_attr( $index ); ?>">
			<div class="uhaifa-slide-row-handle">⠿</div>

			<div class="uhaifa-dynamic-item-bg" style="<?php echo $show_bg ? '' : 'display:none'; ?>">
				<?php echo $this->render_bg_fields( $name_prefix, $item, $bg_mode === 'per_item' ); ?>
			</div>

			<div class="uhaifa-dynamic-item-text" style="<?php echo $show_text ? '' : 'display:none'; ?>">

			<div class="uhaifa-field">
				<label>כותרת <span class="uhaifa-required" title="שדה חובה">*</span></label>
				<input type="text"
				       class="large-text uhaifa-dynamic-title-input"
				       name="<?php echo esc_attr( $name_prefix ); ?>[title]"
				       value="<?php echo esc_attr( $title ); ?>">
			</div>

			<div class="uhaifa-field">
				<label>טקסט</label>
				<textarea class="large-text" rows="2"
				          name="<?php echo esc_attr( $name_prefix ); ?>[text]"><?php echo esc_textarea( $text ); ?></textarea>
			</div>

			<div class="uhaifa-slide-row-link">
				<div class="uhaifa-field uhaifa-field--small">
					<label>טקסט כפתור</label>
					<input type="text"
					       name="<?php echo esc_attr( $name_prefix ); ?>[button_text]"
					       value="<?php echo esc_attr( $button_text ); ?>"
					       placeholder="קרא עוד">
				</div>
				<div class="uhaifa-field">
					<label>קישור כפתור <span class="uhaifa-field-note">(אופציונלי — ריק = ללא כפתור)</span></label>
					<input type="url"
					       class="large-text uhaifa-dynamic-buttonurl-input"
					       name="<?php echo esc_attr( $name_prefix ); ?>[button_url]"
					       value="<?php echo esc_url( $button_url ); ?>"
					       placeholder="https://">
				</div>
				<div class="uhaifa-field uhaifa-field--small">
					<label>פתח ב</label>
					<select name="<?php echo esc_attr( $name_prefix ); ?>[button_target]">
						<option value="_blank" <?php selected( $button_target, '_blank' ); ?>>לשונית חדשה</option>
						<option value="_self"  <?php selected( $button_target, '_self'  ); ?>>אותה לשונית</option>
					</select>
				</div>
			</div>

			</div>

			<div class="uhaifa-slide-row-actions">
				<button type="button" class="button uhaifa-slide-move-up" title="הזז למעלה">↑</button>
				<button type="button" class="button uhaifa-slide-move-down" title="הזז למטה">↓</button>
				<button type="button" class="button uhaifa-slide-remove" title="הסר פריט">✕ הסר פריט</button>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Renders the single, non-repeating title/text/button block used by
	 * bg_mode = 'multi' — one fixed text overlay shown the whole time while
	 * the background images rotate underneath it.
	 */
	private function render_static_text_fields( $static_text ) {
		$title         = $static_text['title']         ?? '';
		$text          = $static_text['text']          ?? '';
		$button_text   = $static_text['button_text']   ?? '';
		$button_url    = $static_text['button_url']    ?? '';
		$button_target = $static_text['button_target'] ?? '_blank';

		ob_start();
		?>
		<div class="uhaifa-field">
			<label>כותרת <span class="uhaifa-required" title="שדה חובה">*</span></label>
			<input type="text"
			       class="large-text uhaifa-static-text-title-input"
			       name="uhaifa_dynamic_static_text[title]"
			       value="<?php echo esc_attr( $title ); ?>">
		</div>

		<div class="uhaifa-field">
			<label>טקסט</label>
			<textarea class="large-text" rows="2"
			          name="uhaifa_dynamic_static_text[text]"><?php echo esc_textarea( $text ); ?></textarea>
		</div>

		<div class="uhaifa-slide-row-link">
			<div class="uhaifa-field uhaifa-field--small">
				<label>טקסט כפתור</label>
				<input type="text"
				       name="uhaifa_dynamic_static_text[button_text]"
				       value="<?php echo esc_attr( $button_text ); ?>"
				       placeholder="קרא עוד">
			</div>
			<div class="uhaifa-field">
				<label>קישור כפתור <span class="uhaifa-field-note">(אופציונלי — ריק = ללא כפתור, זהה לכל הבאנר)</span></label>
				<input type="url"
				       class="large-text uhaifa-static-text-buttonurl-input"
				       name="uhaifa_dynamic_static_text[button_url]"
				       value="<?php echo esc_url( $button_url ); ?>"
				       placeholder="https://">
			</div>
			<div class="uhaifa-field uhaifa-field--small">
				<label>פתח ב</label>
				<select name="uhaifa_dynamic_static_text[button_target]">
					<option value="_blank" <?php selected( $button_target, '_blank' ); ?>>לשונית חדשה</option>
					<option value="_self"  <?php selected( $button_target, '_self'  ); ?>>אותה לשונית</option>
				</select>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Renders a single slide repeater row. $index may be an int (real row)
	 * or the literal string '__INDEX__' (JS template row, replaced client-side).
	 */
	private function render_slide_row( $index, $slide ) {
		$desktop_id  = absint( $slide['desktop'] ?? 0 );
		$mobile_id   = absint( $slide['mobile']  ?? 0 );
		$alt         = $slide['alt']         ?? '';
		$link_url    = $slide['link_url']    ?? '';
		$link_target = $slide['link_target'] ?? '_blank';

		$desktop_url = $desktop_id ? wp_get_attachment_image_url( $desktop_id, 'medium' ) : '';
		$mobile_url  = $mobile_id  ? wp_get_attachment_image_url( $mobile_id,  'medium' ) : '';

		ob_start();
		?>
		<div class="uhaifa-slide-row" data-index="<?php echo esc_attr( $index ); ?>">
			<div class="uhaifa-slide-row-handle">⠿</div>

			<div class="uhaifa-slide-row-images">
				<?php foreach ( [ 'desktop' => [ $desktop_id, $desktop_url, 'תמונה למחשב' ],
				                  'mobile'  => [ $mobile_id,  $mobile_url,  'תמונה לנייד' ] ]
				         as $key => [ $att_id, $att_url, $label ] ) : ?>
				<div class="uhaifa-field">
					<label>
						<?php echo esc_html( $label ); ?>
						<span class="uhaifa-required" title="שדה חובה">*</span>
					</label>
					<div class="uhaifa-image-picker<?php echo $att_id ? ' has-image' : ''; ?>" data-field="<?php echo esc_attr( $key ); ?>">
						<?php if ( $att_url ) : ?>
							<img src="<?php echo esc_url( $att_url ); ?>" class="uhaifa-preview-img">
						<?php else : ?>
							<div class="uhaifa-image-placeholder">לא נבחרה תמונה</div>
						<?php endif; ?>
						<input type="hidden"
						       class="uhaifa-slide-image-input"
						       name="uhaifa_slides[<?php echo esc_attr( $index ); ?>][<?php echo esc_attr( $key ); ?>]"
						       value="<?php echo esc_attr( $att_id ); ?>">
						<div class="uhaifa-picker-actions">
							<button type="button" class="button uhaifa-pick-image" data-preview="<?php echo esc_attr( $key ); ?>">
								בחר תמונה
							</button>
							<button type="button" class="button uhaifa-replace-image" data-preview="<?php echo esc_attr( $key ); ?>">
								החלף תמונה
							</button>
							<button type="button" class="button uhaifa-remove-image" data-preview="<?php echo esc_attr( $key ); ?>">
								הסר תמונה
							</button>
						</div>
						<p class="uhaifa-image-size-warning" style="display:none"></p>
					</div>
				</div>
				<?php endforeach; ?>
			</div>

			<div class="uhaifa-field">
				<label>
					טקסט חלופי (alt) לתמונה
					<span class="uhaifa-required" title="שדה חובה">*</span>
				</label>
				<input type="text"
			       class="large-text uhaifa-slide-alt-input"
			       name="uhaifa_slides[<?php echo esc_attr( $index ); ?>][alt]"
			       value="<?php echo esc_attr( $alt ); ?>"
			       placeholder="תיאור קצר של התמונה, לנגישות">
			</div>

			<div class="uhaifa-slide-row-link">
				<div class="uhaifa-field">
					<label>קישור לשקופית זו (אופציונלי)</label>
					<input type="url"
					       class="large-text"
					       name="uhaifa_slides[<?php echo esc_attr( $index ); ?>][link_url]"
					       value="<?php echo esc_url( $link_url ); ?>"
					       placeholder="ריק = שימוש בקישור הכללי">
				</div>
				<div class="uhaifa-field uhaifa-field--small">
					<label>פתח ב</label>
					<select name="uhaifa_slides[<?php echo esc_attr( $index ); ?>][link_target]">
						<option value="_blank" <?php selected( $link_target, '_blank' ); ?>>לשונית חדשה</option>
						<option value="_self"  <?php selected( $link_target, '_self'  ); ?>>אותה לשונית</option>
					</select>
				</div>
			</div>

			<div class="uhaifa-slide-row-actions">
				<button type="button" class="button uhaifa-slide-move-up" title="הזז למעלה">↑</button>
				<button type="button" class="button uhaifa-slide-move-down" title="הזז למטה">↓</button>
				<button type="button" class="button uhaifa-slide-remove" title="הסר שקופית">✕ הסר שקופית</button>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	// ─── Save Meta ────────────────────────────────────────────────────────────

	public function save_meta( $post_id ) {
		if ( ! isset( $_POST['uhaifa_banner_nonce'] ) ) return;
		if ( ! wp_verify_nonce( $_POST['uhaifa_banner_nonce'], 'uhaifa_banner_save' ) ) return;
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
		if ( ! current_user_can( 'edit_post', $post_id ) ) return;

		// Banner type
		$banner_type = sanitize_key( $_POST['uhaifa_banner_type'] ?? 'image' );
		if ( ! in_array( $banner_type, [ 'image', 'dynamic' ], true ) ) $banner_type = 'image';
		update_post_meta( $post_id, '_uhaifa_banner_type', $banner_type );

		// Image-type data — always saved regardless of the currently active
		// type, so toggling between image/dynamic never discards content.
		update_post_meta( $post_id, '_uhaifa_slides', $this->sanitize_slides_from_post() );

		// Dynamic-type data — same reasoning, always saved.
		$bg_mode = sanitize_key( $_POST['uhaifa_dynamic_bg_mode'] ?? 'shared' );
		if ( ! in_array( $bg_mode, [ 'shared', 'per_item', 'multi' ], true ) ) $bg_mode = 'shared';
		update_post_meta( $post_id, '_uhaifa_dynamic_bg_mode', $bg_mode );
		update_post_meta( $post_id, '_uhaifa_dynamic_shared_bg', $this->sanitize_dynamic_bg_from_post_array( $_POST['uhaifa_dynamic_shared_bg'] ?? [] ) );
		update_post_meta( $post_id, '_uhaifa_dynamic_items', $this->sanitize_dynamic_items_from_post() );
		update_post_meta( $post_id, '_uhaifa_dynamic_static_text', $this->sanitize_static_text_from_post( $_POST['uhaifa_dynamic_static_text'] ?? [] ) );

		// Campaign-level scalar fields
		$scalar_fields = [
			'_uhaifa_link_url'      => [ 'post' => 'uhaifa_link_url',      'san' => 'esc_url_raw' ],
			'_uhaifa_link_target'   => [ 'post' => 'uhaifa_link_target',   'san' => 'sanitize_key' ],
			'_uhaifa_date_start'    => [ 'post' => 'uhaifa_date_start',    'san' => 'sanitize_text_field' ],
			'_uhaifa_date_end'      => [ 'post' => 'uhaifa_date_end',      'san' => 'sanitize_text_field' ],
		];

		// Per-campaign rotation duration override — empty means "use the
		// global default", so we store it as an empty string rather than
		// forcing a numeric fallback here; response-building does the fallback.
		$duration_override = sanitize_text_field( $_POST['uhaifa_duration_override'] ?? '' );
		update_post_meta( $post_id, '_uhaifa_duration_override', $duration_override === '' ? '' : max( 1000, absint( $duration_override ) ) );

		// Explicit set/clear rather than the generic scalar-fields loop below
		// — an UNCHECKED checkbox is simply absent from $_POST, so a loop
		// that only writes when the key is present would never be able to
		// turn this back off once it had been turned on.
		update_post_meta( $post_id, '_uhaifa_evergreen', ! empty( $_POST['uhaifa_evergreen'] ) ? '1' : '' );

		foreach ( $scalar_fields as $meta_key => $opts ) {
			if ( isset( $_POST[ $opts['post'] ] ) ) {
				update_post_meta( $post_id, $meta_key, call_user_func( $opts['san'], $_POST[ $opts['post'] ] ) );
			}
		}

		// Hub-only targeting fields (this_site/all/specific) — no-op here.
		$this->save_target_meta( $post_id );

		// Hub-only cache invalidation — no-op here.
		$this->after_save_meta( $post_id );
	}

	/**
	 * Reads $_POST['uhaifa_slides'], sanitizes, and drops incomplete rows
	 * (rows missing either image). Returns a clean, re-indexed array.
	 */
	private function sanitize_slides_from_post() {
		$raw = $_POST['uhaifa_slides'] ?? [];
		if ( ! is_array( $raw ) ) return [];

		$clean = [];
		foreach ( $raw as $row ) {
			$desktop = absint( $row['desktop'] ?? 0 );
			$mobile  = absint( $row['mobile']  ?? 0 );

			// Skip fully-empty rows (e.g. an added-then-untouched row)
			if ( ! $desktop && ! $mobile ) continue;

			// A row missing either image, or missing alt text, is incomplete —
			// skip it. Alt text is mandatory, same tier as the images.
			$alt = sanitize_text_field( $row['alt'] ?? '' );
			if ( ! $desktop || ! $mobile || $alt === '' ) continue;

			$clean[] = [
				'desktop'     => $desktop,
				'mobile'      => $mobile,
				'alt'         => $alt,
				'link_url'    => esc_url_raw( $row['link_url'] ?? '' ),
				'link_target' => sanitize_key( $row['link_target'] ?? '_blank' ) ?: '_blank',
			];
		}

		return $clean;
	}

	/**
	 * Sanitizes one background block (desktop image / mobile image / YouTube
	 * URL). Used for both the shared background and each per-item background.
	 * Stores the raw YouTube URL as typed — ID extraction happens only at
	 * response-build time in build_dynamic_response(), so the admin field
	 * always redisplays exactly what the editor entered.
	 */
	protected function sanitize_dynamic_bg_from_post_array( $raw ) {
		$raw = is_array( $raw ) ? $raw : [];
		return [
			'image_desktop' => absint( $raw['image_desktop'] ?? 0 ),
			'image_mobile'  => absint( $raw['image_mobile']  ?? 0 ),
			'youtube_url'   => esc_url_raw( $raw['youtube_url'] ?? '' ),
		];
	}

	/**
	 * Reads $_POST['uhaifa_dynamic_items'], sanitizes each row, and drops
	 * fully-empty rows. Unlike sanitize_slides_from_post(), a row is kept as
	 * long as it has a title or a button URL — full completeness (both
	 * present, plus background where required) is checked separately in
	 * validate_before_save(), since what counts as "complete" depends on
	 * the campaign's bg_mode, which this method doesn't know about.
	 */
	private function sanitize_dynamic_items_from_post() {
		$raw = $_POST['uhaifa_dynamic_items'] ?? [];
		if ( ! is_array( $raw ) ) return [];

		$clean = [];
		foreach ( $raw as $row ) {
			$title       = sanitize_text_field( $row['title']       ?? '' );
			$button_url  = esc_url_raw( $row['button_url'] ?? '' );
			$bg          = $this->sanitize_dynamic_bg_from_post_array( $row );

			// Skip fully-empty rows (e.g. an added-then-untouched row). A row
			// with only background images and no text (bg_mode = 'multi',
			// where the text lives in _uhaifa_dynamic_static_text instead)
			// still counts as non-empty.
			if ( $title === '' && $button_url === '' && ! $bg['image_desktop'] && ! $bg['image_mobile'] ) continue;

			$clean[] = array_merge( $bg, [
				'title'         => $title,
				'text'          => sanitize_textarea_field( $row['text'] ?? '' ),
				'button_text'   => sanitize_text_field( $row['button_text'] ?? '' ),
				'button_url'    => $button_url,
				'button_target' => sanitize_key( $row['button_target'] ?? '_blank' ) ?: '_blank',
			] );
		}

		return $clean;
	}

	/**
	 * Sanitizes the single static text/button block used by bg_mode = 'multi'.
	 */
	private function sanitize_static_text_from_post( $raw ) {
		$raw = is_array( $raw ) ? $raw : [];
		return [
			'title'         => sanitize_text_field( $raw['title'] ?? '' ),
			'text'          => sanitize_textarea_field( $raw['text'] ?? '' ),
			'button_text'   => sanitize_text_field( $raw['button_text'] ?? '' ),
			'button_url'    => esc_url_raw( $raw['button_url'] ?? '' ),
			'button_target' => sanitize_key( $raw['button_target'] ?? '_blank' ) ?: '_blank',
		];
	}

	/**
	 * Extracts an 11-character YouTube video ID from any common URL shape
	 * (watch?v=, youtu.be/, embed/, shorts/). Returns '' if nothing matches,
	 * so callers can treat that as "no video, use the image instead".
	 */
	protected function extract_youtube_id( $url ) {
		if ( ! $url ) return '';
		if ( preg_match( '~(?:youtu\.be/|youtube\.com/(?:watch\?v=|embed/|shorts/))([A-Za-z0-9_-]{11})~', $url, $m ) ) {
			return $m[1];
		}
		return '';
	}

	// ─── Settings page (global slide duration) ────────────────────────────────

	public function add_settings_page() {
		add_submenu_page(
			'edit.php?post_type=uhaifa_banner',
			'הגדרות סבב באנרים',
			'הגדרות',
			'manage_options',
			'uhaifa-banners-settings',
			[ $this, 'render_settings_page' ]
		);
	}

	public function render_settings_page() {
		if ( isset( $_POST['uhaifa_duration'] ) && check_admin_referer( 'uhaifa_settings_save' ) ) {
			update_option( 'uhaifa_banners_slide_duration', max( 1000, absint( $_POST['uhaifa_duration'] ) ) );
			update_option( 'uhaifa_allow_hero_override', isset( $_POST['uhaifa_allow_hero_override'] ) );
			echo '<div class="notice notice-success"><p>נשמר.</p></div>';
		}
		$duration    = get_option( 'uhaifa_banners_slide_duration', 5000 );
		$allow_hero  = get_option( 'uhaifa_allow_hero_override', true );
		?>
		<div class="wrap">
			<h1>הגדרות סבב באנרים</h1>
			<form method="post">
				<?php wp_nonce_field( 'uhaifa_settings_save' ); ?>
				<table class="form-table">
					<tr>
						<th><label for="uhaifa_duration">משך הצגת כל שקופית (מילישניות)</label></th>
						<td>
							<input type="number" name="uhaifa_duration" id="uhaifa_duration" min="1000" step="500" value="<?php echo esc_attr( $duration ); ?>">
							<p class="description">זמן שכל שקופית מוצגת במלואה לפני מעבר (fade) לשקופית הבאה, כברירת מחדל לכל הקמפיינים (ניתן לדרוס לקמפיין ספציפי).</p>
						</td>
					</tr>
					<tr>
						<th>שליטת האתר הראשי</th>
						<td>
							<label>
								<input type="checkbox" name="uhaifa_allow_hero_override" id="uhaifa_allow_hero_override" value="1" <?php checked( $allow_hero, true ); ?>>
								אפשר לאתר הראשי לדרוס את הגיבור (Hero Banner) באתר זה
							</label>
							<p class="description">כברירת מחדל מופעל. כאשר מבוטל, האתר יתעלם מיידית מכל דריסה שנשלחת מהאתר המרכזי — כולל דריסה הפעילה כרגע.</p>
						</td>
					</tr>
				</table>
				<?php submit_button( 'שמור' ); ?>
			</form>
		</div>
		<?php
	}

	// ─── Response building (shared by the hub's REST /active and the local
	// Elementor widget's direct, same-site lookup) ─────────────────────────

	/**
	 * Finds and builds the response for the currently-active LOCAL campaign
	 * on this site — no site targeting involved, since a local campaign only
	 * ever applies to the site it lives on.
	 *
	 * @param int $specific_id If given, only this campaign is considered
	 *                         (still subject to publish status + dates) —
	 *                         used when a widget instance is pinned to one
	 *                         specific campaign rather than "whichever is
	 *                         currently active".
	 * @return array|null
	 */
	/**
	 * $target_terms, if given, is [ 'category' => [term_ids], 'post_tag' =>
	 * [term_ids] ] — a widget asking for a specific location's campaign.
	 * Resolution order: (1) a currently-active campaign carrying any of
	 * those terms wins outright; (2) failing that — or if no target terms
	 * were given at all — fall back to the general pool: currently-active
	 * campaigns with NO category/tag of their own, i.e. the sitewide
	 * default. $specific_id (pin to one exact post) bypasses all of this,
	 * same as before.
	 */
	public function get_active_local_response( $specific_id = 0, $target_terms = [] ) {
		$now               = current_time( 'Y-m-d H:i' );
		$duration_default  = (int) get_option( 'uhaifa_banners_slide_duration', 5000 );

		if ( $specific_id ) {
			$banner = get_post( $specific_id );
			if ( ! $banner || $banner->post_type !== 'uhaifa_banner' || $banner->post_status !== 'publish' ) return null;

			$is_evergreen = (bool) get_post_meta( $banner->ID, '_uhaifa_evergreen', true );
			$date_end     = get_post_meta( $banner->ID, '_uhaifa_date_end', true );

			if ( ! $is_evergreen ) {
				$date_start = get_post_meta( $banner->ID, '_uhaifa_date_start', true );
				if ( ! $date_start || $date_start > $now ) return null;
				if ( $date_end && $date_end < $now ) return null;
			}

			return $this->build_response_for_banner( $banner, $duration_default, $date_end );
		}

		$terms_query = $this->matching_terms_tax_query( $target_terms );
		if ( $terms_query ) {
			$response = $this->find_active_local_response( $terms_query, $now, $duration_default );
			if ( $response !== null ) return $response;
		}

		$response = $this->find_active_local_response( $this->untargeted_tax_query(), $now, $duration_default );
		if ( $response !== null ) return $response;

		// Last resort: the one site-wide, dateless fallback campaign, if any.
		return $this->get_evergreen_response( $duration_default );
	}

	/** Fetches the single (at most) evergreen fallback campaign, if one is currently published. */
	private function get_evergreen_response( $duration_default ) {
		$banners = get_posts( [
			'post_type'      => 'uhaifa_banner',
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'meta_query'     => [
				[ 'key' => '_uhaifa_evergreen', 'value' => '1' ],
			],
		] );
		if ( empty( $banners ) ) return null;

		return $this->build_response_for_banner( $banners[0], $duration_default, '' );
	}

	/** Shared date-active lookup, parameterized by an optional tax_query. */
	private function find_active_local_response( $tax_query, $now, $duration_default ) {
		$args = [
			'post_type'      => 'uhaifa_banner',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'meta_query'     => [
				'date_start_clause' => [
					'key'     => '_uhaifa_date_start',
					'value'   => $now,
					'compare' => '<=',
					'type'    => 'DATETIME',
				],
			],
			'orderby'   => 'date_start_clause',
			'order'     => 'DESC',
			'tax_query' => $tax_query,
		];

		$banners = get_posts( $args );

		foreach ( $banners as $banner ) {
			$date_end = get_post_meta( $banner->ID, '_uhaifa_date_end', true );
			if ( $date_end && $date_end < $now ) continue;

			$response = $this->build_response_for_banner( $banner, $duration_default, $date_end );
			if ( $response !== null ) return $response;
		}

		return null;
	}

	/** tax_query matching "has no category AND no tag at all" — the general/fallback pool. */
	private function untargeted_tax_query() {
		return [
			'relation' => 'AND',
			[ 'taxonomy' => 'category', 'operator' => 'NOT EXISTS' ],
			[ 'taxonomy' => 'post_tag', 'operator' => 'NOT EXISTS' ],
		];
	}

	/** tax_query matching ANY of the given term_ids, across category and/or tag. Null if nothing was actually requested. */
	private function matching_terms_tax_query( $target_terms ) {
		$clauses = [ 'relation' => 'OR' ];

		if ( ! empty( $target_terms['category'] ) ) {
			$clauses[] = [ 'taxonomy' => 'category', 'field' => 'term_id', 'terms' => array_map( 'absint', $target_terms['category'] ) ];
		}
		if ( ! empty( $target_terms['post_tag'] ) ) {
			$clauses[] = [ 'taxonomy' => 'post_tag', 'field' => 'term_id', 'terms' => array_map( 'absint', $target_terms['post_tag'] ) ];
		}

		return count( $clauses ) > 1 ? $clauses : null;
	}

	/** Dispatches to build_image_response()/build_dynamic_response(), resolving the per-campaign duration override. */
	protected function build_response_for_banner( $banner, $duration_default, $date_end ) {
		$duration_override = get_post_meta( $banner->ID, '_uhaifa_duration_override', true );
		$duration          = $duration_override !== '' ? (int) $duration_override : $duration_default;
		$banner_type       = get_post_meta( $banner->ID, '_uhaifa_banner_type', true ) ?: 'image';

		return ( $banner_type === 'dynamic' )
			? $this->build_dynamic_response( $banner, $duration, $date_end )
			: $this->build_image_response( $banner, $duration, $date_end );
	}

	/**
	 * Builds the response payload for an 'image' type campaign. Returns null
	 * if the campaign ends up with no usable slides (e.g. all rows incomplete).
	 */
	protected function build_image_response( $banner, $duration, $date_end ) {
		$campaign_link_url    = get_post_meta( $banner->ID, '_uhaifa_link_url',    true );
		$campaign_link_target = get_post_meta( $banner->ID, '_uhaifa_link_target', true ) ?: '_blank';

		$raw_slides = get_post_meta( $banner->ID, '_uhaifa_slides', true );
		$raw_slides = is_array( $raw_slides ) ? $raw_slides : [];

		$slides = [];
		foreach ( $raw_slides as $slide ) {
			$desktop_id = absint( $slide['desktop'] ?? 0 );
			$mobile_id  = absint( $slide['mobile']  ?? 0 );
			if ( ! $desktop_id || ! $mobile_id ) continue; // defensive, should already be clean

			$slide_link = $slide['link_url'] ?? '';

			$slides[] = [
				'desktop'     => wp_get_attachment_image_url( $desktop_id, 'full' ),
				'mobile'      => wp_get_attachment_image_url( $mobile_id,  'full' ),
				'title'       => get_the_title( $banner ),
				'alt'         => $slide['alt'] ?? '',
				// Fallback to campaign-level link when the slide has none of its own
				'link_url'    => $slide_link !== '' ? $slide_link : $campaign_link_url,
				'link_target' => $slide_link !== '' ? ( $slide['link_target'] ?? '_blank' ) : $campaign_link_target,
			];
		}

		if ( empty( $slides ) ) return null;

		return [
			'id'       => $banner->ID,
			'type'     => 'image',
			'duration' => $duration,
			'slides'   => $slides,
			'items'    => [],
			'expires'  => $date_end ? strtotime( $date_end ) : null,
		];
	}

	/**
	 * Builds the response payload for a 'dynamic' type campaign. Returns null
	 * if the campaign ends up with no usable items, or (shared mode) no
	 * usable background. YouTube URLs are resolved to plain video IDs here,
	 * at output time, so the front end never has to parse a URL.
	 */
		protected function build_dynamic_response( $banner, $duration, $date_end ) {
		$bg_mode     = get_post_meta( $banner->ID, '_uhaifa_dynamic_bg_mode', true ) ?: 'shared';
		$shared_bg   = get_post_meta( $banner->ID, '_uhaifa_dynamic_shared_bg', true );
		$shared_bg   = is_array( $shared_bg ) ? $shared_bg : [];
		$raw_items   = get_post_meta( $banner->ID, '_uhaifa_dynamic_items', true );
		$raw_items   = is_array( $raw_items ) ? $raw_items : [];
		$static_text = get_post_meta( $banner->ID, '_uhaifa_dynamic_static_text', true );
		$static_text = is_array( $static_text ) ? $static_text : [];

		// bg_mode = 'multi': items are background-only (images, no text/link
		// of their own) — only the FIRST one is mandatory, the rest are
		// optional extra rotation frames and are simply skipped if empty.
		if ( $bg_mode === 'multi' ) {
			$items = [];
			foreach ( $raw_items as $item ) {
				$mobile_id = absint( $item['image_mobile'] ?? 0 );
				if ( ! $mobile_id ) continue;

				$desktop_id = absint( $item['image_desktop'] ?? 0 );
				$items[] = [
					'desktop' => $desktop_id ? wp_get_attachment_image_url( $desktop_id, 'full' ) : null,
					'mobile'  => wp_get_attachment_image_url( $mobile_id, 'full' ),
				];
			}

			if ( empty( $items ) ) return null;
			if ( ( $static_text['title'] ?? '' ) === '' ) return null; // permanent title is mandatory

			return [
				'id'          => $banner->ID,
				'type'        => 'dynamic',
				'bg_mode'     => $bg_mode,
				'duration'    => $duration,
				'slides'      => [],
				'items'       => $items,
				'static_text' => [
					'title'         => $static_text['title'],
					'text'          => $static_text['text']          ?? '',
					'button_text'   => $static_text['button_text']   ?? '',
					'button_url'    => $static_text['button_url']    ?? '',
					'button_target' => $static_text['button_target'] ?? '_blank',
				],
				'expires'     => $date_end ? strtotime( $date_end ) : null,
			];
		}

		// bg_mode = 'shared' / 'per_item': unchanged.
		$items = [];
		foreach ( $raw_items as $item ) {
			$title      = $item['title']      ?? '';
			$button_url = $item['button_url'] ?? '';
			if ( $title === '' ) continue; // title is the only required field — button link is optional

			$entry = [
				'title'         => $title,
				'text'          => $item['text']          ?? '',
				'button_text'   => $item['button_text']   ?? '',
				'button_url'    => $button_url,
				'button_target' => $item['button_target'] ?? '_blank',
			];

			if ( $bg_mode === 'per_item' ) {
				$desktop_id = absint( $item['image_desktop'] ?? 0 );
				$mobile_id  = absint( $item['image_mobile']  ?? 0 );
				if ( ! $mobile_id ) continue; // mobile background is mandatory even for video items

				$entry['desktop']    = $desktop_id ? wp_get_attachment_image_url( $desktop_id, 'full' ) : null;
				$entry['mobile']     = wp_get_attachment_image_url( $mobile_id, 'full' );
				$entry['youtube_id'] = $this->extract_youtube_id( $item['youtube_url'] ?? '' );
			}

			$items[] = $entry;
		}

		if ( empty( $items ) ) return null;

		$response = [
			'id'       => $banner->ID,
			'type'     => 'dynamic',
			'bg_mode'  => $bg_mode,
			'duration' => $duration,
			'slides'   => [],
			'items'    => $items,
			'expires'  => $date_end ? strtotime( $date_end ) : null,
		];

		if ( $bg_mode === 'shared' ) {
			$mobile_id = absint( $shared_bg['image_mobile'] ?? 0 );
			if ( ! $mobile_id ) return null; // shared mode requires a shared background

			$desktop_id = absint( $shared_bg['image_desktop'] ?? 0 );

			$response['background'] = [
				'desktop'    => $desktop_id ? wp_get_attachment_image_url( $desktop_id, 'full' ) : null,
				'mobile'     => wp_get_attachment_image_url( $mobile_id, 'full' ),
				'youtube_id' => $this->extract_youtube_id( $shared_bg['youtube_url'] ?? '' ),
			];
		}

		return $response;
	}

	/**
	 * Options for an admin "pick a specific campaign" <select> (used by the
	 * Elementor widget's local_campaign_id control). Any status is included
	 * except trash, so a scheduled-but-not-yet-live campaign can still be
	 * pinned ahead of time.
	 */
	public static function get_campaign_select_options() {
		$posts = get_posts( [
			'post_type'      => 'uhaifa_banner',
			'post_status'    => [ 'publish', 'draft', 'pending', 'future' ],
			'posts_per_page' => -1,
			'orderby'        => 'title',
			'order'          => 'ASC',
		] );

		$options = [];
		foreach ( $posts as $post ) {
			$options[ $post->ID ] = $post->post_title ?: ( 'קמפיין #' . $post->ID );
		}
		return $options;
	}

	/**
	 * Options for the Elementor widget's target-term select2 — every
	 * category/tag on the site, not just ones already used on a campaign,
	 * since a sub-unit may want to target a term before any campaign uses
	 * it yet. Composite "{taxonomy}:{term_id}" values, since the same
	 * numeric term_id isn't guaranteed unique across the two taxonomies.
	 */
	public static function get_target_term_select_options() {
		$options = [];

		foreach ( [ 'category' => 'קטגוריה', 'post_tag' => 'תגית' ] as $taxonomy => $label ) {
			$terms = get_terms( [ 'taxonomy' => $taxonomy, 'hide_empty' => false ] );
			if ( is_wp_error( $terms ) ) continue;

			foreach ( $terms as $term ) {
				$options[ $taxonomy . ':' . $term->term_id ] = $label . ': ' . $term->name;
			}
		}

		return $options;
	}

	// ─── Admin Assets ─────────────────────────────────────────────────────────

	public function enqueue_admin_assets( $hook ) {
		if ( ! in_array( $hook, [ 'post.php', 'post-new.php' ] ) ) return;
		$screen = get_current_screen();
		if ( ! $screen || $screen->post_type !== 'uhaifa_banner' ) return;

		wp_enqueue_media();

		wp_enqueue_style(
			'uhaifa-banners-admin',
			UHAIFA_BANNERS_URL . 'assets/admin-banners.css',
			[],
			UHAIFA_BANNERS_VERSION
		);
		wp_enqueue_script(
			'uhaifa-banners-admin',
			UHAIFA_BANNERS_URL . 'assets/admin-banners.js',
			[ 'jquery', 'media-upload' ],
			UHAIFA_BANNERS_VERSION,
			true
		);
	}

	// ─── CPT List Columns ─────────────────────────────────────────────────────

	public function cpt_columns( $cols ) {
		return [
			'cb'          => $cols['cb'],
			'title'       => 'כותרת',
			'targets'     => 'יעד',
			'preview'     => 'תצוגה מקדימה',
			'banner_type' => 'סוג',
			'slides'      => 'פריטים',
			'date_start'  => 'התחלה',
			'date_end'    => 'סיום',
			'live_status' => 'סטטוס',
		];
	}

	public function cpt_column_content( $col, $post_id ) {
		switch ( $col ) {

			case 'targets':
				$terms = wp_get_post_terms( $post_id, [ 'category', 'post_tag' ] );
				$terms = is_wp_error( $terms ) ? [] : $terms;

				if ( empty( $terms ) ) {
					echo '<span style="color:#999">כללי</span>';
				} else {
					$pills = array_map( function ( $term ) {
						$color = $term->taxonomy === 'category' ? '#2271b1' : '#8c2ea3';
						return '<span style="display:inline-block;background:' . $color . ';color:#fff;border-radius:3px;padding:2px 8px;font-size:11px;margin:1px;white-space:nowrap;">' . esc_html( $term->name ) . '</span>';
					}, $terms );
					echo implode( ' ', $pills );
				}
				break;

			case 'preview':
				$banner_type = get_post_meta( $post_id, '_uhaifa_banner_type', true ) ?: 'image';

				if ( $banner_type === 'dynamic' ) {
					$bg_mode   = get_post_meta( $post_id, '_uhaifa_dynamic_bg_mode', true ) ?: 'shared';
					$mobile_id = 0;

					if ( $bg_mode === 'shared' ) {
						$shared_bg = get_post_meta( $post_id, '_uhaifa_dynamic_shared_bg', true );
						$mobile_id = is_array( $shared_bg ) ? absint( $shared_bg['image_mobile'] ?? 0 ) : 0;
					} else {
						$items = get_post_meta( $post_id, '_uhaifa_dynamic_items', true );
						$first = is_array( $items ) && ! empty( $items ) ? $items[0] : null;
						$mobile_id = $first ? absint( $first['image_mobile'] ?? 0 ) : 0;
					}

					if ( $mobile_id ) {
						echo '<img src="' . esc_url( wp_get_attachment_image_url( $mobile_id, 'thumbnail' ) ) . '" style="height:40px;border-radius:3px;" title="Background">';
					} else {
						echo '—';
					}
				} else {
					$slides = get_post_meta( $post_id, '_uhaifa_slides', true );
					$first  = is_array( $slides ) && ! empty( $slides ) ? $slides[0] : null;
					if ( $first ) {
						if ( ! empty( $first['desktop'] ) ) echo '<img src="' . esc_url( wp_get_attachment_image_url( $first['desktop'], 'thumbnail' ) ) . '" style="height:40px;border-radius:3px;margin-right:4px;" title="Desktop">';
						if ( ! empty( $first['mobile'] ) )  echo '<img src="' . esc_url( wp_get_attachment_image_url( $first['mobile'],  'thumbnail' ) ) . '" style="height:40px;border-radius:3px;" title="Mobile">';
					} else {
						echo '—';
					}
				}
				break;

			case 'banner_type':
				$banner_type = get_post_meta( $post_id, '_uhaifa_banner_type', true ) ?: 'image';
				echo $banner_type === 'dynamic'
					? '<span style="color:#8c2ea3">🎬 דינמי</span>'
					: '<span style="color:#2271b1">🖼️ תמונות</span>';
				break;

			case 'slides':
				$banner_type = get_post_meta( $post_id, '_uhaifa_banner_type', true ) ?: 'image';
				if ( $banner_type === 'dynamic' ) {
					$items = get_post_meta( $post_id, '_uhaifa_dynamic_items', true );
					$count = is_array( $items ) ? count( $items ) : 0;
				} else {
					$slides = get_post_meta( $post_id, '_uhaifa_slides', true );
					$count  = is_array( $slides ) ? count( $slides ) : 0;
				}
				echo esc_html( $count );
				break;

			case 'date_start':
				if ( get_post_meta( $post_id, '_uhaifa_evergreen', true ) ) {
					echo '<span style="color:#999">—</span>';
				} else {
					echo esc_html( str_replace( 'T', ' ', get_post_meta( $post_id, '_uhaifa_date_start', true ) ) );
				}
				break;

			case 'date_end':
				if ( get_post_meta( $post_id, '_uhaifa_evergreen', true ) ) {
					echo '<span style="color:#999">—</span>';
				} else {
					echo esc_html( str_replace( 'T', ' ', get_post_meta( $post_id, '_uhaifa_date_end', true ) ) );
				}
				break;

			case 'live_status':
				$now   = current_time( 'Y-m-d H:i' );
				$start = get_post_meta( $post_id, '_uhaifa_date_start', true );
				$end   = get_post_meta( $post_id, '_uhaifa_date_end',   true );
				$pub   = get_post_status( $post_id ) === 'publish';
				$ever  = (bool) get_post_meta( $post_id, '_uhaifa_evergreen', true );

				if ( $ever ) {
					echo $pub
						? '<span style="color:#dba617;font-weight:700">⭐ ברירת מחדל</span>'
						: '<span style="color:#999">— טיוטה</span>';
				} elseif ( ! $pub ) {
					echo '<span style="color:#999">— טיוטה</span>';
				} elseif ( $now >= $start && ( ! $end || $now <= $end ) ) {
					echo '<span style="color:#00a32a;font-weight:700">● פעיל</span>';
				} elseif ( $now < $start ) {
					echo '<span style="color:#dba617">◷ מתוזמן</span>';
				} else {
					echo '<span style="color:#999">✓ הסתיים</span>';
				}
				break;
		}
	}

	/** Adds a "⭐ ברירת מחדל" label next to the title, alongside WP's own native "— Draft"/"— Pending Review" states. */
	public function add_evergreen_post_state( $states, $post ) {
		if ( $post->post_type !== 'uhaifa_banner' ) return $states;

		if ( get_post_meta( $post->ID, '_uhaifa_evergreen', true ) ) {
			$states['uhaifa_evergreen'] = '⭐ ברירת מחדל';
		}

		return $states;
	}
}
