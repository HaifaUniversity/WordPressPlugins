<?php
/**
 * "מבזק קמפוס" (campus flash) CPT — runs ONLY on the hub site.
 *
 * Superadmin-only, by design entirely separate from the whitelist-based
 * access control used for uhaifa_banner: no per-site opt-out, no webmaster
 * involvement at all. One post = one flash item (post_title IS the message
 * text). Registered with show_in_menu => false — the menu entry itself now
 * lives in UHaifa_Flash_Grid (the "edit everything on one screen" grid
 * page), which is the intended way in. This class owns data + REST +
 * validation only; current_screen is kept as a hard backstop against
 * direct-URL access to the standard post editor, which still technically
 * exists underneath the grid.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class UHaifa_Flash_CPT {

	// Set true by UHaifa_Flash_Grid around its own wp_insert_post()/
	// wp_update_post() calls, which validate each row themselves against
	// their own (differently-shaped) $_POST data — this flag tells
	// validate_before_save() to stand down rather than apply its
	// meta-box-specific $_POST assumptions to a grid save.
	public static $skip_validation = false;

	public function __construct() {
		add_action( 'init',                                    [ $this, 'register_cpt' ] );
		add_action( 'current_screen',                          [ $this, 'restrict_to_superadmin' ] );
		add_action( 'add_meta_boxes',                          [ $this, 'add_meta_boxes' ] );
		add_action( 'save_post_uhaifa_flash',                  [ $this, 'save_meta' ] );
		add_filter( 'wp_insert_post_data',                     [ $this, 'validate_before_save' ], 10, 2 );
		add_action( 'admin_notices',                           [ $this, 'show_admin_errors' ] );
		add_action( 'admin_enqueue_scripts',                   [ $this, 'enqueue_admin_assets' ] );
		add_filter( 'manage_uhaifa_flash_posts_columns',       [ $this, 'cpt_columns' ] );
		add_action( 'manage_uhaifa_flash_posts_custom_column', [ $this, 'cpt_column_content' ], 10, 2 );
		add_action( 'rest_api_init',                           [ $this, 'register_rest_routes' ] );
		add_action( 'post_updated',                            [ $this, 'on_flash_updated' ], 10, 1 );
	}

	// ─── CPT + access control ───────────────────────────────────────────────

	public function register_cpt() {
		register_post_type( 'uhaifa_flash', [
			'labels' => [
				'name'          => 'מבזק קמפוס',
				'singular_name' => 'מבזק',
				'add_new'       => 'הוסף מבזק',
				'add_new_item'  => 'הוסף מבזק חדש',
				'edit_item'     => 'ערוך מבזק',
				'view_item'     => 'צפה במבזק',
				'search_items'  => 'חפש מבזקים',
				'not_found'     => 'לא נמצאו מבזקים.',
				'menu_name'     => 'מבזק קמפוס',
			],
			'public'       => false,
			'show_ui'      => true,
			'show_in_menu' => false, // added manually in add_menu(), superadmin only
			'supports'     => [ 'title' ],
			'menu_icon'    => 'dashicons-megaphone',
			'show_in_rest' => false,
		] );
	}

	public function restrict_to_superadmin( $screen ) {
		if ( ! $screen || $screen->post_type !== 'uhaifa_flash' ) return;
		if ( is_super_admin() ) return;
		wp_die( 'אין לך הרשאה לגשת לעמוד זה.', 'אין הרשאה', [ 'response' => 403 ] );
	}

	// ─── Meta box ────────────────────────────────────────────────────────────

	public function add_meta_boxes() {
		add_meta_box( 'uhaifa_flash_details', 'פרטי המבזק', [ $this, 'render_meta_box' ], 'uhaifa_flash', 'normal', 'high' );
	}

	public function render_meta_box( $post ) {
		wp_nonce_field( 'uhaifa_flash_save', 'uhaifa_flash_nonce' );

		$link        = get_post_meta( $post->ID, '_uhaifa_flash_link',        true );
		$date_start  = get_post_meta( $post->ID, '_uhaifa_flash_date_start',  true );
		$date_end    = get_post_meta( $post->ID, '_uhaifa_flash_date_end',    true );
		?>
		<div class="uhaifa-meta-box">
			<div class="uhaifa-settings-section">
				<h3 class="uhaifa-settings-section-title">פרטי המבזק</h3>
				<p class="description">כותרת הפוסט (למעלה) היא טקסט המבזק עצמו, כפי שיוצג בכל האתרים.</p>

				<div class="uhaifa-field" style="margin-bottom:16px;">
					<label for="uhaifa_flash_link">קישור (אופציונלי)</label>
					<input type="url" name="uhaifa_flash_link" id="uhaifa_flash_link" class="widefat" value="<?php echo esc_attr( $link ); ?>" placeholder="https://">
				</div>

				<div class="uhaifa-dates-row">
					<div class="uhaifa-field">
						<label for="uhaifa_flash_date_start">תאריך ושעת התחלה</label>
						<input type="datetime-local" name="uhaifa_flash_date_start" id="uhaifa_flash_date_start" value="<?php echo esc_attr( $date_start ); ?>">
					</div>
					<div class="uhaifa-field">
						<label for="uhaifa_flash_date_end">תאריך ושעת סיום (אופציונלי)</label>
						<input type="datetime-local" name="uhaifa_flash_date_end" id="uhaifa_flash_date_end" value="<?php echo esc_attr( $date_end ); ?>">
					</div>
				</div>

				<div class="uhaifa-info-box" style="margin-top:16px;">
					מבזק זה יוצג תמיד בדף הבית של כל אתר, כברירת מחדל. בנוסף, אם מבקר מגיע לכל דף פנימי אחר באתר דרך קישור מאתר חיצוני, המבזק יוצג פעם אחת גם שם — ללא צורך בהגדרה נוספת.
				</div>
			</div>
		</div>
		<?php
	}

	public function save_meta( $post_id ) {
		if ( ! isset( $_POST['uhaifa_flash_nonce'] ) ) return;
		if ( ! wp_verify_nonce( $_POST['uhaifa_flash_nonce'], 'uhaifa_flash_save' ) ) return;
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
		if ( ! is_super_admin() ) return;
		if ( ! current_user_can( 'edit_post', $post_id ) ) return;

		$scalar_fields = [
			'_uhaifa_flash_link'        => [ 'post' => 'uhaifa_flash_link',        'san' => 'esc_url_raw' ],
			'_uhaifa_flash_date_start'  => [ 'post' => 'uhaifa_flash_date_start',  'san' => 'sanitize_text_field' ],
			'_uhaifa_flash_date_end'    => [ 'post' => 'uhaifa_flash_date_end',    'san' => 'sanitize_text_field' ],
		];

		foreach ( $scalar_fields as $meta_key => $opts ) {
			if ( isset( $_POST[ $opts['post'] ] ) ) {
				update_post_meta( $post_id, $meta_key, call_user_func( $opts['san'], $_POST[ $opts['post'] ] ) );
			}
		}

		update_option( 'uhaifa_flash_last_updated', time() );
		delete_transient( 'uhaifa_flash_' . md5( untrailingslashit( get_site_url() ) ) );
	}

	// ─── Validation (same hard-error-on-missing-start-date pattern as banners) ─

	public function validate_before_save( $data, $postarr ) {
		if ( self::$skip_validation )                return $data;
		if ( $data['post_type'] !== 'uhaifa_flash' ) return $data;
		if ( $data['post_status'] !== 'publish' )    return $data;
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return $data;

		$post_id = isset( $postarr['ID'] ) ? absint( $postarr['ID'] ) : 0;

		$meta_box_submitted = isset( $_POST['uhaifa_flash_nonce'] )
			&& wp_verify_nonce( $_POST['uhaifa_flash_nonce'], 'uhaifa_flash_save' );

		$date_start = $meta_box_submitted
			? sanitize_text_field( $_POST['uhaifa_flash_date_start'] ?? '' )
			: get_post_meta( $post_id, '_uhaifa_flash_date_start', true );

		$errors = [];
		if ( empty( $data['post_title'] ) ) $errors[] = 'missing_message';
		if ( ! $date_start )                $errors[] = 'missing_start_date';

		if ( $errors ) {
			set_transient( 'uhaifa_flash_errors_' . $post_id, $errors, 45 );
			$data['post_status'] = 'draft';
		}

		return $data;
	}

	public function show_admin_errors() {
		$screen = get_current_screen();
		if ( ! $screen || $screen->post_type !== 'uhaifa_flash' ) return;

		$post_id = absint( $_GET['post'] ?? 0 );
		if ( ! $post_id ) return;

		$errors = get_transient( 'uhaifa_flash_errors_' . $post_id );
		if ( ! $errors ) return;
		delete_transient( 'uhaifa_flash_errors_' . $post_id );

		foreach ( $errors as $error ) {
			if ( $error === 'missing_message' ) {
				echo '<div class="notice notice-error"><p><strong>מבזק קמפוס:</strong> יש להזין טקסט מבזק (כותרת) לפני פרסום. המבזק נשמר כטיוטה.</p></div>';
			} elseif ( $error === 'missing_start_date' ) {
				echo '<div class="notice notice-error"><p><strong>מבזק קמפוס:</strong> יש להגדיר תאריך ושעת התחלה לפני פרסום — ללא תאריך התחלה המבזק לא יוצג. המבזק נשמר כטיוטה.</p></div>';
			}
		}
	}

	// ─── Admin assets (reuses the shared admin-banners.css classes) ───────────

	public function enqueue_admin_assets( $hook ) {
		if ( ! in_array( $hook, [ 'post.php', 'post-new.php' ], true ) ) return;
		$screen = get_current_screen();
		if ( ! $screen || $screen->post_type !== 'uhaifa_flash' ) return;

		wp_enqueue_style(
			'uhaifa-banners-admin',
			UHAIFA_BANNERS_URL . 'assets/admin-banners.css',
			[],
			UHAIFA_BANNERS_VERSION
		);
	}

	// ─── List columns ────────────────────────────────────────────────────────

	public function cpt_columns( $cols ) {
		$new = [];
		foreach ( $cols as $key => $label ) {
			$new[ $key ] = $label;
			if ( $key === 'title' ) {
				$new['uhaifa_dates']  = 'תאריכים';
				$new['uhaifa_status'] = 'סטטוס תצוגה';
			}
		}
		return $new;
	}

	public function cpt_column_content( $col, $post_id ) {
		$now   = current_time( 'Y-m-d H:i' );
		$start = get_post_meta( $post_id, '_uhaifa_flash_date_start', true );
		$end   = get_post_meta( $post_id, '_uhaifa_flash_date_end',   true );

	if ( $col === 'uhaifa_dates' ) {
			echo esc_html( str_replace( 'T', ' ', $start ) );
			if ( $end ) echo ' — ' . esc_html( str_replace( 'T', ' ', $end ) );

		} elseif ( $col === 'uhaifa_status' ) {
			if ( get_post_status( $post_id ) !== 'publish' ) {
				echo '<span style="color:#787c82">⬤ טיוטה</span>';
			} elseif ( ! $start || str_replace( 'T', ' ', $start ) > $now ) {
				echo '<span style="color:#dba617">⬤ מתוזמן</span>';
			} elseif ( $end && str_replace( 'T', ' ', $end ) < $now ) {
				echo '<span style="color:#787c82">⬤ עבר</span>';
			} else {
				echo '<span style="color:#00a32a">⬤ פעיל</span>';
			}
		}
	}

	// ─── REST ────────────────────────────────────────────────────────────────

	public function register_rest_routes() {
		register_rest_route( 'uhaifa-banners/v1', '/flash', [
			'methods'             => 'GET',
			'callback'            => [ $this, 'handle_flash' ],
			'permission_callback' => '__return_true',
		] );

		register_rest_route( 'uhaifa-banners/v1', '/flash-last-updated', [
			'methods'             => 'GET',
			'callback'            => function () {
				return rest_ensure_response( [ 'timestamp' => (int) get_option( 'uhaifa_flash_last_updated', 0 ) ] );
			},
			'permission_callback' => '__return_true',
		] );
	}

	public function on_flash_updated( $post_id ) {
		if ( get_post_type( $post_id ) !== 'uhaifa_flash' ) return;
		update_option( 'uhaifa_flash_last_updated', time() );
	}

	/**
	 * Returns EVERY currently-in-range flash item (not filtered by referrer —
	 * the spoke's cached copy of this response is what gets matched locally
	 * against the incoming referrer, so this stays cacheable regardless of
	 * who's asking or where from).
	 */
	public function handle_flash( WP_REST_Request $request ) {
		$now = current_time( 'Y-m-d H:i' );

		$flashes = get_posts( [
			'post_type'      => 'uhaifa_flash',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'meta_query'     => [
				'date_start_clause' => [
					'key'     => '_uhaifa_flash_date_start',
					'value'   => $now,
					'compare' => '<=',
					'type'    => 'DATETIME',
				],
			],
			'orderby' => 'date_start_clause',
			'order'   => 'ASC',
		] );

		$items = [];
		foreach ( $flashes as $flash ) {
			$end = get_post_meta( $flash->ID, '_uhaifa_flash_date_end', true );
			if ( $end && str_replace( 'T', ' ', $end ) < $now ) continue;

			$items[] = [
				'id'      => $flash->ID,
				'message' => get_the_title( $flash ),
				'link'    => get_post_meta( $flash->ID, '_uhaifa_flash_link', true ) ?: null,
			];
		}

		return rest_ensure_response( [
			'logo_url' => get_site_icon_url( 0, 64 ),
			'items'    => $items,
		] );
	}
}
