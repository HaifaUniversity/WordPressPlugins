<?php
/**
 * The UHaifa Hero Elementor widget — the "give site managers their own hero"
 * feature. A webmaster drags this into their hero area instead of a manual
 * Elementor section, giving them the exact same rendering system (fade
 * slideshow / dynamic background+text) the hub already uses, but driven by
 * LOCAL content:
 *
 *   - "Posts by tag": pulls this site's own posts (any public post type +
 *     taxonomy, configurable), one rotating item per post — featured image
 *     as the background, post title as the title, excerpt as the body text,
 *     button links through to the post itself. Mirrors what a "grab posts by
 *     tag" carousel plugin already does on some faculty sites, just rendered
 *     through our shared visual system.
 *   - "Local campaign": points at a uhaifa_banner post created LOCALLY on
 *     this site (via the same CPT + meta box the hub uses — see
 *     class-campaign-cpt.php) — either "whichever campaign is currently
 *     date-active" or one specific campaign pinned in the widget settings.
 *
 * Every render() first checks UHaifa_Banner_Override_Resolver for a hub
 * push targeted at this site. If one is active, it's rendered INSTEAD of
 * the widget's own local content — entirely server-side, no JS hide/swap —
 * which is also what makes this immune to the ad-block filename issue that
 * affected the legacy override path. Only the hub's own super-admin can
 * ever trigger this; a local site's own content can never affect other
 * sites.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( '\Elementor\Widget_Base' ) ) return;

require_once __DIR__ . '/class-hero-renderer.php';
require_once __DIR__ . '/class-override-resolver.php';
require_once __DIR__ . '/class-campaign-cpt.php';

class UHaifa_Elementor_Hero_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'uhaifa_hero';
	}

	public function get_title() {
		return 'UHaifa - באנר גיבור';
	}

	public function get_icon() {
		return 'eicon-slider-push';
	}

	public function get_categories() {
		return [ 'university' ];
	}

	public function get_keywords() {
		return [ 'hero', 'banner', 'slider', 'באנר', 'גיבור', 'סליידר', 'קמפיין' ];
	}

	public function get_style_depends() {
		return [ 'uhaifa-hero' ];
	}

	public function get_script_depends() {
		return [ 'uhaifa-hero' ];
	}

	// ─── Controls ─────────────────────────────────────────────────────────────

	protected function register_controls() {

		$this->start_controls_section( 'section_source', [
			'label' => 'מקור תוכן',
		] );

		$this->add_control( 'content_source', [
			'label'   => 'מקור התוכן לגיבור',
			'type'    => \Elementor\Controls_Manager::SELECT,
			'default' => 'posts_by_tag',
			'options' => [
				'posts_by_tag'   => 'פוסטים לפי תגית/קטגוריה',
				'local_campaign' => 'קמפיין מקומי (נבנה באתר הזה)',
			],
		] );

		$this->end_controls_section();

		// ── Display ──────────────────────────────────────────────────────────
		$this->start_controls_section( 'section_display', [
			'label' => 'תצוגה',
		] );

		$this->add_control( 'show_dots', [
			'label'        => 'הצג עיגולי ניווט (Dots)',
			'type'         => \Elementor\Controls_Manager::SWITCHER,
			'label_on'     => 'כן',
			'label_off'    => 'לא',
			'return_value' => 'yes',
			'default'      => 'yes',
			'description'  => 'לא זמין במצב "טקסט קבוע" של קמפיין דינמי — שם אין עיגולים בכל מקרה, כי הטקסט לא מתחלף.',
		] );

		$this->end_controls_section();

		// ── Posts by tag ────────────────────────────────────────────────────
		$this->start_controls_section( 'section_posts', [
			'label'     => 'הגדרות: פוסטים לפי תגית',
			'condition' => [ 'content_source' => 'posts_by_tag' ],
		] );

		$this->add_control( 'query_post_type', [
			'label'   => 'סוג תוכן',
			'type'    => \Elementor\Controls_Manager::SELECT,
			'default' => 'post',
			'options' => $this->get_post_type_options(),
		] );

		$this->add_control( 'query_terms', [
			'label'       => 'תגיות/קטגוריות',
			'type'        => \Elementor\Controls_Manager::SELECT2,
			'multiple'    => true,
			'label_block' => true,
			'options'     => $this->get_term_options(),
			'default'     => [],
			'description' => 'השאירו ריק לכל הפוסטים מהסוג שנבחר',
		] );

		$this->add_control( 'posts_count', [
			'label'   => 'מספר פוסטים',
			'type'    => \Elementor\Controls_Manager::NUMBER,
			'default' => 5,
			'min'     => 1,
			'max'     => 20,
		] );

		$this->add_control( 'query_orderby', [
			'label'   => 'מיון לפי',
			'type'    => \Elementor\Controls_Manager::SELECT,
			'default' => 'date',
			'options' => [
				'date'       => 'תאריך פרסום',
				'title'      => 'כותרת',
				'menu_order' => 'סדר תפריט',
				'rand'       => 'אקראי',
			],
		] );

		$this->add_control( 'query_order', [
			'label'   => 'כיוון מיון',
			'type'    => \Elementor\Controls_Manager::SELECT,
			'default' => 'DESC',
			'options' => [
				'DESC' => 'חדש לישן',
				'ASC'  => 'ישן לחדש',
			],
			'condition' => [ 'query_orderby!' => 'rand' ],
		] );

		$this->add_control( 'excerpt_length', [
			'label'   => 'אורך תקציר (מילים)',
			'type'    => \Elementor\Controls_Manager::NUMBER,
			'default' => 30,
			'min'     => 5,
			'max'     => 100,
		] );

		$this->add_control( 'button_text', [
			'label'   => 'טקסט כפתור',
			'type'    => \Elementor\Controls_Manager::TEXT,
			'default' => 'פרטים נוספים',
		] );

		$this->end_controls_section();

		// ── Local campaign ──────────────────────────────────────────────────
		$this->start_controls_section( 'section_local', [
			'label'     => 'הגדרות: קמפיין מקומי',
			'condition' => [ 'content_source' => 'local_campaign' ],
		] );

		$this->add_control( 'local_campaign_note', [
			'type' => \Elementor\Controls_Manager::RAW_HTML,
			'raw'  => 'ניהול הקמפיינים המקומיים נעשה בתפריט <strong>קמפיינים לגיבור</strong> בלוח הבקרה של האתר הזה — אותה מערכת תמונות/וידאו/סבב שהוגדרה עבור הבאנרים המרכזיים, אך משמשת רק אתר זה.',
		] );

		$this->add_control( 'local_campaign_mode', [
			'label'   => 'איזה קמפיין להציג',
			'type'    => \Elementor\Controls_Manager::SELECT,
			'default' => 'auto',
			'options' => [
				'auto'     => 'הקמפיין הפעיל הנוכחי (לפי תאריכים)',
				'specific' => 'קמפיין ספציפי',
			],
		] );

		$this->add_control( 'local_campaign_id', [
			'label'     => 'בחר קמפיין',
			'type'      => \Elementor\Controls_Manager::SELECT,
			'options'   => UHaifa_Banner_CPT::get_campaign_select_options(),
			'condition' => [ 'local_campaign_mode' => 'specific' ],
		] );

		$this->add_control( 'target_terms', [
			'label'       => 'סינון לפי תגית/קטגוריה',
			'type'        => \Elementor\Controls_Manager::SELECT2,
			'multiple'    => true,
			'label_block' => true,
			'options'     => UHaifa_Banner_CPT::get_target_term_select_options(),
			'condition'   => [ 'local_campaign_mode' => 'auto' ],
			'description' => 'ריק = יוצג רק הקמפיין הכללי (ללא תגית/קטגוריה). אם נבחר ערך כאן וקיים קמפיין פעיל המתויג באחד מהם — הוא יוצג במקום הקמפיין הכללי. אם אין כרגע קמפיין פעיל עם התגית/קטגוריה שנבחרה — הקמפיין הכללי יוצג כברירת מחדל.',
		] );

		$this->end_controls_section();
	}

	private function get_post_type_options() {
		$types   = get_post_types( [ 'public' => true ], 'objects' );
		$options = [];
		foreach ( $types as $type ) {
			if ( $type->name === 'attachment' ) continue;
			$options[ $type->name ] = $type->labels->name;
		}
		return $options;
	}

	private function get_term_options() {
		$taxonomies = get_taxonomies( [ 'public' => true, 'show_ui' => true ], 'objects' );
		unset( $taxonomies['post_format'], $taxonomies['nav_menu'], $taxonomies['link_category'] );

		$options = [];
		foreach ( $taxonomies as $taxonomy ) {
			$terms = get_terms( [ 'taxonomy' => $taxonomy->name, 'hide_empty' => false ] );
			if ( is_wp_error( $terms ) ) continue;

			foreach ( $terms as $term ) {
				// Value encodes its own taxonomy — lets get_posts_by_tag_data()
				// build a correct tax_query without needing a separate
				// taxonomy control, and avoids any ambiguity between two
				// taxonomies that happen to share a term name.
				$options[ $taxonomy->name . '|' . $term->term_id ] = $term->name . ' — ' . $taxonomy->labels->singular_name;
			}
		}
		return $options;
	}

	// ─── Render ───────────────────────────────────────────────────────────────

	protected function render() {
		$settings = $this->get_settings_for_display();

		// Elementor's SWITCHER stores '' (not the string 'no') when toggled
		// off — only a genuinely unset key (never saved) should fall back
		// to the 'yes' default via ??; anything else must be checked
		// explicitly against 'yes', not merely "not equal to 'no'".
		$wrapper_attrs = [
			'data-uh-show-dots' => ( ( $settings['show_dots'] ?? 'yes' ) === 'yes' ) ? '1' : '0',
		];

		// 1. Hub override always wins, resolved entirely server-side.
		$override = UHaifa_Banner_Override_Resolver::get_payload();
		if ( $override ) {
			echo UHaifa_Hero_Renderer::render( $override, [ 'uhaifa-hero-widget', 'uhaifa-hero-overridden' ], $wrapper_attrs );
			return;
		}

		// 2. This widget's own local content.
		$data = ( $settings['content_source'] ?? 'posts_by_tag' ) === 'local_campaign'
			? $this->get_local_campaign_data( $settings )
			: $this->get_posts_by_tag_data( $settings );

		if ( ! $data ) {
			if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
				echo '<div style="padding:40px 20px;text-align:center;background:#f6f7f7;border:2px dashed #c3c4c7;border-radius:4px;color:#787c82;">'
					. 'אין כרגע תוכן פעיל להצגה עבור הגדרות הווידג\'ט הנוכחיות (בדקו תגיות/תאריכי קמפיין).'
					. '</div>';
			}
			return;
		}

		echo UHaifa_Hero_Renderer::render( $data, [ 'uhaifa-hero-widget' ], $wrapper_attrs );
	}

	/**
	 * Maps this site's own posts into the shared dynamic/per-item response
	 * shape: featured image as background, title/excerpt/button overlay,
	 * button links to the post itself.
	 */
	private function get_posts_by_tag_data( $settings ) {
		$post_type   = $settings['query_post_type'] ?: 'post';
		$term_values = is_array( $settings['query_terms'] ?? null ) ? $settings['query_terms'] : [];
		$count       = max( 1, (int) ( $settings['posts_count']   ?? 5 ) );
		$orderby     = $settings['query_orderby']  ?: 'date';
		$order       = $settings['query_order']    ?: 'DESC';
		$excerpt_len = max( 5, (int) ( $settings['excerpt_length'] ?? 30 ) );
		$button_text = $settings['button_text'] ?: 'פרטים נוספים';

		$args = [
			'post_type'           => $post_type,
			'post_status'         => 'publish',
			'posts_per_page'      => $count,
			'orderby'             => $orderby,
			'order'               => $order,
			'ignore_sticky_posts' => true,
		];

		if ( ! empty( $term_values ) ) {
			// Group selected term IDs by their taxonomy (values look like
			// "post_tag|14"), since a single tax_query clause can only
			// target one taxonomy at a time. Clauses combine with OR — a
			// post matching ANY selected tag/category, across any of the
			// selected taxonomies, is included.
			$by_taxonomy = [];
			foreach ( $term_values as $value ) {
				$parts = explode( '|', $value, 2 );
				if ( count( $parts ) !== 2 ) continue;
				$by_taxonomy[ $parts[0] ][] = absint( $parts[1] );
			}

			if ( empty( $by_taxonomy ) ) return null;

			$tax_query = [ 'relation' => 'OR' ];
			foreach ( $by_taxonomy as $taxonomy => $term_ids ) {
				$tax_query[] = [
					'taxonomy' => $taxonomy,
					'field'    => 'term_id',
					'terms'    => $term_ids,
				];
			}
			$args['tax_query'] = $tax_query; // phpcs:ignore
		}

		$query = new WP_Query( $args );
		$items = [];

		foreach ( $query->posts as $post ) {
			$thumb_id = get_post_thumbnail_id( $post );
			if ( ! $thumb_id ) continue;
			if ( ! $thumb_id ) continue; // this layout is image-first — skip posts with no featured image

			$img_url = wp_get_attachment_image_url( $thumb_id, 'full' );

			$items[] = [
				'title'         => get_the_title( $post ),
				'text'          => wp_trim_words( wp_strip_all_tags( get_the_excerpt( $post ) ), $excerpt_len ),
				'button_text'   => $button_text,
				'button_url'    => get_permalink( $post ),
				'button_target' => '_self',
				'desktop'       => $img_url,
				'mobile'        => $img_url,
				'youtube_id'    => '',
			];
		}
		wp_reset_postdata();

	if ( empty( $items ) ) return null;

		return [
			'type'     => 'dynamic',
			'bg_mode'  => 'per_item',
			'duration' => (int) get_option( 'uhaifa_banners_slide_duration', 5000 ),
			'slides'   => [],
			'items'    => $items,
		];
	}

	/**
	 * Resolves the comma-separated text a webmaster typed into "תגיות/מונחים"
	 * into real term IDs — trying an exact slug match first, then falling
	 * back to an exact name match. Webmasters naturally type the readable
	 * name they see in wp-admin (e.g. "באנר"), not its slug — and for
	 * non-Latin scripts like Hebrew, WordPress' auto-generated slug is
	 * percent-encoded UTF-8 bytes, not the readable word, so a slug-only
	 * lookup would silently match nothing for exactly the input a real
	 * user would type.
	 */
	private function resolve_term_ids( $terms_raw, $taxonomy ) {
		$labels = array_values( array_filter( array_map( 'trim', explode( ',', $terms_raw ) ) ) );
		$ids    = [];

		foreach ( $labels as $label ) {
			$term = get_term_by( 'slug', sanitize_title( $label ), $taxonomy );
			if ( ! $term ) $term = get_term_by( 'slug', $label, $taxonomy );
			if ( ! $term ) $term = get_term_by( 'name', $label, $taxonomy );

			if ( $term && ! is_wp_error( $term ) ) {
				$ids[] = $term->term_id;
			}
		}

		return array_unique( $ids );
	}

	/** Looks up the local uhaifa_banner CPT instance registered by the bootstrap and asks it for the active/pinned local campaign. */
	private function get_local_campaign_data( $settings ) {
		global $uhaifa_banner_cpt;
		if ( ! $uhaifa_banner_cpt instanceof UHaifa_Banner_CPT ) return null;

		$specific_id = ( $settings['local_campaign_mode'] ?? 'auto' ) === 'specific'
			? absint( $settings['local_campaign_id'] ?? 0 )
			: 0;

		// "{taxonomy}:{term_id}" composite values back into per-taxonomy arrays.
		$target_terms = [ 'category' => [], 'post_tag' => [] ];
		foreach ( (array) ( $settings['target_terms'] ?? [] ) as $value ) {
			$parts = explode( ':', $value, 2 );
			if ( count( $parts ) === 2 && isset( $target_terms[ $parts[0] ] ) ) {
				$target_terms[ $parts[0] ][] = absint( $parts[1] );
			}
		}

		return $uhaifa_banner_cpt->get_active_local_response( $specific_id, $target_terms );
	}
}
