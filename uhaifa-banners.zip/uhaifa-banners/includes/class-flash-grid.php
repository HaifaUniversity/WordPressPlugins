<?php
/**
 * "מבזק קמפוס" grid admin page — runs ONLY on the hub site.
 *
 * Replaces the standard one-post-at-a-time CPT editor with a single
 * spreadsheet-style screen: every flash item as an editable row, an
 * "add row" button, and one "שמור הכל" button that creates/updates
 * everything in one request. Deleting a row hits admin-post.php
 * immediately (with a JS confirm() first) rather than being part of the
 * bulk save.
 *
 * Owns the "מבזק קמפוס" menu entry itself (UHaifa_Flash_CPT no longer
 * registers any menu) and the submenu reorder/cleanup for the parent
 * "באנרים מרכזיים" menu, since both are about where this page sits.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class UHaifa_Flash_Grid {

	const PAGE_SLUG = 'uhaifa-flash-manage';

	private $hook_suffix;

	public function __construct() {
		add_action( 'admin_menu',                 [ $this, 'add_menu' ], 20 );
		add_action( 'admin_menu',                 [ $this, 'reorder_menu' ], 999 );
		add_action( 'admin_enqueue_scripts',       [ $this, 'enqueue_admin_assets' ] );
		add_action( 'admin_post_uhaifa_flash_save_all', [ $this, 'handle_save_all' ] );
		add_action( 'admin_post_uhaifa_flash_delete',   [ $this, 'handle_delete' ] );
	}

	// ─── Menu ───────────────────────────────────────────────────────────────

	public function add_menu() {
		if ( ! is_super_admin() ) return;
		// 'read' is intentionally permissive — real gating is is_super_admin()
		// above, and render_grid_page()'s own check below, not a WP capability.
		$this->hook_suffix = add_submenu_page(
			'edit.php?post_type=uhaifa_banner',
			'מבזק קמפוס',
			'מבזק קמפוס',
			'read',
			self::PAGE_SLUG,
			[ $this, 'render_grid_page' ]
		);
	}

	/**
	 * Cleans up the "באנרים מרכזיים" submenu: WordPress core auto-adds
	 * "Add New", plus a Categories/Tags entry for any taxonomy attached to
	 * uhaifa_banner, right when it builds the CPT's menu — before any
	 * plugin admin_menu callback runs. Priority 999 here guarantees this
	 * runs dead last, after that core behavior AND our own add_menu()
	 * (priority 20) AND UHaifa_Banner_CPT::add_settings_page() (priority
	 * 10) have all added their entries, so there's a final, complete list
	 * to filter and reorder in one place. Final order: the list itself,
	 * מבזק קמפוס, then הגדרות.
	 */
	public function reorder_menu() {
		global $submenu;

		$parent = 'edit.php?post_type=uhaifa_banner';
		if ( empty( $submenu[ $parent ] ) ) return;

		$items = array_filter( $submenu[ $parent ], function ( $item ) {
			$slug = $item[2] ?? '';
			return false === strpos( $slug, 'post-new.php' )
				&& false === strpos( $slug, 'edit-tags.php' );
		} );

		$order = [
			$parent            => 0, // "באנרים מרכזיים" (the list itself)
			self::PAGE_SLUG    => 1, // מבזק קמפוס
			'uhaifa-banners-settings' => 2, // הגדרות
		];

		usort( $items, function ( $a, $b ) use ( $order ) {
			$a_pos = $order[ $a[2] ?? '' ] ?? 99;
			$b_pos = $order[ $b[2] ?? '' ] ?? 99;
			return $a_pos <=> $b_pos;
		} );

		$submenu[ $parent ] = array_values( $items );
	}

	public function enqueue_admin_assets( $hook ) {
		if ( ! $this->hook_suffix || $hook !== $this->hook_suffix ) return;

		wp_enqueue_style(
			'uhaifa-banners-admin',
			UHAIFA_BANNERS_URL . 'assets/admin-banners.css',
			[],
			UHAIFA_BANNERS_VERSION
		);
		wp_enqueue_script(
			'uhaifa-flash-grid',
			UHAIFA_BANNERS_URL . 'assets/admin-flash-grid.js',
			[],
			UHAIFA_BANNERS_VERSION,
			true
		);
	}

	// ─── Page ───────────────────────────────────────────────────────────────

	public function render_grid_page() {
		if ( ! is_super_admin() ) {
			wp_die( 'אין לך הרשאה לגשת לעמוד זה.', 'אין הרשאה', [ 'response' => 403 ] );
		}

		$flashes = get_posts( [
			'post_type'      => 'uhaifa_flash',
			'post_status'    => [ 'publish', 'draft' ],
			'posts_per_page' => -1,
			'orderby'        => 'ID',
			'order'          => 'DESC',
		] );
		?>
		<div class="wrap">
			<h1>מבזק קמפוס</h1>

			<?php if ( isset( $_GET['saved'] ) ) : ?>
				<div class="notice notice-success is-dismissible"><p>נשמר.</p></div>
			<?php endif; ?>

			<?php $this->render_row_errors(); ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="uhaifa_flash_save_all">
				<?php wp_nonce_field( 'uhaifa_flash_save', 'uhaifa_flash_nonce' ); ?>

				<table class="widefat uhaifa-flash-grid" id="uhaifa-flash-grid-table">
					<thead>
						<tr>
							<th style="width:32%;">הודעה</th>
							<th style="width:20%;">קישור (אופציונלי)</th>
							<th style="width:18%;">התחלה</th>
							<th style="width:18%;">סיום (אופציונלי)</th>
							<th style="width:8%;">סטטוס</th>
							<th style="width:4%;"></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $flashes as $i => $flash ) : ?>
							<?php $this->render_row( $i, $flash ); ?>
						<?php endforeach; ?>
					</tbody>
				</table>

				<p style="margin-top:12px;">
					<button type="button" class="button" id="uhaifa-flash-add-row">+ הוסף מבזק</button>
					<button type="submit" class="button button-primary">שמור הכל</button>
				</p>
			</form>

			<template id="uhaifa-flash-row-template">
				<?php $this->render_row( '__INDEX__', null ); ?>
			</template>
		</div>
		<?php
	}

	private function render_row_errors() {
		$errors = get_transient( 'uhaifa_flash_grid_errors' );
		if ( ! $errors ) return;
		delete_transient( 'uhaifa_flash_grid_errors' );
		?>
		<div class="notice notice-error">
			<p><strong>המבזקים הבאים נשמרו כטיוטה כי חסר בהם טקסט או תאריך התחלה:</strong> <?php echo esc_html( implode( ', ', $errors ) ); ?></p>
		</div>
		<?php
	}

	/**
	 * Renders one <tr>. Pass $post = null (with $i = '__INDEX__') to render
	 * the blank <template> row that admin-flash-grid.js clones for "add row".
	 */
	private function render_row( $i, $post ) {
		$id         = $post ? $post->ID : 0;
		$message    = $post ? $post->post_title : '';
		$link       = $post ? get_post_meta( $id, '_uhaifa_flash_link',       true ) : '';
		$date_start = $post ? get_post_meta( $id, '_uhaifa_flash_date_start', true ) : '';
		$date_end   = $post ? get_post_meta( $id, '_uhaifa_flash_date_end',   true ) : '';
		$status     = $post ? get_post_status( $id ) : 'publish';

		$now              = current_time( 'Y-m-d H:i' );
		$start_normalized = str_replace( 'T', ' ', $date_start );
		$end_normalized   = str_replace( 'T', ' ', $date_end );

		if ( $status !== 'publish' ) {
			$status_label = '<span style="color:#787c82;">טיוטה</span>';
		} elseif ( ! $date_start || $start_normalized > $now ) {
			$status_label = '<span style="color:#dba617;">מתוזמן</span>';
		} elseif ( $date_end && $end_normalized < $now ) {
			$status_label = '<span style="color:#787c82;">עבר</span>';
		} else {
			$status_label = '<span style="color:#00a32a;">פעיל</span>';
		}
		?>
		<tr>
			<td>
				<input type="hidden" name="rows[<?php echo esc_attr( $i ); ?>][id]" value="<?php echo esc_attr( $id ); ?>">
				<input type="text" name="rows[<?php echo esc_attr( $i ); ?>][message]" value="<?php echo esc_attr( $message ); ?>" class="widefat" placeholder="טקסט המבזק">
			</td>
			<td>
				<input type="url" name="rows[<?php echo esc_attr( $i ); ?>][link]" value="<?php echo esc_attr( $link ); ?>" class="widefat" placeholder="https://">
			</td>
			<td>
				<input type="datetime-local" name="rows[<?php echo esc_attr( $i ); ?>][date_start]" value="<?php echo esc_attr( $date_start ); ?>" class="widefat">
			</td>
			<td>
				<input type="datetime-local" name="rows[<?php echo esc_attr( $i ); ?>][date_end]" value="<?php echo esc_attr( $date_end ); ?>" class="widefat">
			</td>
			<td><?php echo $status_label; ?></td>
			<td>
				<?php if ( $id ) :
					$delete_url = wp_nonce_url( admin_url( 'admin-post.php?action=uhaifa_flash_delete&post_id=' . $id ), 'uhaifa_flash_delete_' . $id );
					?>
					<a href="<?php echo esc_url( $delete_url ); ?>" class="uhaifa-flash-delete-row" data-confirm="למחוק את המבזק לצמיתות?" style="color:#b32d2e;text-decoration:none;font-size:18px;" aria-label="מחק מבזק">×</a>
				<?php else : ?>
					<a href="#" class="uhaifa-flash-delete-row" data-new="1" style="color:#b32d2e;text-decoration:none;font-size:18px;" aria-label="הסר שורה">×</a>
				<?php endif; ?>
			</td>
		</tr>
		<?php
	}

	// ─── Save / delete ──────────────────────────────────────────────────────

	public function handle_save_all() {
		if ( ! is_super_admin() ) {
			wp_die( 'אין לך הרשאה לבצע פעולה זו.', 'אין הרשאה', [ 'response' => 403 ] );
		}
		check_admin_referer( 'uhaifa_flash_save', 'uhaifa_flash_nonce' );

		$rows       = ( isset( $_POST['rows'] ) && is_array( $_POST['rows'] ) ) ? $_POST['rows'] : [];
		$row_errors = [];

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) continue;
			$id      = absint( $row['id'] ?? 0 );
			if ( $id && get_post_type( $id ) !== 'uhaifa_flash' ) continue; // never let a grid row overwrite another post type
			$message = sanitize_text_field( wp_unslash( $row['message'] ?? '' ) );
			$link    = esc_url_raw( wp_unslash( $row['link'] ?? '' ) );
			$start   = uhaifa_banners_sanitize_datetime_local( wp_unslash( $row['date_start'] ?? '' ) );
			$end     = uhaifa_banners_sanitize_datetime_local( wp_unslash( $row['date_end'] ?? '' ) );

			// Skip a fully blank row (e.g. an unused "add row" template
			// that was never filled in).
			if ( $message === '' && $link === '' && $start === '' && $end === '' ) continue;

			$errors = [];
			if ( $message === '' ) $errors[] = 'הודעה חסרה';
			if ( $start === '' )    $errors[] = 'תאריך התחלה חסר';
			$status = $errors ? 'draft' : 'publish';

			// This class has already validated the row above — tell
			// UHaifa_Flash_CPT::validate_before_save() to stand down
			// rather than re-check against its own (meta-box-shaped)
			// $_POST assumptions, which don't apply to a grid submission.
			UHaifa_Flash_CPT::$skip_validation = true;

			if ( $id ) {
				wp_update_post( [ 'ID' => $id, 'post_title' => $message, 'post_status' => $status ] );
			} else {
				$id = wp_insert_post( [
					'post_type'   => 'uhaifa_flash',
					'post_title'  => $message,
					'post_status' => $status,
				] );
			}

			UHaifa_Flash_CPT::$skip_validation = false;

			if ( $id && ! is_wp_error( $id ) ) {
				update_post_meta( $id, '_uhaifa_flash_link',        $link );
				update_post_meta( $id, '_uhaifa_flash_date_start',  $start );
				update_post_meta( $id, '_uhaifa_flash_date_end',    $end );

				if ( $errors ) {
					$row_errors[] = ( $message !== '' ) ? $message : '(ללא טקסט)';
				}
			}
		}

		update_option( 'uhaifa_flash_last_updated', time() );
		delete_transient( 'uhaifa_flash_' . md5( untrailingslashit( get_site_url() ) ) );

		if ( $row_errors ) {
			set_transient( 'uhaifa_flash_grid_errors', $row_errors, 45 );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE_SLUG . '&saved=1' ) );
		exit;
	}

	public function handle_delete() {
		if ( ! is_super_admin() ) {
			wp_die( 'אין לך הרשאה לבצע פעולה זו.', 'אין הרשאה', [ 'response' => 403 ] );
		}

		$post_id = absint( $_GET['post_id'] ?? 0 );
		check_admin_referer( 'uhaifa_flash_delete_' . $post_id );

		if ( $post_id && get_post_type( $post_id ) === 'uhaifa_flash' ) {
			wp_delete_post( $post_id, true ); // force-delete, skip trash — lightweight, ephemeral content
			update_option( 'uhaifa_flash_last_updated', time() );
			delete_transient( 'uhaifa_flash_' . md5( untrailingslashit( get_site_url() ) ) );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE_SLUG . '&saved=1' ) );
		exit;
	}
}
