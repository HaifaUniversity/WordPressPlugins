<?php
/**
 * Consumer class — runs on ALL sites (including the publisher), for sites
 * that have NOT yet adopted the UHaifa Hero Elementor widget. It hides
 * whatever markup lives at #uhaifa-hero-banner and injects the hub's
* override banner via JS (uhaifa-consumer.js).
 *
 * Sites using the new Elementor widget don't need this at all — the widget
 * resolves the override server-side (see class-elementor-widget.php) and
 * renders it directly in place of its own local content, with no JS swap.
 * This class stays as-is for legacy hero areas.
 *
 * The actual fetch/cache logic now lives in UHaifa_Banner_Override_Resolver
 * so it's shared with the widget instead of duplicated.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once __DIR__ . '/class-override-resolver.php';

class UHaifa_Banner_Consumer {

	/** @var array|null Fetched campaign data ({duration, slides}) for this request */
	private $banner = null;

	public function __construct() {
		add_action( 'wp',                [ $this, 'load_banner' ] );
		add_action( 'wp_enqueue_scripts',[ $this, 'maybe_enqueue' ] );
		add_action( 'wp_footer',         [ $this, 'maybe_inject' ] );
	}

	// ─── 1. Fetch / cache ─────────────────────────────────────────────────────

	public function load_banner() {
		if ( is_admin() ) return;
		$this->banner = UHaifa_Banner_Override_Resolver::get_payload();
	}

	// ─── 2. Enqueue assets ────────────────────────────────────────────────────

	public function maybe_enqueue() {
		if ( ! $this->banner ) return;

		wp_enqueue_style(
			'uhaifa-consumer',
			UHAIFA_BANNERS_URL . 'assets/uhaifa-consumer.css',
			[],
			UHAIFA_BANNERS_VERSION
		);

		wp_enqueue_script(
			'uhaifa-consumer',
			UHAIFA_BANNERS_URL . 'assets/uhaifa-consumer.js',
			[],
			UHAIFA_BANNERS_VERSION,
			true   // footer
		);

		// Pass the full banner payload to JS as-is — its shape already
		// varies by type ({slides:[...]} for image, {items:[...],
		// background:{...}} for dynamic), so no need to hand-pick fields
		// here; uhaifa-consumer.js branches on uhBanner.type.
		wp_localize_script( 'uhaifa-consumer', 'uhBanner', $this->banner );
	}

	// ─── 3. Inject placeholder ────────────────────────────────────────────────
	// The actual DOM manipulation is done by uhaifa-consumer.js.
	// We output nothing extra here — JS handles the injection.

	public function maybe_inject() {
		if ( ! $this->banner ) return;
		// Intentionally empty — JS handles the injection.
		// This hook can be used for server-side noscript fallback in future.
	}
}
