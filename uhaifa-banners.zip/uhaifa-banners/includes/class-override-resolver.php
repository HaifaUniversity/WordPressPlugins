<?php
/**
 * Resolves "what active campaign, if any, is the hub currently pushing to
 * THIS site?" — the shared caching/fetch logic originally inline in
 * UHaifa_Banner_Consumer::get_banner(). Extracted so both:
 *   - the legacy client-side override (UHaifa_Banner_Consumer +
  *     uhaifa-consumer.js, for sites without the widget yet), and
 *   - the new Elementor widget (server-side override, no JS swap)
 * hit the exact same cached lookup instead of duplicating the REST/HTTP
 * round-trip and its transient caching.
 *
 * Runs on every site, including the hub itself (the hub is also a
 * "consumer" of its own /active endpoint — see the internal rest_do_request
 * branch below, which avoids a real HTTP round-trip in that case).
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class UHaifa_Banner_Override_Resolver {

	/**
	 * Returns the hub's active-campaign payload for this site, or null if
	 * nothing is currently being pushed here. Cached in a transient for
	 * UHAIFA_BANNERS_CACHE_TTL seconds (or 60s on fetch failure).
	 */
		public static function get_payload() {
		if ( ! get_option( 'uhaifa_allow_hero_override', true ) ) {
			return null;
		}

		$site_url  = untrailingslashit( get_site_url() );
		$cache_key = 'uhaifa_banner_' . md5( $site_url );

		// ── Serve from transient cache ──
		$cached = get_transient( $cache_key );

		if ( $cached !== false ) {
			// 'none' means we already know there are no active slides
			return $cached === 'none' ? null : $cached;
		}

		// ── Publisher calls its own REST internally (avoids HTTP round-trip) ──
		$publisher = untrailingslashit( UHAIFA_BANNERS_PUBLISHER_URL );

		if ( $site_url === $publisher ) {
			$req = new WP_REST_Request( 'GET', '/uhaifa-banners/v1/active' );
			$req->set_param( 'site', $site_url );
			$res  = rest_do_request( $req );
			$data = $res->get_data();

		} else {
			// ── Consumer does remote HTTP GET ──
			$endpoint = trailingslashit( UHAIFA_BANNERS_PUBLISHER_URL )
			            . 'wp-json/uhaifa-banners/v1/active';

			$response = uhaifa_banners_remote_request(
				'GET',
				add_query_arg( 'site', rawurlencode( $site_url ), $endpoint ),
				[ 'timeout' => 5 ]
			);

			if ( is_wp_error( $response )
			     || wp_remote_retrieve_response_code( $response ) !== 200 ) {
				// On failure cache briefly and bail
				set_transient( $cache_key, 'none', 60 );
				return null;
			}

			$data = json_decode( wp_remote_retrieve_body( $response ), true );
		}

		// ── Store in transient ──
		// 'slides' is used by image-type campaigns, 'items' by dynamic-type
		// ones — either being non-empty means there's something to show.
		$has_content = $data && is_array( $data )
			&& ( ! empty( $data['slides'] ) || ! empty( $data['items'] ) );

		if ( $has_content ) {
			set_transient( $cache_key, $data, UHAIFA_BANNERS_CACHE_TTL );
			return $data;
		}

				set_transient( $cache_key, 'none', UHAIFA_BANNERS_CACHE_TTL );
		return null;
	}

	/**
	 * Force-refreshes this site's cached payload — clears the transient and
	 * immediately re-fetches from the hub, instead of waiting for the next
	 * real visitor to hit an expired transient. Called via the /warm-cache
	 * REST route below, itself triggered by the hub's "Push Now" button.
	 */
	public static function refresh() {
		$site_url  = untrailingslashit( get_site_url() );
		$cache_key = 'uhaifa_banner_' . md5( $site_url );
		delete_transient( $cache_key );
		return self::get_payload();
	}
}

// ─── Warm-cache REST route (runs on every site) ────────────────────────────
// Lets the hub tell a spoke site "refresh right now" immediately after a
// campaign is saved, instead of waiting for a real visitor to trigger a
// lazy refetch. Registered here (not in class-publisher.php) because this
// file loads on every site, hub included.

add_action( 'rest_api_init', function () {

	// Public and deliberately harmless: all it can do is make this site
	// re-fetch from the hub (never anything else), and it's throttled to one
	// real refresh per 30 seconds, so it can't be used to hammer the hub.
	register_rest_route( 'uhaifa-banners/v1', '/warm-cache', [
		'methods'             => 'POST',
		'callback'            => function ( WP_REST_Request $request ) {
			if ( get_transient( 'uhaifa_banners_warm_lock' ) ) {
				return rest_ensure_response( [ 'success' => true, 'throttled' => true ] );
			}
			set_transient( 'uhaifa_banners_warm_lock', 1, 30 );

			$payload = UHaifa_Banner_Override_Resolver::refresh();
			return rest_ensure_response( [
				'success'     => true,
				'has_content' => ! empty( $payload ),
			] );
		},
		'permission_callback' => '__return_true',
	] );

	// Lets the hub confirm, during /register, that a claimed site URL really
	// runs this plugin. Exposes nothing beyond the plugin name + version.
	register_rest_route( 'uhaifa-banners/v1', '/ping', [
		'methods'             => 'GET',
		'callback'            => function () {
			return rest_ensure_response( [ 'plugin' => 'uhaifa-banners', 'version' => UHAIFA_BANNERS_VERSION ] );
		},
		'permission_callback' => '__return_true',
	] );
} );
